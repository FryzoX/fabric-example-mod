package night.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.world.level.BlockCollisions;
import net.minecraft.world.level.block.state.BlockState;
import night.utils.minecraft.WorldUtils;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({BlockCollisions.class})
public class BlockCollisionsMixin {
   @Shadow
   @Final
   private MutableBlockPos pos;

   @ModifyExpressionValue(
      method = {"computeNext"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/level/BlockGetter;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;"
      )}
   )
   private BlockState night$predictPlacedCollision(BlockState original) {
      if (!original.isAir()) {
         return original;
      } else {
         BlockState predicted = WorldUtils.getPredictedCollisionState(this.pos);
         return predicted != null ? predicted : original;
      }
   }
}
