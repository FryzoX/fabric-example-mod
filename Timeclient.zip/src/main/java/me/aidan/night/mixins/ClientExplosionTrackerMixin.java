package night.mixins;

import net.minecraft.client.multiplayer.ClientExplosionTracker;
import net.minecraft.core.particles.ExplosionParticleInfo;
import net.minecraft.util.random.WeightedList;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.modules.impl.visuals.NoRenderModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientExplosionTracker.class})
public class ClientExplosionTrackerMixin {
   @Inject(
      method = {"track"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$cancelDebris(Vec3 center, float radius, int blockCount, WeightedList<ExplosionParticleInfo> blockParticles, CallbackInfo ci) {
      NoRenderModule noRender = Night.MODULE_MANAGER.getModule(NoRenderModule.class);
      if (noRender.isToggled() && noRender.explosions.getValue()) {
         ci.cancel();
      }
   }
}
