package night.mixins;

import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.extract.LevelExtractor;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({LevelExtractor.class})
public abstract class LevelExtractorMixin {
   @Inject(
      method = {"isEntityVisible"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$skipNullEntity(Entity entity, Frustum frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
      if (entity == null) {
         cir.setReturnValue(false);
      }
   }
}
