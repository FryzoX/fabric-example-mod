package night.mixins;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import night.Night;
import night.modules.impl.visuals.NoRenderModule;
import night.utils.IMinecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({BlockEntityRenderDispatcher.class})
public class BlockEntityRenderDispatcherMixin implements IMinecraft {
   @Inject(
      method = {"submit"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$submit(BlockEntityRenderState state, PoseStack matrices, SubmitNodeCollector collector, CameraRenderState cameraState, CallbackInfo info) {
      NoRenderModule noRender = Night.MODULE_MANAGER.getModule(NoRenderModule.class);
      if (noRender.isToggled()
         && !noRender.tileEntities.getValue().equals("Never")
         && (
            noRender.tileEntities.getValue().equals("Always")
               || noRender.tileEntities.getValue().equals("Distance")
                  && Math.sqrt(mc.player.distanceToSqr(state.blockPos.getX(), state.blockPos.getY(), state.blockPos.getZ()))
                     > noRender.tileDistance.getValue().floatValue()
         )) {
         info.cancel();
      }
   }
}
