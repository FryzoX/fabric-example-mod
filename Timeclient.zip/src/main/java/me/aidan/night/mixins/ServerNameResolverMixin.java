package night.mixins;

import java.net.InetSocketAddress;
import java.util.Optional;
import net.minecraft.client.multiplayer.resolver.ResolvedServerAddress;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.client.multiplayer.resolver.ServerNameResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ServerNameResolver.class})
public class ServerNameResolverMixin {
   private static final Logger LOGGER = LoggerFactory.getLogger("Night/DnsFix");

   @Inject(
      method = {"resolveAddress"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void resolveAddress(ServerAddress address, CallbackInfoReturnable<Optional<ResolvedServerAddress>> cir) {
      if (!((Optional)cir.getReturnValue()).isPresent()) {
         try {
            InetSocketAddress resolved = new InetSocketAddress(address.getHost(), address.getPort());
            if (resolved.isUnresolved()) {
               LOGGER.warn("[PB] java.net fallback resolve of {} also unresolved", address.getHost());
               return;
            }

            LOGGER.info("[PB] Resolved {} via java.net fallback: {}", address.getHost(), resolved);
            cir.setReturnValue(Optional.of(ResolvedServerAddress.from(resolved)));
         } catch (Exception var4) {
            LOGGER.warn("[PB] java.net fallback resolve of {} failed", address.getHost(), var4);
         }
      }
   }
}
