package night.mixins;

import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Button.Builder;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.DisconnectedScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.TransferState;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.network.chat.Component;
import night.Night;
import night.gui.components.AccountButton;
import night.modules.impl.miscellaneous.AutoReconnectModule;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({DisconnectedScreen.class})
public class DisconnectedScreenMixin extends Screen {
   @Shadow
   @Final
   private LinearLayout layout;
   @Unique
   private Button toggleButton;
   @Unique
   private Button button;
   @Unique
   private double time = 100.0;

   protected DisconnectedScreenMixin(Component title) {
      super(title);
   }

   @Inject(
      method = {"init"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/layouts/LinearLayout;arrangeElements()V",
         shift = Shift.BEFORE
      )}
   )
   private void init(CallbackInfo info) {
      if (Night.SERVER_MANAGER.getLastConnection() != null) {
         this.button = new Builder(Component.literal(this.getText()), button -> this.tryConnecting()).width(200).build();
         this.toggleButton = new Builder(
               Component.literal(
                  "Toggle "
                     + (Night.MODULE_MANAGER.getModule(AutoReconnectModule.class).isToggled() ? ChatFormatting.GREEN : ChatFormatting.RED)
                     + "AutoReconnect"
               ),
               button -> {
                  Night.MODULE_MANAGER
                     .getModule(AutoReconnectModule.class)
                     .setToggled(!Night.MODULE_MANAGER.getModule(AutoReconnectModule.class).isToggled(), false);
                  this.toggleButton
                     .setMessage(
                        Component.literal(
                           "Toggle "
                              + (Night.MODULE_MANAGER.getModule(AutoReconnectModule.class).isToggled() ? ChatFormatting.GREEN : ChatFormatting.RED)
                              + "AutoReconnect"
                        )
                     );
                  this.button.setMessage(Component.literal(this.getText()));
                  this.time = Night.MODULE_MANAGER.getModule(AutoReconnectModule.class).delay.getValue().intValue() * 20;
               }
            )
            .width(200)
            .build();
         this.layout.addChild(this.button);
         this.layout.addChild(this.toggleButton);
      }

      this.addRenderableWidget(AccountButton.create(8, 8, 75, 20, this));
   }

   public void tick() {
      if (Night.MODULE_MANAGER.getModule(AutoReconnectModule.class).isToggled() && Night.SERVER_MANAGER.getLastConnection() != null) {
         if (this.time <= 0.0) {
            this.tryConnecting();
         } else {
            this.time--;
            if (this.button != null) {
               this.button.setMessage(Component.literal(this.getText()));
            }
         }
      }
   }

   @Unique
   private String getText() {
      String reconnectText = "Reconnect";
      if (Night.MODULE_MANAGER.getModule(AutoReconnectModule.class).isToggled()) {
         reconnectText = reconnectText + " " + String.format("(" + ChatFormatting.GREEN + "%.1fs" + ChatFormatting.RESET + ")", this.time / 20.0);
      }

      return reconnectText;
   }

   @Unique
   private void tryConnecting() {
      ConnectScreen.startConnecting(
         new TitleScreen(),
         Minecraft.getInstance(),
         (ServerAddress)Night.SERVER_MANAGER.getLastConnection().left(),
         (ServerData)Night.SERVER_MANAGER.getLastConnection().right(),
         false,
         new TransferState(Map.of(), Map.of(), false)
      );
   }
}
