package night.mixins;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.equine.AbstractHorse;
import night.Night;
import night.modules.impl.movement.EntityControlModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({AbstractHorse.class})
public abstract class AbstractHorseMixin {
   @Inject(
      method = {"getControllingPassenger"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$onGetControllingPassenger(CallbackInfoReturnable<LivingEntity> cir) {
      Entity first;
      EntityControlModule entityControl;
      if (Night.MODULE_MANAGER != null
         && (entityControl = Night.MODULE_MANAGER.getModule(EntityControlModule.class)) != null
         && entityControl.isToggled()
         && entityControl.control.getValue()
         && (first = ((AbstractHorse)this).getFirstPassenger()) instanceof LivingEntity) {
         LivingEntity living = (LivingEntity)first;
         cir.setReturnValue(living);
      }
   }

   @Inject(
      method = {"isTamed"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void night$onIsTamed(CallbackInfoReturnable<Boolean> cir) {
      EntityControlModule entityControl;
      if (Night.MODULE_MANAGER != null
         && (entityControl = Night.MODULE_MANAGER.getModule(EntityControlModule.class)) != null
         && entityControl.isToggled()
         && entityControl.control.getValue()) {
         cir.setReturnValue(true);
      }
   }
}
