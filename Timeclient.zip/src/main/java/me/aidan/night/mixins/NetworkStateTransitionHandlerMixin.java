package night.mixins;

import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.network.Connection;
import net.minecraft.network.ProtocolSwapHandler;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import night.pingbypass.PingBypassFlags;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ProtocolSwapHandler.class})
public interface NetworkStateTransitionHandlerMixin {
   @Inject(
      method = {"handleInboundTerminalPacket"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void handleInboundTerminalPacket(ChannelHandlerContext context, Packet<?> packet, CallbackInfo info) {
      if (PingBypassFlags.suppressEncoderErrors) {
         ChannelHandler channelHandler = context.pipeline().get("packet_handler");
         Connection cc;
         if (channelHandler instanceof Connection && (cc = (Connection)channelHandler).getReceiving() == PacketFlow.CLIENTBOUND) {
            info.cancel();
         }
      }
   }

   @Inject(
      method = {"handleOutboundTerminalPacket"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void handleOutboundTerminalPacket(ChannelHandlerContext context, Packet<?> packet, CallbackInfo info) {
      if (PingBypassFlags.suppressEncoderErrors) {
         ChannelHandler channelHandler = context.pipeline().get("packet_handler");
         Connection cc;
         if (channelHandler instanceof Connection && (cc = (Connection)channelHandler).getReceiving() == PacketFlow.CLIENTBOUND) {
            info.cancel();
         }
      }
   }
}
