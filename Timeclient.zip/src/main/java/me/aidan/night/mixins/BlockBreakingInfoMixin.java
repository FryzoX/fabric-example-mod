package night.mixins;

import net.minecraft.server.level.BlockDestructionProgress;
import night.Night;
import night.events.impl.PlayerMineEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({BlockDestructionProgress.class})
public class BlockBreakingInfoMixin {
   @Inject(
      method = {"setProgress"},
      at = {@At("HEAD")}
   )
   private void setProgress(int progress, CallbackInfo ci) {
      BlockDestructionProgress self = (BlockDestructionProgress)this;
      if (progress >= 0 && progress <= 9) {
         Night.EVENT_HANDLER.post(new PlayerMineEvent(self.getId(), self.getPos()));
      }
   }
}
