package night.mixins;

import java.awt.Color;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.LevelLoadingScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.LevelLoadingScreen.Reason;
import net.minecraft.network.chat.Component;
import night.Night;
import night.modules.impl.core.MenuModule;
import night.utils.color.ColorUtils;
import night.utils.graphics.Renderer2D;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({LevelLoadingScreen.class})
public class DownloadingTerrainScreenMixin extends Screen {
   @Shadow
   @Final
   private Reason reason;

   protected DownloadingTerrainScreenMixin(Component title) {
      super(title);
   }

   @Inject(
      method = {"extractBackground"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void renderBackground(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      if (this.reason.equals(Reason.OTHER)
         && Night.MODULE_MANAGER.getModule(MenuModule.class).isToggled()
         && Night.MODULE_MANAGER.getModule(MenuModule.class).mainMenu.getValue()) {
         Renderer2D.renderQuad(context, 0.0F, 0.0F, this.width, this.height, new Color(25, 25, 25, 255));

         for (int i = 0; i < this.width; i++) {
            Color color = ColorUtils.getRainbow(2L, 0.7F, 1.0F, 255, i * 5L);
            Renderer2D.renderQuad(context, i, 0.0F, i + 1, 1.0F, color);
         }

         ci.cancel();
      }
   }
}
