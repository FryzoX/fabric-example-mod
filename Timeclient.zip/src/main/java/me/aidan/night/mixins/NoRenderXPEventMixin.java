package night.mixins;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.client.renderer.LevelEventHandler;
import net.minecraft.core.BlockPos;
import night.utils.graphics.XPParticleScope;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({LevelEventHandler.class})
public class NoRenderXPEventMixin {
   @WrapMethod(
      method = {"levelEvent"}
   )
   private void night$xpScope(int event, BlockPos pos, int data, Operation<Void> original) {
      boolean previous = XPParticleScope.enter(event, data);

      try {
         original.call(new Object[]{event, pos, data});
      } finally {
         XPParticleScope.restore(previous);
      }
   }
}
