package night.mixins;

import net.minecraft.client.gui.render.GuiRenderer;
import night.managers.RenderManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({GuiRenderer.class})
public class GuiRendererMixin {
   @Inject(
      method = {"draw"},
      at = {@At("RETURN")}
   )
   private void night$postGuiRender(CallbackInfo ci) {
      for (Runnable r : RenderManager.POST_GUI_RENDERERS) {
         r.run();
      }
   }
}
