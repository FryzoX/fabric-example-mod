package night.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.model.object.crystal.EndCrystalModel;
import net.minecraft.client.renderer.entity.state.EndCrystalRenderState;
import night.modules.impl.visuals.CrystalAnimationsModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({EndCrystalModel.class})
public abstract class CrystalAnimationsMixin {
   @ModifyConstant(
      method = {"setupAnim(Lnet/minecraft/client/renderer/entity/state/EndCrystalRenderState;)V"},
      constant = {@Constant(
         floatValue = 3.0F
      )},
      require = 1
   )
   private float cheatsmc$rotation(float original) {
      CrystalAnimationsModule module = CrystalAnimationsModule.active();
      return module == null ? original : original * module.rotationSpeed.getValue().floatValue();
   }

   @ModifyExpressionValue(
      method = {"setupAnim(Lnet/minecraft/client/renderer/entity/state/EndCrystalRenderState;)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/renderer/entity/EndCrystalRenderer;getY(F)F"
      )},
      require = 1
   )
   private float cheatsmc$bobbing(float original) {
      CrystalAnimationsModule module = CrystalAnimationsModule.active();
      return module == null ? original : (original + 1.4F) * module.floatFactor.getValue().floatValue() - 1.4F;
   }

   @Inject(
      method = {"setupAnim(Lnet/minecraft/client/renderer/entity/state/EndCrystalRenderState;)V"},
      at = {@At("TAIL")},
      require = 1
   )
   private void cheatsmc$parts(EndCrystalRenderState state, CallbackInfo ci) {
      EndCrystalModel model = (EndCrystalModel)this;
      CrystalAnimationsModule module = CrystalAnimationsModule.active();
      model.outerGlass.skipDraw = module != null && !module.outer.getValue();
      model.innerGlass.skipDraw = module != null && !module.inner.getValue();
      model.cube.skipDraw = module != null && !module.core.getValue();
      model.base.visible = state.showsBottom && (module == null || module.bottom.getValue());
      if (module != null) {
         float scale = module.crystalScale.getValue().floatValue();
         model.root().xScale *= scale;
         model.root().yScale *= scale;
         model.root().zScale *= scale;
         model.outerGlass.y = model.outerGlass.y - module.heightOffset.getValue().floatValue() * 8.0F / scale;
      }
   }
}
