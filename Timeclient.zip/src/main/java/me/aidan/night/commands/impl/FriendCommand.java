package night.commands.impl;

import java.util.ArrayList;
import java.util.List;
import night.Night;
import night.commands.Command;
import night.commands.RegisterCommand;
import night.modules.impl.core.FriendModule;
import night.utils.chat.ChatUtils;

@RegisterCommand(
   name = "friend",
   tag = "Friend",
   description = "Allows you to manage the client's friend list.",
   syntax = "<add|del> <[player]> | <clear|list>",
   aliases = {"f", "friends"}
)
public class FriendCommand extends Command {
   @Override
   public List<String> getSuggestions(String[] args) {
      if (args.length == 0) {
         return List.of("add", "del", "clear", "list");
      } else if (args.length == 1 && args[0].equalsIgnoreCase("del")) {
         return Night.FRIEND_MANAGER.getFriends();
      } else {
         return args.length == 1 && args[0].equalsIgnoreCase("add") && mc.level != null && mc.player != null
            ? mc.level
               .players()
               .stream()
               .filter(player -> player != mc.player)
               .map(player -> player.getName().getString())
               .filter(name -> !Night.FRIEND_MANAGER.contains(name))
               .toList()
            : List.of();
      }
   }

   @Override
   public void execute(String[] args) {
      if (args.length == 2) {
         String var2 = args[0].toLowerCase();
         switch (var2) {
            case "add":
               if (!Night.FRIEND_MANAGER.contains(args[1])) {
                  if (Night.MODULE_MANAGER.getModule(FriendModule.class).friendMessage.getValue()) {
                     Night.FRIEND_MANAGER.sendFriendMessage(args[1]);
                  }

                  Night.FRIEND_MANAGER.add(args[1]);
                  Night.CHAT_MANAGER
                     .tagged(
                        "Successfully added " + ChatUtils.getPrimary() + args[1] + ChatUtils.getSecondary() + " to your friends list.",
                        this.getTag(),
                        this.getName()
                     );
               } else {
                  Night.CHAT_MANAGER
                     .tagged(ChatUtils.getPrimary() + args[1] + ChatUtils.getSecondary() + " is already on your friends list.", this.getTag(), this.getName());
               }
               break;
            case "del":
               if (Night.FRIEND_MANAGER.contains(args[1])) {
                  Night.FRIEND_MANAGER.remove(args[1]);
                  Night.CHAT_MANAGER
                     .tagged(
                        "Successfully removed " + ChatUtils.getPrimary() + args[1] + ChatUtils.getSecondary() + " from your friends list.",
                        this.getTag(),
                        this.getName()
                     );
               } else {
                  Night.CHAT_MANAGER
                     .tagged(ChatUtils.getPrimary() + args[1] + ChatUtils.getSecondary() + " is not on your friends list.", this.getTag(), this.getName());
               }
               break;
            default:
               this.messageSyntax();
         }
      } else if (args.length == 1) {
         String var9 = args[0].toLowerCase();
         switch (var9) {
            case "clear":
               Night.FRIEND_MANAGER.clear();
               Night.CHAT_MANAGER.tagged("Successfully cleared your friends list.", this.getTag(), this.getName() + "-list");
               break;
            case "list":
               ArrayList<String> friends = Night.FRIEND_MANAGER.getFriends();
               if (friends.isEmpty()) {
                  Night.CHAT_MANAGER.tagged("You currently have no friends.", this.getTag());
               } else {
                  StringBuilder builder = new StringBuilder();
                  int index = 0;

                  for (String name : friends) {
                     StringBuilder var10000 = builder.append(ChatUtils.getSecondary()).append(name);
                     index++;
                     var10000.append(index == friends.size() ? "" : ", ");
                  }

                  Night.CHAT_MANAGER
                     .message(
                        "Friends "
                           + ChatUtils.getPrimary()
                           + "["
                           + ChatUtils.getSecondary()
                           + friends.size()
                           + ChatUtils.getPrimary()
                           + "]: "
                           + ChatUtils.getSecondary()
                           + builder,
                        this.getName() + "-list"
                     );
               }
               break;
            default:
               this.messageSyntax();
         }
      } else {
         this.messageSyntax();
      }
   }
}
