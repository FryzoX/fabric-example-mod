package night.gui.api;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import lombok.Generated;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.util.Mth;
import night.Night;
import night.gui.ClickGuiScreen;
import night.gui.impl.ModuleButton;
import night.gui.impl.WhitelistButton;
import night.modules.Module;
import night.modules.impl.core.ClickGuiModule;
import night.modules.impl.core.PingBypassModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.CategorySetting;
import night.utils.animations.Animation;
import night.utils.animations.Easing;
import night.utils.graphics.Renderer2D;

public class Frame {
   private final Module.Category category;
   private final String headerLabel;
   private int x;
   private int y;
   private int width;
   private int height;
   private int totalHeight;
   private int baseContentHeight;
   private int dragX = 0;
   private int dragY = 0;
   private int textPadding = 3;
   public boolean open = true;
   public boolean dragging = false;
   private final ArrayList<Button> buttons = new ArrayList<>();
   private float scrollOffset = 0.0F;
   private float targetScroll = 0.0F;
   private long lastScrollTime = System.currentTimeMillis();
   private final Animation openAnim = new Animation(1.0F, 1.0F, 220, Easing.Method.EASE_OUT_CUBIC);

   public Frame(Module.Category category, int x, int y, int width, int height) {
      this.category = category;
      this.headerLabel = null;
      this.x = x;
      this.y = y;
      this.width = width;
      this.height = height;

      for (Module module : Night.MODULE_MANAGER.getModules(category)) {
         if (!(module instanceof PingBypassModule)) {
            this.buttons.add(new ModuleButton(module, this, height));
         }
      }
   }

   public Frame(String headerLabel, List<Button> prebuiltButtons, int x, int y, int width, int height) {
      this.category = null;
      this.headerLabel = headerLabel;
      this.x = x;
      this.y = y;
      this.width = width;
      this.height = height;
      this.buttons.addAll(prebuiltButtons);
   }

   private String getHeaderText() {
      return this.category != null ? this.category.getName() : this.headerLabel;
   }

   public void render(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
      this.render(context, mouseX, mouseY, delta, "");
   }

   public void render(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta, String searchQuery) {
      if (this.dragging) {
         this.setX(mouseX - this.dragX);
         this.setY(mouseY - this.dragY);
      }

      boolean searching = searchQuery != null && !searchQuery.isEmpty();
      this.totalHeight = this.height;
      this.baseContentHeight = 0;
      this.totalHeight++;

      for (Button button : this.buttons) {
         if (searching && button instanceof ExpandableRow row) {
            if (!row.getRowName().toLowerCase().contains(searchQuery.toLowerCase())) {
               button.setVisible(false);
               continue;
            }

            button.setVisible(true);
            row.setSearchQuery(searchQuery);
         } else if (!searching && button instanceof ExpandableRow row2) {
            button.setVisible(true);
            row2.setSearchQuery("");
         }

         if (button.isVisible()) {
            this.baseContentHeight = this.baseContentHeight + button.getHeight();
            button.setX(this.x);
            button.setY(this.y + this.totalHeight);
            this.totalHeight = this.totalHeight + button.getHeight();
            if (button instanceof ExpandableRow row) {
               float openAmount = row.getOpenAmount();
               List<Button> settingButtons = row.getButtons();
               float childOffset = 0.0F;
               float fullHeight = 0.0F;

               for (Button b : settingButtons) {
                  b.getSetting().getVisibility().update();
                  boolean visible = b.getSetting().getVisibility().isVisible();
                  b.setVisible(visible);
                  if (visible) {
                     float categoryScale = 1.0F;
                     if (b.getSetting().getVisibility() instanceof CategorySetting.Visibility categoryVisibility) {
                        categoryScale = categoryVisibility.getValue().getOpenAmount();
                     } else if (b.getSetting().getVisibility() instanceof BooleanSetting.Visibility booleanVisibility) {
                        categoryScale = booleanVisibility.getOpenAmount();
                     }

                     float rowHeight = b.getHeight() * categoryScale;
                     b.setX(this.x);
                     b.setY(this.y + this.totalHeight + Math.round(childOffset));
                     childOffset += rowHeight;
                     fullHeight += rowHeight;
                  }
               }

               int revealHeight = Math.round(fullHeight * openAmount);
               row.setRevealHeight(revealHeight);
               this.totalHeight += revealHeight;
               if (searching) {
                  this.baseContentHeight += revealHeight;
               }
            }
         }
      }

      this.baseContentHeight = Math.max(
         this.baseContentHeight,
         Math.min(this.totalHeight - this.height - 1, Minecraft.getInstance().getWindow().getGuiScaledHeight() - this.y - this.height - 10)
      );
      float contentHeight = this.totalHeight - this.height - 1;
      float viewHeight = this.baseContentHeight;
      float maxScroll = 0.0F;
      float minScroll = -Math.max(0.0F, contentHeight - viewHeight);
      long now = System.currentTimeMillis();
      float dt = Math.min((float)(now - this.lastScrollTime) / 1000.0F, 0.05F);
      this.lastScrollTime = now;
      if (dt <= 1.0E-4F) {
         dt = 0.016F;
      }

      if (this.targetScroll > maxScroll) {
         this.targetScroll = this.targetScroll + (maxScroll - this.targetScroll) * Math.min(1.0F, 8.0F * dt);
      } else if (this.targetScroll < minScroll) {
         this.targetScroll = this.targetScroll + (minScroll - this.targetScroll) * Math.min(1.0F, 8.0F * dt);
      }

      float lerpFactor = 1.0F - (float)Math.exp(-9.0 * dt);
      this.scrollOffset = Mth.lerp(lerpFactor, this.scrollOffset, this.targetScroll);
      if (Math.abs(this.scrollOffset - this.targetScroll) < 0.01F && this.targetScroll >= minScroll && this.targetScroll <= maxScroll) {
         this.scrollOffset = this.targetScroll;
      }

      int shift;
      if ((shift = Math.round(this.scrollOffset)) != 0) {
         for (Button button : this.buttons) {
            if (button.isVisible()) {
               button.setY(button.getY() + shift);
               if (button instanceof ExpandableRow row) {
                  for (Button bx : row.getButtons()) {
                     if (bx.isVisible()) {
                        bx.setY(bx.getY() + shift);
                     }
                  }
               }
            }
         }
      }

      ClickGuiModule clickGui = Night.MODULE_MANAGER.getModule(ClickGuiModule.class);
      boolean showIcons = clickGui.categoryIcons.getValue();
      boolean glow = clickGui.glowAccent.getValue();
      Renderer2D.renderQuad(context, this.x, this.y, this.x + this.width, this.y + this.height, ClickGuiScreen.getButtonColor(this.y, 55));
      if (glow) {
         Renderer2D.renderQuad(context, this.x, this.y, this.x + this.width, this.y + 1, ClickGuiScreen.getButtonColor(this.y, 220));
      }

      Color accentColor = ClickGuiScreen.getButtonColor(this.y, 220);
      Renderer2D.renderQuad(context, this.x, this.y + this.height - 1, this.x + this.width, this.y + this.height, accentColor);
      String icon = showIcons ? this.getCategoryIcon() + " " : "";
      Night.FONT_MANAGER.drawTextWithShadow(context, icon + this.getHeaderText(), this.x + this.textPadding, this.y + 2, Color.WHITE);
      if (clickGui.triangles.getValue()) {
         String chevron = this.open ? "▲" : "▼";
         int chevronX = this.x + this.width - this.textPadding - Night.FONT_MANAGER.getWidth(chevron);
         Night.FONT_MANAGER.drawTextWithShadow(context, chevron, chevronX, this.y + 2, new Color(255, 255, 255, 180));
      }

      float frameOpenAmount = this.openAnim.get(this.open ? 1.0F : 0.0F);
      int fullContentHeight = this.baseContentHeight;
      int revealHeight = Math.round(fullContentHeight * frameOpenAmount);
      int bottomMargin = 4;
      if (revealHeight > 0) {
         int clipTop = this.y + this.height;
         int clipBottom = clipTop + revealHeight + bottomMargin;
         context.enableScissor(this.x, clipTop, this.x + this.width, clipBottom);
         Renderer2D.renderQuad(context, this.x, this.y + this.height, this.x + this.width, clipBottom, new Color(14, 13, 20, 195));

         for (Button buttonx : this.buttons) {
            if (buttonx.isVisible()) {
               buttonx.render(context, mouseX, mouseY, delta);
            }
         }

         if (contentHeight > viewHeight && viewHeight > 0.0F && revealHeight > 10) {
            float scrollRange = contentHeight - viewHeight;
            float scrollRatio = Mth.clamp(-this.scrollOffset / scrollRange, 0.0F, 1.0F);
            int thumbH = Math.max(10, Math.round(revealHeight * (viewHeight / contentHeight)));
            int thumbY = clipTop + Math.round(scrollRatio * (revealHeight - thumbH));
            Renderer2D.renderQuad(
               context, this.x + this.width - 3, thumbY, this.x + this.width - 1, thumbY + thumbH, ClickGuiScreen.getButtonColor(this.y, 160)
            );
         }

         context.disableScissor();
      }

      Color borderColor = ClickGuiScreen.getButtonColor(this.y, 130);
      int borderBottom = this.open ? this.y + this.height + revealHeight + bottomMargin : this.y + this.height;
      Renderer2D.renderOutline(context, this.x, this.y, this.x + this.width, borderBottom, borderColor);
   }

   private String getCategoryIcon() {
      if (this.category == null) {
         return "✦";
      } else {
         return switch (this.category) {
            case COMBAT -> "⚔";
            case MOVEMENT -> "⚡";
            case VISUALS -> "◉";
            case PLAYER -> "♟";
            case MISCELLANEOUS -> "⚙";
            case CORE -> "◆";
            default -> "♚";
         };
      }
   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovering(mouseX, mouseY)) {
         if (button == 0) {
            this.dragging = true;
            this.dragX = (int)(mouseX - this.getX());
            this.dragY = (int)(mouseY - this.getY());
         } else if (button == 1) {
            boolean clipTop = this.open = !this.open;
         }
      }

      if (this.open) {
         int clipTop = this.y + this.height;
         int clipBottom = clipTop + Math.round(this.baseContentHeight * this.openAnim.get(this.open ? 1.0F : 0.0F)) + 4;
         if (mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= clipTop && mouseY <= clipBottom) {
            for (Button b : this.buttons) {
               if (b.isVisible()) {
                  b.mouseClicked(mouseX, mouseY, button);
               }
            }
         }
      }
   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
      if (button == 0) {
         this.dragging = false;
      }

      for (Button b : this.buttons) {
         if (b.isVisible()) {
            b.mouseReleased(mouseX, mouseY, button);
         }
      }
   }

   public void mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      int clipTop = this.y;
      int clipBottom = this.y + this.height + (this.open ? Math.round(this.baseContentHeight * this.openAnim.get(this.open ? 1.0F : 0.0F)) + 4 : 0);
      if (mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= clipTop && mouseY <= clipBottom) {
         boolean whitelistHandling = false;

         for (Button b : this.buttons) {
            ExpandableRow row;
            if (b instanceof ExpandableRow && (row = (ExpandableRow)b).isOpen()) {
               for (Button whitelistButton : row.getButtons().stream().filter(button -> button instanceof WhitelistButton).toList()) {
                  WhitelistButton wb;
                  if (whitelistButton instanceof WhitelistButton && (wb = (WhitelistButton)whitelistButton).isHandlingScroll(mouseX, mouseY)) {
                     wb.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
                     whitelistHandling = true;
                     break;
                  }
               }
            }
         }

         if (!whitelistHandling && verticalAmount != 0.0) {
            float scrollSpeed = Night.MODULE_MANAGER.getModule(ClickGuiModule.class).scrollSpeed.getValue().floatValue();
            this.baseContentHeight = Math.max(
               this.baseContentHeight,
               Math.min(this.totalHeight - this.height - 1, Minecraft.getInstance().getWindow().getGuiScaledHeight() - this.y - this.height - 10)
            );
            float contentHeight = this.totalHeight - this.height - 1;
            float viewHeight = this.baseContentHeight;
            float maxScroll = 0.0F;
            float minScroll = -Math.max(0.0F, contentHeight - viewHeight);
            float scrollStep = (float)(verticalAmount * scrollSpeed * 12.0);
            float resistance = 1.0F;
            if (this.targetScroll > maxScroll) {
               resistance = 1.0F / (1.0F + (this.targetScroll - maxScroll) * 0.05F);
            } else if (this.targetScroll < minScroll) {
               resistance = 1.0F / (1.0F + (minScroll - this.targetScroll) * 0.05F);
            }

            this.targetScroll += scrollStep * resistance;
         }
      }
   }

   public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      for (Button b : this.buttons) {
         b.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
      }
   }

   public void keyPressed(int keyCode, int scanCode, int modifiers) {
      if (this.open) {
         for (Button button : this.buttons) {
            if (button.isVisible()) {
               button.keyPressed(keyCode, scanCode, modifiers);
            }
         }
      }
   }

   public void charTyped(char chr, int modifiers) {
      if (this.open) {
         for (Button button : this.buttons) {
            if (button.isVisible()) {
               button.charTyped(chr, modifiers);
            }
         }
      }
   }

   public boolean isHovering(double mouseX, double mouseY) {
      return this.x <= mouseX && this.y <= mouseY && this.x + this.width > mouseX && this.y + this.height > mouseY;
   }

   @Generated
   public Module.Category getCategory() {
      return this.category;
   }

   @Generated
   public String getHeaderLabel() {
      return this.headerLabel;
   }

   @Generated
   public int getX() {
      return this.x;
   }

   @Generated
   public int getY() {
      return this.y;
   }

   @Generated
   public int getWidth() {
      return this.width;
   }

   @Generated
   public int getHeight() {
      return this.height;
   }

   @Generated
   public int getTotalHeight() {
      return this.totalHeight;
   }

   @Generated
   public int getBaseContentHeight() {
      return this.baseContentHeight;
   }

   @Generated
   public int getDragX() {
      return this.dragX;
   }

   @Generated
   public int getDragY() {
      return this.dragY;
   }

   @Generated
   public int getTextPadding() {
      return this.textPadding;
   }

   @Generated
   public boolean isOpen() {
      return this.open;
   }

   @Generated
   public boolean isDragging() {
      return this.dragging;
   }

   @Generated
   public ArrayList<Button> getButtons() {
      return this.buttons;
   }

   @Generated
   public float getScrollOffset() {
      return this.scrollOffset;
   }

   @Generated
   public float getTargetScroll() {
      return this.targetScroll;
   }

   @Generated
   public long getLastScrollTime() {
      return this.lastScrollTime;
   }

   @Generated
   public Animation getOpenAnim() {
      return this.openAnim;
   }

   @Generated
   public void setX(int x) {
      this.x = x;
   }

   @Generated
   public void setY(int y) {
      this.y = y;
   }

   @Generated
   public void setWidth(int width) {
      this.width = width;
   }

   @Generated
   public void setHeight(int height) {
      this.height = height;
   }

   @Generated
   public void setTotalHeight(int totalHeight) {
      this.totalHeight = totalHeight;
   }

   @Generated
   public void setBaseContentHeight(int baseContentHeight) {
      this.baseContentHeight = baseContentHeight;
   }

   @Generated
   public void setDragX(int dragX) {
      this.dragX = dragX;
   }

   @Generated
   public void setDragY(int dragY) {
      this.dragY = dragY;
   }

   @Generated
   public void setTextPadding(int textPadding) {
      this.textPadding = textPadding;
   }

   @Generated
   public void setOpen(boolean open) {
      this.open = open;
   }

   @Generated
   public void setDragging(boolean dragging) {
      this.dragging = dragging;
   }

   @Generated
   public void setScrollOffset(float scrollOffset) {
      this.scrollOffset = scrollOffset;
   }

   @Generated
   public void setTargetScroll(float targetScroll) {
      this.targetScroll = targetScroll;
   }

   @Generated
   public void setLastScrollTime(long lastScrollTime) {
      this.lastScrollTime = lastScrollTime;
   }
}
