package night.gui;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;

public class PeekMenu extends ChestMenu {
   public PeekMenu(int containerId, Inventory playerInventory, Container container) {
      super(MenuType.GENERIC_9x3, containerId, playerInventory, container, 3);
   }

   public void clicked(int slotId, int button, ContainerInput type, Player player) {
   }

   public ItemStack quickMoveStack(Player player, int index) {
      return ItemStack.EMPTY;
   }
}
