package night.gui.screens.account;

import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import night.Night;
import night.accounts.Account;
import night.modules.impl.core.ClickGuiModule;
import night.utils.graphics.Renderer2D;

public class AccountManagerScreen extends Screen {
   private final Screen parent;
   private Account selectedAccount = null;
   private float scrollOffset = 0.0F;
   private float targetScroll = 0.0F;
   private String statusMessage = "";
   private long statusMessageTime = 0L;
   private long lastClickTime = 0L;
   private Account lastClickedAccount = null;
   private final Map<Account, Float> hoverAnimations = new HashMap<>();
   private Button loginButton;
   private Button deleteButton;

   public AccountManagerScreen(Screen parent) {
      super(Component.literal("Account Manager"));
      this.parent = parent;
   }

   protected void init() {
      int centerX = this.width / 2;
      int listBottom = this.height - 55;
      this.loginButton = Button.builder(Component.literal("Login"), button -> this.loginSelected()).bounds(centerX - 160, listBottom, 102, 20).build();
      this.addRenderableWidget(this.loginButton);
      this.addRenderableWidget(
         Button.builder(Component.literal("Add Microsoft"), button -> Minecraft.getInstance().gui.setScreen(new MicrosoftLoginScreen(this)))
            .bounds(centerX - 52, listBottom, 104, 20)
            .build()
      );
      this.addRenderableWidget(
         Button.builder(Component.literal("Add Offline"), button -> Minecraft.getInstance().gui.setScreen(new AddOfflineAccountScreen(this)))
            .bounds(centerX + 58, listBottom, 102, 20)
            .build()
      );
      this.addRenderableWidget(Button.builder(Component.literal("Random Offline"), button -> {
         String[] prefixes = new String[]{"Shadow", "xnhau", "Ghost", "Viper", "Phantom", "Raven", "Frost", "Nova", "Dark", "Storm"};
         String randomName = prefixes[new Random().nextInt(prefixes.length)] + "_" + (100 + new Random().nextInt(900));
         this.selectedAccount = Night.ACCOUNT_MANAGER.loginOffline(randomName);
         this.setStatus("Logged in as " + randomName);
      }).bounds(centerX - 160, listBottom + 25, 102, 20).build());
      this.deleteButton = Button.builder(Component.literal("Delete"), button -> {
         if (this.selectedAccount != null) {
            Night.ACCOUNT_MANAGER.removeAccount(this.selectedAccount);
            this.selectedAccount = null;
            this.setStatus("Account deleted");
         }
      }).bounds(centerX - 52, listBottom + 25, 104, 20).build();
      this.addRenderableWidget(this.deleteButton);
      this.addRenderableWidget(Button.builder(Component.literal("Back"), button -> this.onClose()).bounds(centerX + 58, listBottom + 25, 102, 20).build());
      this.updateButtonStates();
   }

   private void loginSelected() {
      if (this.selectedAccount != null) {
         this.setStatus("Logging in to " + this.selectedAccount.getName() + "...");
         CompletableFuture.runAsync(() -> {
            boolean success = Night.ACCOUNT_MANAGER.login(this.selectedAccount);
            if (success) {
               this.setStatus("Logged in as " + this.selectedAccount.getName());
            } else {
               this.setStatus("§cFailed to login to " + this.selectedAccount.getName());
            }
         });
      }
   }

   private void updateButtonStates() {
      if (this.loginButton != null) {
         boolean var1 = this.loginButton.active = this.selectedAccount != null;
      }

      if (this.deleteButton != null) {
         this.deleteButton.active = this.selectedAccount != null;
      }
   }

   private void setStatus(String message) {
      this.statusMessage = message;
      this.statusMessageTime = System.currentTimeMillis();
   }

   public void extractBackground(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
      Renderer2D.renderGradient(context, 0.0F, 0.0F, this.width, this.height, new Color(24, 24, 24), new Color(12, 12, 12));
   }

   public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
      int centerX = this.width / 2;
      String title = "Account Manager";
      Night.FONT_MANAGER.drawTextWithShadow(context, title, centerX - Night.FONT_MANAGER.getWidth(title) / 2, 12, Color.WHITE);
      String currentName = Night.ACCOUNT_MANAGER.getCurrentName();
      if (System.currentTimeMillis() - this.statusMessageTime < 5000L && !this.statusMessage.isEmpty()) {
         Color statusColor = this.statusMessage.startsWith("§c")
            ? new Color(255, 100, 100)
            : (this.statusMessage.startsWith("Logging") ? new Color(200, 200, 200) : new Color(255, 255, 100));
         Night.FONT_MANAGER.drawTextWithShadow(context, this.statusMessage, centerX - Night.FONT_MANAGER.getWidth(this.statusMessage) / 2, 28, statusColor);
      } else {
         String currentAccountStr = "Logged in as: §f" + currentName;
         Night.FONT_MANAGER
            .drawTextWithShadow(context, currentAccountStr, centerX - Night.FONT_MANAGER.getWidth(currentAccountStr) / 2, 28, new Color(180, 180, 180));
      }

      int listX = centerX - 160;
      int listY = 55;
      int listW = 320;
      int listH = this.height - 120;
      Renderer2D.renderQuad(context, listX, listY, listX + listW, listY + listH, new Color(24, 24, 24, 230));
      Renderer2D.renderOutline(context, listX, listY, listX + listW, listY + listH, new Color(60, 60, 60, 160));
      this.scrollOffset = this.scrollOffset + (this.targetScroll - this.scrollOffset) * 0.3F;
      List<Account> accounts = Night.ACCOUNT_MANAGER.getAccounts();
      int entryH = 32;
      int maxScroll = Math.max(0, accounts.size() * entryH - listH);
      this.targetScroll = Mth.clamp(this.targetScroll, -maxScroll, 0.0F);
      context.enableScissor(listX, listY, listX + listW, listY + listH);
      float yPos = listY + this.scrollOffset;

      for (Account account : accounts) {
         if (yPos + entryH >= listY && yPos <= listY + listH) {
            boolean isSelected = account == this.selectedAccount;
            boolean isCurrent = account.getName().equalsIgnoreCase(currentName);
            boolean isHovered = mouseX >= listX + 4
               && mouseX <= listX + listW - 4
               && mouseY >= yPos + 2.0F
               && mouseY <= yPos + entryH - 2.0F
               && mouseY >= listY
               && mouseY <= listY + listH;
            float targetHover = isHovered ? 1.0F : 0.0F;
            float currentHover = this.hoverAnimations.getOrDefault(account, 0.0F);
            if (Math.abs(targetHover - (currentHover = currentHover + (targetHover - currentHover) * 0.22F)) < 0.005F) {
               currentHover = targetHover;
            }

            this.hoverAnimations.put(account, currentHover);
            Color bg = isSelected ? new Color(50, 50, 50, 220) : (isCurrent ? new Color(40, 40, 40, 180) : new Color(30, 30, 30, 150));
            Renderer2D.renderQuad(context, listX + 4, yPos + 2.0F, listX + listW - 4, yPos + entryH - 2.0F, bg);
            Color accent = this.getAccentColor();
            if (currentHover > 0.001F) {
               float fillWidth = (listW - 8) * currentHover;
               Color slideStart = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), (int)(90.0F * currentHover));
               Color slideEnd = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), (int)(20.0F * currentHover));
               Renderer2D.renderSidewaysGradient(context, listX + 4, yPos + 2.0F, listX + 4 + fillWidth, yPos + entryH - 2.0F, slideStart, slideEnd);
               Color leadingEdge = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), (int)(200.0F * currentHover));
               Renderer2D.renderQuad(context, listX + 3 + fillWidth, yPos + 2.0F, listX + 5 + fillWidth, yPos + entryH - 2.0F, leadingEdge);
            }

            float pillAlpha = isSelected ? 1.0F : currentHover;
            if (pillAlpha > 0.001F) {
               float pillWidth = isSelected ? 3.5F : 3.0F * currentHover;
               Color pillColor = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), (int)(255.0F * pillAlpha));
               Renderer2D.renderQuad(context, listX + 4, yPos + 2.0F, listX + 4 + pillWidth, yPos + entryH - 2.0F, pillColor);
            }

            float textSlideOffset = 3.0F * currentHover;
            String nameStr = (isCurrent ? "§a✓ " : "") + account.getName();
            Night.FONT_MANAGER
               .drawTextWithShadow(context, nameStr, (int)(listX + 14 + textSlideOffset), (int)(yPos + 6.0F), isCurrent ? Color.GREEN : Color.WHITE);
            String typeStr = "[" + account.getType().getDisplayName() + "]";

            Color typeColor = switch (account.getType()) {
               case MICROSOFT -> new Color(0, 220, 255);
               case OFFLINE -> new Color(255, 200, 80);
               case SESSION -> new Color(220, 120, 255);
            };
            Night.FONT_MANAGER.drawTextWithShadow(context, typeStr, (int)(listX + 14 + textSlideOffset), (int)(yPos + 18.0F), typeColor);
            if (isCurrent) {
               String activeStr = "§aACTIVE";
               Night.FONT_MANAGER
                  .drawTextWithShadow(context, activeStr, listX + listW - Night.FONT_MANAGER.getWidth(activeStr) - 12, (int)(yPos + 11.0F), Color.GREEN);
            }
         }

         yPos += entryH;
      }

      context.disableScissor();
      if (accounts.isEmpty()) {
         String emptyStr = "No saved accounts. Click 'Add Offline' or 'Add Microsoft' below.";
         Night.FONT_MANAGER
            .drawTextWithShadow(context, emptyStr, centerX - Night.FONT_MANAGER.getWidth(emptyStr) / 2, listY + listH / 2 - 5, new Color(140, 140, 160));
      }

      this.updateButtonStates();
      super.extractRenderState(context, mouseX, mouseY, delta);
   }

   public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
      double mouseX = event.x();
      double mouseY = event.y();
      int button = event.button();
      int centerX = this.width / 2;
      int listX = centerX - 160;
      int listY = 55;
      int listW = 320;
      int listH = this.height - 120;
      if (button == 0 && mouseX >= listX && mouseX <= listX + listW && mouseY >= listY && mouseY <= listY + listH) {
         List<Account> accounts = Night.ACCOUNT_MANAGER.getAccounts();
         float relativeY = (float)(mouseY - listY - this.scrollOffset);
         int entryH = 32;
         int index = (int)(relativeY / entryH);
         if (index >= 0 && index < accounts.size()) {
            Account clicked = accounts.get(index);
            long now = System.currentTimeMillis();
            if (clicked != this.lastClickedAccount || now - this.lastClickTime >= 350L && !doubleClick) {
               this.selectedAccount = clicked;
            } else {
               this.selectedAccount = clicked;
               this.loginSelected();
            }

            this.lastClickedAccount = clicked;
            this.lastClickTime = now;
            this.updateButtonStates();
            return true;
         }
      }

      return super.mouseClicked(event, doubleClick);
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      List<Account> accounts = Night.ACCOUNT_MANAGER.getAccounts();
      int listH = this.height - 120;
      int entryH = 32;
      int maxScroll = Math.max(0, accounts.size() * entryH - listH);
      this.targetScroll += (float)(verticalAmount * 24.0);
      this.targetScroll = Mth.clamp(this.targetScroll, -maxScroll, 0.0F);
      return true;
   }

   private Color getAccentColor() {
      ClickGuiModule clickGui = Night.MODULE_MANAGER.getModule(ClickGuiModule.class);
      return clickGui != null ? clickGui.color.getColor() : new Color(130, 90, 240);
   }

   public void onClose() {
      Minecraft.getInstance().gui.setScreen(this.parent);
   }
}
