package night.gui.impl;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.Window;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import lombok.Generated;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.Util;
import net.minecraft.util.Util.OS;
import night.Night;
import night.gui.ClickGuiScreen;
import night.gui.WhitelistEditorScreen;
import night.gui.api.Button;
import night.gui.api.Frame;
import night.settings.impl.WhitelistSetting;
import night.utils.graphics.Renderer2D;
import night.utils.minecraft.IdentifierUtils;

public class WhitelistButton extends Button {
   private final WhitelistSetting setting;
   private boolean open = false;
   private String searchQuery = "";
   private boolean searching = false;
   private boolean selecting = false;
   private int cursorPos = 0;
   private String oldSearchQuery = "";
   private boolean draggingScrollbar = false;
   private int dragStartY = 0;
   private float dragStartScroll = 0.0F;
   private final List<String> allElements;
   private List<String> visibleElements = new ArrayList<>();
   private final int maxDisplayed = 6;
   private float scrollOffset = 0.0F;
   private float targetScrollOffset = 0.0F;
   private final int searchBarHeight = 12;
   private final int elementHeight = 12;
   private final int offsetX = 2;
   private final int scrollbarWidth = 5;
   private final int symbolWidth = 15;

   public WhitelistButton(WhitelistSetting setting, Frame parent, int height) {
      super(setting, parent, height, setting.getDescription());
      this.setting = setting;
      this.allElements = this.getAllElements();
   }

   @Override
   public void render(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
      boolean queryChanged = !this.searchQuery.equals(this.oldSearchQuery);
      this.oldSearchQuery = this.searchQuery;
      float ratio = 0.0F;
      if (queryChanged) {
         ratio = this.getScrollRatio();
      }

      this.updateVisibleElements();
      this.clampScrollValues();
      if (queryChanged) {
         this.applyScrollRatio(ratio);
         this.clampScrollValues();
      }

      this.scrollOffset = this.scrollOffset + (this.targetScrollOffset - this.scrollOffset) * 0.5F;
      Renderer2D.renderQuad(
         context,
         this.getX() + this.getPadding() + 1,
         this.getY(),
         this.getX() + this.getWidth() - this.getPadding() - 1,
         this.getY() + 13 - 1,
         ClickGuiScreen.getButtonColor(this.getY(), 100)
      );
      Renderer2D.renderQuad(
         context,
         this.getX() + this.getPadding() + 1,
         this.getY(),
         this.getX() + this.getPadding() + 2,
         this.getY() + this.getHeight() - 1,
         ClickGuiScreen.getButtonColor(this.getY(), 30)
      );
      Night.FONT_MANAGER.drawTextWithShadow(context, this.setting.getTag(), this.getX() + this.getTextPadding() + 1, this.getY() + 2, Color.WHITE);
      Night.FONT_MANAGER
         .drawTextWithShadow(
            context,
            "" + ChatFormatting.GRAY + this.setting.getWhitelist().size(),
            this.getX() + this.getWidth() - this.getTextPadding() - 1 - Night.FONT_MANAGER.getWidth(this.setting.getWhitelist().size() + ""),
            this.getY() + 2,
            Color.WHITE
         );
      if (this.open) {
         int contentY = this.getY() + this.getParent().getHeight();
         Renderer2D.renderQuad(
            context,
            this.getX() + this.getPadding() + 1 + 2,
            contentY,
            this.getX() + this.getWidth() - this.getPadding() - 1,
            contentY + 12,
            ClickGuiScreen.getButtonColor(this.getY(), 30)
         );
         Object displayedSearch = this.searchQuery;
         if (this.searching) {
            String cursorChar = Night.CLICK_GUI.isShowLine() ? "|" : " ";
            if (this.cursorPos <= ((String)displayedSearch).length()) {
               displayedSearch = ((String)displayedSearch).substring(0, this.cursorPos) + cursorChar + ((String)displayedSearch).substring(this.cursorPos);
            }
         } else {
            displayedSearch = "Search...";
         }

         if (this.searching && this.searchQuery.isEmpty()) {
            String cursorChar = Night.CLICK_GUI.isShowLine() ? "|" : " ";
            Night.FONT_MANAGER
               .drawTextWithShadow(
                  context, cursorChar, this.getX() + this.getTextPadding() + 2 + 2, contentY + 6 - Night.FONT_MANAGER.getHeight() / 2, Color.WHITE
               );
            Night.FONT_MANAGER
               .drawTextWithShadow(
                  context,
                  "Search...",
                  this.getX() + this.getTextPadding() + 2 + 2 + Night.FONT_MANAGER.getWidth(" "),
                  contentY + 6 - Night.FONT_MANAGER.getHeight() / 2,
                  Color.GRAY
               );
         } else {
            Night.FONT_MANAGER
               .drawTextWithShadow(
                  context,
                  (String)displayedSearch,
                  this.getX() + this.getTextPadding() + 2 + 2,
                  contentY + 6 - Night.FONT_MANAGER.getHeight() / 2,
                  this.searching ? (this.selecting ? ClickGuiScreen.getButtonColor(this.getY(), 255) : Color.WHITE) : Color.GRAY
               );
         }

         int listStartY = contentY + 12;
         int renderCount = Math.min(this.visibleElements.size(), 6);
         int scrollbarX = this.getX() + this.getWidth() - this.getPadding() - 5 - 1;
         int scrollbarFullHeight = 72;
         List<String> whitelistIds = this.setting.getWhitelistIds();
         String[] words = this.searchQuery.isEmpty() ? new String[0] : this.searchQuery.toLowerCase().split(" ");

         for (int i = 0; i < renderCount; i++) {
            int index = (int)(i + this.scrollOffset);
            if (index >= 0 && index < this.visibleElements.size()) {
               String registryId = this.visibleElements.get(index);
               boolean inWhitelist = whitelistIds.contains(registryId);
               String renderText = registryId.replace("minecraft:", "");
               Color normalColor = inWhitelist ? Color.WHITE : Color.GRAY;
               Color highlightColor = inWhitelist ? Color.YELLOW : Color.LIGHT_GRAY;
               int itemY = listStartY + i * 12;
               Renderer2D.renderQuad(
                  context,
                  this.getX() + this.getPadding() + 1 + 2,
                  itemY,
                  this.getX() + this.getWidth() - this.getPadding() - 1,
                  itemY + 12,
                  ClickGuiScreen.getButtonColor(this.getY(), 30)
               );
               int textX = this.getX() + this.getTextPadding() + 2 + 2;
               int symbolX = scrollbarX - 15 + 5;
               boolean textHovered = mouseX >= textX && mouseX <= symbolX && mouseY >= itemY && mouseY < itemY + 12;
               List<WhitelistButton.ColoredSegment> segments = this.highlightMatches(renderText, words, normalColor, highlightColor);
               int textWidth = 0;

               for (WhitelistButton.ColoredSegment seg : segments) {
                  textWidth += Night.FONT_MANAGER.getWidth(seg.text);
               }

               int availableSpace = symbolX - textX;
               List<WhitelistButton.ColoredSegment> drawSegments = !textHovered && textWidth > availableSpace
                  ? this.truncateSegments(segments, availableSpace)
                  : segments;
               int drawX = textX;

               for (WhitelistButton.ColoredSegment seg : drawSegments) {
                  Night.FONT_MANAGER.drawTextWithShadow(context, seg.text, drawX, itemY + 2, seg.color);
                  drawX += Night.FONT_MANAGER.getWidth(seg.text);
               }

               String symbol = this.searching && !inWhitelist ? "+" : "-";
               int symbolRenderX = scrollbarX - 15 + 5;
               boolean symbolHovered = mouseX >= symbolRenderX && mouseX <= symbolRenderX + 15 && mouseY >= itemY && mouseY < itemY + 12;
               Color symbolColor = symbol.equals("+")
                  ? (symbolHovered ? new Color(0, 255, 0) : Color.WHITE)
                  : (symbolHovered ? new Color(255, 0, 0) : Color.WHITE);
               Night.FONT_MANAGER.drawTextWithShadow(context, symbol, symbolRenderX, itemY + 2, symbolColor);
            }
         }

         if (this.visibleElements.size() > 6) {
            float maxScroll = Math.max(0, this.visibleElements.size() - 6);
            float scrollPercent = maxScroll == 0.0F ? 0.0F : this.scrollOffset / maxScroll;
            int barHeight = (int)(scrollbarFullHeight * (6.0F / this.visibleElements.size()));
            if (barHeight < 20) {
               barHeight = 20;
            }

            int scrollbarPos = (int)((scrollbarFullHeight - barHeight) * scrollPercent);
            Renderer2D.renderQuad(
               context, scrollbarX, listStartY, scrollbarX + 5, listStartY + scrollbarFullHeight, ClickGuiScreen.getButtonColor(this.getY(), 40)
            );
            Renderer2D.renderQuad(
               context,
               scrollbarX,
               listStartY + scrollbarPos,
               scrollbarX + 5,
               listStartY + scrollbarPos + barHeight,
               ClickGuiScreen.getButtonColor(this.getY(), 200)
            );
         }
      }
   }

   @Override
   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovering(mouseX, mouseY) && button == 1) {
         boolean relativeY = this.open = !this.open;
      }

      if (!this.isHovering(mouseX, mouseY) || button != 0 || this.open && !(mouseY < this.getY() + this.getParent().getHeight())) {
         if (this.open) {
            if (button == 0) {
               int contentY = this.getY() + this.getParent().getHeight();
               if (mouseX >= this.getX() + this.getPadding() + 1 + 2
                  && mouseX <= this.getX() + this.getWidth() - this.getPadding() - 1
                  && mouseY >= contentY
                  && mouseY <= contentY + 12) {
                  this.searching = true;
                  this.selecting = false;
                  this.cursorPos = this.searchQuery.length();
                  return;
               }

               if (!this.isWithinOpenArea(mouseX, mouseY)) {
                  this.searching = false;
                  this.selecting = false;
                  this.searchQuery = "";
                  this.cursorPos = 0;
               }

               if (this.visibleElements.size() > 6 && this.isHoveringScrollbar(mouseX, mouseY)) {
                  this.draggingScrollbar = true;
                  this.dragStartY = (int)mouseY;
                  this.dragStartScroll = this.scrollOffset;
                  return;
               }

               if (!this.isWithinOpenArea(mouseX, mouseY)) {
                  return;
               }

               int contentAreaX1 = this.getX() + this.getPadding() + 1 + 2;
               int contentAreaX2 = this.getX() + this.getWidth() - this.getPadding() - 1;
               if (mouseX < contentAreaX1 || mouseX > contentAreaX2) {
                  return;
               }

               int contentYArea = this.getY() + this.getParent().getHeight();
               int listStartY = contentYArea + 12;
               int index;
               int relativeY;
               if (mouseY >= listStartY
                  && mouseY < listStartY + 72
                  && (index = (int)this.scrollOffset + (relativeY = (int)(mouseY - listStartY)) / 12) >= 0
                  && index < this.visibleElements.size()) {
                  String registryId = this.visibleElements.get(index);
                  int scrollbarX = this.getX() + this.getWidth() - this.getPadding() - 5 - 1;
                  int symbolX = scrollbarX - 15 + 5;
                  int itemY = listStartY + relativeY / 12 * 12;
                  if (mouseX >= symbolX && mouseX <= symbolX + 15 && mouseY >= itemY && mouseY < itemY + 12) {
                     boolean inWhitelist = this.setting.getWhitelistIds().contains(registryId);
                     if (inWhitelist) {
                        if (this.setting.getType() == WhitelistSetting.Type.BLOCKS) {
                           this.setting.remove(IdentifierUtils.getBlock(registryId));
                        } else {
                           this.setting.remove(IdentifierUtils.getItem(registryId));
                        }

                        this.setting.remove(registryId);
                     } else if (this.setting.getType() == WhitelistSetting.Type.BLOCKS) {
                        this.setting.add(IdentifierUtils.getBlock(registryId));
                     } else {
                        this.setting.add(IdentifierUtils.getItem(registryId));
                     }
                  }
               }
            }
         }
      } else {
         mc.gui.setScreen(new WhitelistEditorScreen(this.setting, mc.gui.screen()));
      }
   }

   @Override
   public void mouseReleased(double mouseX, double mouseY, int button) {
      if (button == 0 && this.draggingScrollbar) {
         this.draggingScrollbar = false;
      }
   }

   @Override
   public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (this.draggingScrollbar && this.visibleElements.size() > 6) {
         int scrollbarFullHeight = 72;
         float maxScroll = Math.max(0, this.visibleElements.size() - 6);
         float dy = (float)(mouseY - this.dragStartY);
         float ratio = dy / scrollbarFullHeight;
         this.targetScrollOffset = this.dragStartScroll + maxScroll * ratio;
         this.clampScrollValues();
      }
   }

   @Override
   public void mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      if (this.open && this.isWithinOpenArea(mouseX, mouseY)) {
         this.targetScrollOffset -= (float)verticalAmount;
         this.clampScrollValues();
      }
   }

   @Override
   public void keyPressed(int keyCode, int scanCode, int modifiers) {
      if (this.searching) {
         Window handle = mc.getWindow();
         boolean ctrlPressed = InputConstants.isKeyDown(handle, Util.getPlatform() == OS.OSX ? 343 : 341);
         if (keyCode == 256) {
            this.searching = false;
            this.selecting = false;
            this.searchQuery = "";
            this.cursorPos = 0;
         } else if (keyCode == 257) {
            this.searching = false;
            this.selecting = false;
            this.searchQuery = "";
            this.cursorPos = 0;
         } else if (keyCode == 259) {
            if (this.selecting) {
               this.searchQuery = "";
               this.cursorPos = 0;
               this.selecting = false;
            } else if (this.cursorPos > 0) {
               this.searchQuery = this.searchQuery.substring(0, this.cursorPos - 1) + this.searchQuery.substring(this.cursorPos);
               this.cursorPos--;
            }
         } else if (keyCode == 261) {
            if (this.cursorPos < this.searchQuery.length()) {
               this.searchQuery = this.searchQuery.substring(0, this.cursorPos) + this.searchQuery.substring(this.cursorPos + 1);
            }
         } else if (keyCode == 263) {
            if (this.cursorPos > 0) {
               this.cursorPos--;
            }
         } else if (keyCode == 262) {
            if (this.cursorPos < this.searchQuery.length()) {
               this.cursorPos++;
            }
         } else if (ctrlPressed) {
            if (keyCode == 86) {
               try {
                  String clip = mc.keyboardHandler.getClipboard();
                  if (clip != null) {
                     this.searchQuery = this.searchQuery.substring(0, this.cursorPos) + clip + this.searchQuery.substring(this.cursorPos);
                     this.cursorPos = this.cursorPos + clip.length();
                  }
               } catch (Exception var8) {
                  Night.LOGGER.error("{}: Failed to process clipboard paste", var8.getClass().getName(), var8);
               }
            } else if (keyCode == 67 && this.selecting) {
               try {
                  mc.keyboardHandler.setClipboard(this.searchQuery);
               } catch (Exception var7) {
                  Night.LOGGER.error("{}: Failed to process clipboard change", var7.getClass().getName(), var7);
               }
            } else if (keyCode == 65) {
               this.selecting = true;
               this.cursorPos = this.searchQuery.length();
            }
         }
      }
   }

   @Override
   public void charTyped(char chr, int modifiers) {
      if (this.searching && !Character.isISOControl(chr)) {
         if (this.selecting) {
            this.searchQuery = String.valueOf(chr);
            this.selecting = false;
            this.cursorPos = 1;
         } else {
            this.searchQuery = this.searchQuery.substring(0, this.cursorPos) + chr + this.searchQuery.substring(this.cursorPos);
            this.cursorPos++;
         }
      }
   }

   @Override
   public int getHeight() {
      int baseHeight = this.getParent().getHeight();
      return !this.open ? baseHeight : baseHeight + 12 + 72;
   }

   @Override
   public boolean isHovering(double mouseX, double mouseY) {
      return this.getX() + this.getPadding() <= mouseX
         && this.getY() <= mouseY
         && this.getX() + this.getWidth() - this.getPadding() > mouseX
         && this.getY() + this.getParent().getHeight() > mouseY;
   }

   public boolean isHandlingScroll(double mouseX, double mouseY) {
      return this.open && (this.isWithinOpenArea(mouseX, mouseY) || this.draggingScrollbar);
   }

   private boolean isWithinOpenArea(double mouseX, double mouseY) {
      int contentY = this.getY() + this.getParent().getHeight();
      int maxAreaHeight = 84;
      return mouseX >= this.getX() + this.getPadding() + 1 + 2
         && mouseX <= this.getX() + this.getWidth() - this.getPadding() - 1
         && mouseY >= contentY
         && mouseY <= contentY + maxAreaHeight;
   }

   private boolean isHoveringScrollbar(double mouseX, double mouseY) {
      if (this.open && this.visibleElements.size() > 6) {
         int contentY = this.getY() + this.getParent().getHeight();
         int listStartY = contentY + 12;
         int scrollbarX = this.getX() + this.getWidth() - this.getPadding() - 5 - 1;
         int scrollbarHeight = 72;
         return mouseX >= scrollbarX && mouseX <= scrollbarX + 5 && mouseY >= listStartY && mouseY <= listStartY + scrollbarHeight;
      } else {
         return false;
      }
   }

   private void updateVisibleElements() {
      List<String> baseList;
      if (this.searchQuery.isEmpty()) {
         if (this.searching) {
            baseList = new ArrayList<>(this.allElements);
         } else {
            List<String> whitelistIds = this.setting.getWhitelistIds();
            baseList = this.allElements.stream().filter(whitelistIds::contains).collect(Collectors.toList());
         }

         baseList.sort((id1, id2) -> {
            int cmp = id1.compareToIgnoreCase(id2);
            return cmp == 0 ? Integer.compare(id1.length(), id2.length()) : cmp;
         });
      } else {
         String[] words = this.searchQuery.toLowerCase().split(" ");
         baseList = this.allElements.stream().filter(id -> {
            String lower = id.toLowerCase();

            for (String w : words) {
               if (!w.isEmpty() && !lower.contains(w)) {
                  return false;
               }
            }

            return true;
         }).collect(Collectors.toList());
         baseList.sort((id1, id2) -> {
            int compare = this.compareBySearchPriority(id1, id2, words);
            if (compare != 0) {
               return compare;
            } else {
               int cmp = id1.compareToIgnoreCase(id2);
               return cmp == 0 ? Integer.compare(id1.length(), id2.length()) : cmp;
            }
         });
      }

      this.visibleElements = baseList;
   }

   private int compareBySearchPriority(String id1, String id2, String[] words) {
      int startCount1 = this.countStarts(id1, words);
      int startCount2 = this.countStarts(id2, words);
      return Integer.compare(startCount1, startCount2);
   }

   private int countStarts(String id, String[] words) {
      int count = id.length();
      String lower = id.toLowerCase();

      for (String w : words) {
         int c;
         if (!w.isEmpty() && lower.contains(w.toLowerCase()) && (c = lower.split(w.toLowerCase())[0].length()) < count) {
            count = c;
         }
      }

      return count;
   }

   private float getScrollRatio() {
      int maxSize = this.visibleElements.size();
      int maxScroll = Math.max(0, maxSize - 6);
      return maxScroll == 0 ? 0.0F : this.scrollOffset / maxScroll;
   }

   private void applyScrollRatio(float ratio) {
      int maxSize = this.visibleElements.size();
      int maxScroll = Math.max(0, maxSize - 6);
      float newOffset;
      this.scrollOffset = newOffset = ratio * maxScroll;
      this.targetScrollOffset = newOffset;
   }

   private void clampScrollValues() {
      int maxSize = this.visibleElements.size();
      int maxScroll = Math.max(0, maxSize - 6);
      if (this.targetScrollOffset < 0.0F) {
         this.targetScrollOffset = 0.0F;
      }

      if (this.targetScrollOffset > maxScroll) {
         this.targetScrollOffset = maxScroll;
      }

      if (this.scrollOffset < 0.0F) {
         this.scrollOffset = 0.0F;
      }

      if (this.scrollOffset > maxScroll) {
         this.scrollOffset = maxScroll;
      }
   }

   private List<String> getAllElements() {
      ArrayList<String> temp = new ArrayList<>();
      if (this.setting.getType() == WhitelistSetting.Type.BLOCKS) {
         BuiltInRegistries.BLOCK.entrySet().forEach(e -> temp.add(((ResourceKey)e.getKey()).identifier().toString()));
      } else {
         BuiltInRegistries.ITEM.entrySet().forEach(e -> temp.add(((ResourceKey)e.getKey()).identifier().toString()));
      }

      temp.sort((a, b) -> {
         int cmp = a.compareToIgnoreCase(b);
         return cmp == 0 ? Integer.compare(a.length(), b.length()) : cmp;
      });
      return temp;
   }

   private List<WhitelistButton.ColoredSegment> truncateSegments(List<WhitelistButton.ColoredSegment> segments, int maxWidth) {
      ArrayList<WhitelistButton.ColoredSegment> truncated = new ArrayList<>();
      int currentWidth = 0;

      for (WhitelistButton.ColoredSegment seg : segments) {
         int segWidth = Night.FONT_MANAGER.getWidth(seg.text);
         if (currentWidth + segWidth > maxWidth) {
            int spaceLeft = maxWidth - currentWidth;
            if (spaceLeft > 0) {
               StringBuilder sb = new StringBuilder();

               char c;
               int charWidth;
               for (int i = 0;
                  i < seg.text.length()
                     && (charWidth = Night.FONT_MANAGER.getWidth(String.valueOf(c = seg.text.charAt(i)))) <= spaceLeft - Night.FONT_MANAGER.getWidth("…");
                  i++
               ) {
                  sb.append(c);
                  spaceLeft -= charWidth;
               }

               sb.append("…");
               truncated.add(new WhitelistButton.ColoredSegment(sb.toString(), seg.color));
            } else {
               truncated.add(new WhitelistButton.ColoredSegment("…", Color.GRAY));
            }
            break;
         }

         truncated.add(seg);
         currentWidth += segWidth;
      }

      return truncated;
   }

   private List<WhitelistButton.ColoredSegment> highlightMatches(String text, String[] words, Color normalColor, Color highlightColor) {
      if (words.length == 0) {
         ArrayList<WhitelistButton.ColoredSegment> segments = new ArrayList<>();
         segments.add(new WhitelistButton.ColoredSegment(text, normalColor));
         return segments;
      } else {
         String lowerText = text.toLowerCase();
         List<WhitelistButton.Range> ranges = new ArrayList<>();

         for (String w : words) {
            if (!w.isEmpty()) {
               int start = 0;

               int idx;
               while ((idx = lowerText.indexOf(w, start)) != -1) {
                  ranges.add(new WhitelistButton.Range(idx, idx + w.length()));
                  start = idx + w.length();
               }
            }
         }

         ranges = this.mergeRanges(ranges);
         ArrayList<WhitelistButton.ColoredSegment> segments = new ArrayList<>();
         int currentIndex = 0;

         for (WhitelistButton.Range r : ranges) {
            if (r.start > currentIndex) {
               segments.add(new WhitelistButton.ColoredSegment(text.substring(currentIndex, r.start), normalColor));
            }

            segments.add(new WhitelistButton.ColoredSegment(text.substring(r.start, r.end), highlightColor));
            currentIndex = r.end;
         }

         if (currentIndex < text.length()) {
            segments.add(new WhitelistButton.ColoredSegment(text.substring(currentIndex), normalColor));
         }

         return segments;
      }
   }

   private List<WhitelistButton.Range> mergeRanges(List<WhitelistButton.Range> ranges) {
      if (ranges.isEmpty()) {
         return ranges;
      } else {
         ranges.sort(Comparator.comparingInt(r -> r.start));
         ArrayList<WhitelistButton.Range> merged = new ArrayList<>();
         WhitelistButton.Range current = ranges.getFirst();

         for (int i = 1; i < ranges.size(); i++) {
            WhitelistButton.Range next = ranges.get(i);
            if (next.start <= current.end) {
               current.end = Math.max(current.end, next.end);
            } else {
               merged.add(current);
               current = next;
            }
         }

         merged.add(current);
         return merged;
      }
   }

   private static class ColoredSegment {
      String text;
      Color color;

      @Generated
      public ColoredSegment(String text, Color color) {
         this.text = text;
         this.color = color;
      }
   }

   private static class Range {
      int start;
      int end;

      @Generated
      public Range(int start, int end) {
         this.start = start;
         this.end = end;
      }
   }
}
