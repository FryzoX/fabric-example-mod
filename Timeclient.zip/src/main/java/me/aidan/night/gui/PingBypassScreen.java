package night.gui;

import java.net.InetSocketAddress;
import java.net.Socket;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import night.Night;
import night.modules.impl.core.PingBypassModule;
import night.pingbypass.PingBypassConfig;
import night.pingbypass.PingBypassFlags;

public class PingBypassScreen extends Screen {
   private final Screen parent;
   private EditBox ipField;
   private EditBox portField;
   private EditBox passwordField;
   private EditBox serverField;
   private Button connectButton;
   private Button resumeButton;
   private volatile String proxyStatus = "Pinging...";
   private volatile boolean pinged = false;

   public PingBypassScreen(Screen parent) {
      super(Component.literal("PingBypass"));
      this.parent = parent;
   }

   protected void init() {
      int centerX = this.width / 2;
      int startY = 50;
      this.ipField = new EditBox(this.font, centerX - 150, startY, 300, 20, Component.literal("Proxy IP"));
      this.ipField.setMaxLength(256);
      this.ipField.setValue(this.getConfig().getIp());
      this.ipField.setHint(Component.literal("127.0.0.1"));
      this.addRenderableWidget(this.ipField);
      this.portField = new EditBox(this.font, centerX - 150, startY + 34, 145, 20, Component.literal("Port"));
      this.portField.setMaxLength(5);
      this.portField.setValue(String.valueOf(this.getConfig().getPort()));
      this.portField.setHint(Component.literal("25565"));
      this.addRenderableWidget(this.portField);
      this.passwordField = new EditBox(this.font, centerX + 5, startY + 34, 145, 20, Component.literal("Password"));
      this.passwordField.setMaxLength(64);
      this.passwordField.setValue(this.getConfig().getPassword());
      this.passwordField.setHint(Component.literal("Password"));
      this.addRenderableWidget(this.passwordField);
      this.serverField = new EditBox(this.font, centerX - 150, startY + 68, 300, 20, Component.literal("Target Server"));
      this.serverField.setMaxLength(256);
      String savedServer = Night.MODULE_MANAGER.getModule(PingBypassModule.class).server.getValue();
      this.serverField.setValue(savedServer.isEmpty() ? "" : savedServer);
      this.serverField.setHint(Component.literal("mc.server.com:25565"));
      this.addRenderableWidget(this.serverField);
      this.connectButton = Button.builder(Component.literal("Connect"), button -> this.connect()).bounds(centerX - 150, startY + 110, 300, 20).build();
      this.addRenderableWidget(this.connectButton);
      PingBypassModule pbModule = Night.MODULE_MANAGER.getModule(PingBypassModule.class);
      this.resumeButton = Button.builder(Component.literal("Resume Session"), button -> this.resume()).bounds(centerX - 150, startY + 138, 300, 20).build();
      this.resumeButton.active = pbModule != null && pbModule.isToggled();
      this.addRenderableWidget(this.resumeButton);
      this.addRenderableWidget(Button.builder(Component.literal("Back"), button -> this.onClose()).bounds(centerX - 150, this.height - 30, 300, 20).build());
      this.pingProxy();
   }

   private void pingProxy() {
      this.pinged = false;
      this.proxyStatus = "Pinging...";
      String proxyIp = this.getConfig().getIp();
      int proxyPort = this.getConfig().getPort();
      new Thread(() -> {
         try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(proxyIp, proxyPort), 2000);
            this.proxyStatus = "Proxy online";
            this.pinged = true;
         } catch (Exception var8) {
            this.proxyStatus = "§cOffline — cannot reach proxy";
            this.pinged = true;
         }
      }, "PingBypass-Pinger").start();
   }

   public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
      super.extractRenderState(context, mouseX, mouseY, delta);
      context.centeredText(this.font, "PingBypass", this.width / 2, 20, 16777215);
      int centerX = this.width / 2;
      int startY = 50;
      context.text(this.font, "Proxy IP", centerX - 150, startY - 11, 10526880);
      context.text(this.font, "Port", centerX - 150, startY + 23, 10526880);
      context.text(this.font, "Password", centerX + 5, startY + 23, 10526880);
      context.text(this.font, "Target Server", centerX - 150, startY + 57, 10526880);
      int statusColor = this.proxyStatus.contains("Connected")
         ? 5635925
         : (this.proxyStatus.contains("Idle") ? 16755200 : (this.proxyStatus.contains("Offline") ? 16733525 : 11184810));
      context.centeredText(this.font, this.proxyStatus, this.width / 2, startY + 165, statusColor);
      if (PingBypassFlags.proxyForwardingActive) {
         PingBypassModule pbModule = Night.MODULE_MANAGER.getModule(PingBypassModule.class);
         String session = "Session active — " + (pbModule.getServerName() != null ? pbModule.getServerName() : "connected");
         context.centeredText(this.font, session, this.width / 2, startY + 178, 5635925);
      }
   }

   private void connect() {
      PingBypassModule pbModule = Night.MODULE_MANAGER.getModule(PingBypassModule.class);
      pbModule.ip.setValue(this.ipField.getValue().trim());

      try {
         pbModule.port.setValue(Integer.parseInt(this.portField.getValue().trim()));
      } catch (NumberFormatException var3) {
      }

      pbModule.password.setValue(this.passwordField.getValue());
      pbModule.server.setValue(this.serverField.getValue().trim());
      if (pbModule.isToggled()) {
         pbModule.setToggled(false, false);
      }

      pbModule.setToggled(true);
   }

   private void resume() {
      this.minecraft.gui.setScreen(this.parent);
   }

   public void onClose() {
      this.minecraft.gui.setScreen(this.parent);
   }

   private PingBypassConfig getConfig() {
      return Night.PINGBYPASS_CONFIG;
   }
}
