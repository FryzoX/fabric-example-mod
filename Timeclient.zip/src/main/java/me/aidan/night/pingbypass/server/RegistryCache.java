package night.pingbypass.server;

import com.mojang.serialization.DynamicOps;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.stream.Stream;
import net.minecraft.core.LayeredRegistryAccess;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.RegistrySynchronization;
import net.minecraft.core.HolderLookup.RegistryLookup;
import net.minecraft.core.Registry.PendingTags;
import net.minecraft.core.RegistryAccess.Frozen;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundUpdateTagsPacket;
import net.minecraft.network.protocol.configuration.ClientboundRegistryDataPacket;
import net.minecraft.resources.RegistryDataLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.RegistryLayer;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.repository.KnownPack;
import net.minecraft.server.packs.repository.PackRepository;
import net.minecraft.server.packs.repository.ServerPacksSource;
import net.minecraft.server.packs.resources.MultiPackResourceManager;
import net.minecraft.tags.TagLoader;
import net.minecraft.tags.TagNetworkSerialization;
import net.minecraft.world.level.WorldDataConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RegistryCache {
   private static final Logger LOGGER = LoggerFactory.getLogger(RegistryCache.class);
   private static final Executor SYNC_EXECUTOR = Runnable::run;
   private final List<Packet<?>> registryPackets = new ArrayList<>();
   private final List<KnownPack> knownPacks = new ArrayList<>();
   private LayeredRegistryAccess<RegistryLayer> registries;
   private RegistryAccess registryManager;
   private boolean loaded;
   private volatile boolean loadAttempted;

   public void load() {
      LOGGER.info("Loading vanilla registries for proxy...");
      long start = System.currentTimeMillis();

      try {
         PackRepository packRepository = ServerPacksSource.createVanillaTrustedRepository();
         MinecraftServer.configurePackRepository(packRepository, WorldDataConfiguration.DEFAULT, true, true);
         List<PackResources> packs = packRepository.openAllSelected();
         MultiPackResourceManager resourceManager = new MultiPackResourceManager(PackType.SERVER_DATA, packs);

         try {
            LayeredRegistryAccess<RegistryLayer> initialLayers = RegistryLayer.createRegistryAccess();
            List<PendingTags<?>> staticTags = TagLoader.loadTagsForExistingRegistries(resourceManager, initialLayers.getLayer(RegistryLayer.STATIC));
            Frozen worldgenLoadContext = initialLayers.getAccessForLoading(RegistryLayer.WORLDGEN);
            List<RegistryLookup<?>> worldgenContextRegistries = TagLoader.buildUpdatedLookups(worldgenLoadContext, staticTags);
            Frozen worldgenRegistries = (Frozen)RegistryDataLoader.load(
                  resourceManager, worldgenContextRegistries, RegistryDataLoader.WORLDGEN_REGISTRIES, SYNC_EXECUTOR
               )
               .join();
            List<RegistryLookup<?>> dimensionContextRegistries = Stream.concat(worldgenContextRegistries.stream(), worldgenRegistries.listRegistries())
               .toList();
            Frozen dimensionRegistries = (Frozen)RegistryDataLoader.load(
                  resourceManager, dimensionContextRegistries, RegistryDataLoader.DIMENSION_REGISTRIES, SYNC_EXECUTOR
               )
               .join();
            this.registries = initialLayers.replaceFrom(RegistryLayer.WORLDGEN, new Frozen[]{worldgenRegistries, dimensionRegistries});

            for (PendingTags<?> pending : staticTags) {
               pending.apply();
            }

            this.registryManager = this.registries.compositeAccess();
            this.knownPacks.addAll(resourceManager.listPacks().flatMap(pack -> pack.knownPackInfo().stream()).toList());
            DynamicOps<Tag> ops = this.registries.compositeAccess().createSerializationContext(NbtOps.INSTANCE);
            RegistrySynchronization.packRegistries(
               ops,
               this.registries.getAccessFrom(RegistryLayer.WORLDGEN),
               Set.of(),
               (key, entries) -> this.registryPackets.add(new ClientboundRegistryDataPacket(key, entries))
            );
            this.registryPackets.add(new ClientboundUpdateTagsPacket(TagNetworkSerialization.serializeTagsToNetwork(this.registries)));
            this.loaded = true;
         } catch (Throwable var16) {
            try {
               resourceManager.close();
            } catch (Throwable var15) {
               var16.addSuppressed(var15);
            }

            throw var16;
         }

         resourceManager.close();
         long var181 = System.currentTimeMillis() - start;
         LOGGER.info("Loaded {} registry packets in {}ms", this.registryPackets.size(), var181);
      } catch (Exception var17) {
         LOGGER.error("Failed to load vanilla registries", var17);
      }
   }

   public boolean isLoaded() {
      if (!this.loaded && !this.loadAttempted) {
         this.loadAttempted = true;
         this.load();
      }

      return this.loaded;
   }

   public List<Packet<?>> getRegistryPackets() {
      return this.registryPackets;
   }

   public List<KnownPack> getKnownPacks() {
      return this.knownPacks;
   }

   public LayeredRegistryAccess<RegistryLayer> getRegistries() {
      return this.registries;
   }

   public RegistryAccess getRegistryManager() {
      return this.registryManager;
   }
}
