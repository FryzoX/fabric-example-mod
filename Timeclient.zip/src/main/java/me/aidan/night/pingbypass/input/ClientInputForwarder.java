package night.pingbypass.input;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.protocol.common.ServerboundCustomPayloadPacket;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.MouseInputEvent;
import night.events.impl.TickEvent;
import night.pingbypass.PingBypassFlags;
import night.pingbypass.protocol.PbCustomPayload;
import night.pingbypass.protocol.packets.C2SInputPacket;
import night.pingbypass.protocol.packets.C2SOpenInventoryPacket;

public class ClientInputForwarder {
   private boolean inventoryOpen = false;

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (PingBypassFlags.proxyForwardingActive) {
         if (Night.PINGBYPASS_CONFIG == null || !Night.PINGBYPASS_CONFIG.isServer()) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.getConnection() != null) {
               Screen screen = mc.gui.screen();
               InventoryScreen inv;
               boolean nowOpen = screen instanceof InventoryScreen && (inv = (InventoryScreen)screen).getMenu() == mc.player.inventoryMenu;
               if (nowOpen != this.inventoryOpen) {
                  this.inventoryOpen = nowOpen;

                  try {
                     PbCustomPayload payload = PbCustomPayload.fromPacket(new C2SOpenInventoryPacket(nowOpen));
                     mc.getConnection().getConnection().send(new ServerboundCustomPayloadPacket(payload));
                  } catch (Exception var8) {
                     Night.LOGGER.warn("[PingBypass] Failed to send inventory-open state", var8);
                  }
               }
            }
         }
      }
   }

   @SubscribeEvent
   public void onMouseInput(MouseInputEvent event) {
      if (PingBypassFlags.proxyForwardingActive) {
         if (Night.PINGBYPASS_CONFIG == null || !Night.PINGBYPASS_CONFIG.isServer()) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.getConnection() != null) {
               int button = event.getButton();
               if (button == 0 || button == 1) {
                  this.sendInput(mc, 0, button, 1);
               }
            }
         }
      }
   }

   private void sendInput(Minecraft mc, int type, int button, int action) {
      try {
         PbCustomPayload payload = PbCustomPayload.fromPacket(new C2SInputPacket(type, button, action));
         mc.getConnection().getConnection().send(new ServerboundCustomPayloadPacket(payload));
      } catch (Exception var6) {
         Night.LOGGER.warn("[PingBypass] Failed to send input", var6);
      }
   }

   public void start() {
      Night.EVENT_HANDLER.subscribe(this);
      Night.LOGGER.info("[PingBypass] Client input forwarder started");
   }

   public void stop() {
      Night.EVENT_HANDLER.unsubscribe(this);
   }
}
