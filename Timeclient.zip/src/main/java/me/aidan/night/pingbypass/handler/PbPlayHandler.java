package night.pingbypass.handler;

import com.mojang.authlib.GameProfile;
import it.unimi.dsi.fastutil.ints.Int2ObjectMaps;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.Connection;
import net.minecraft.network.DisconnectionDetails;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.HashedStack;
import net.minecraft.network.TickablePacketListener;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundKeepAlivePacket;
import net.minecraft.network.protocol.common.ServerboundClientInformationPacket;
import net.minecraft.network.protocol.common.ServerboundCustomClickActionPacket;
import net.minecraft.network.protocol.common.ServerboundCustomPayloadPacket;
import net.minecraft.network.protocol.common.ServerboundKeepAlivePacket;
import net.minecraft.network.protocol.common.ServerboundPongPacket;
import net.minecraft.network.protocol.common.ServerboundResourcePackPacket;
import net.minecraft.network.protocol.cookie.ServerboundCookieResponsePacket;
import net.minecraft.network.protocol.game.ServerGamePacketListener;
import net.minecraft.network.protocol.game.ServerboundAcceptTeleportationPacket;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundBlockEntityTagQueryPacket;
import net.minecraft.network.protocol.game.ServerboundChangeDifficultyPacket;
import net.minecraft.network.protocol.game.ServerboundChangeGameModePacket;
import net.minecraft.network.protocol.game.ServerboundChatAckPacket;
import net.minecraft.network.protocol.game.ServerboundChatCommandPacket;
import net.minecraft.network.protocol.game.ServerboundChatCommandSignedPacket;
import net.minecraft.network.protocol.game.ServerboundChatPacket;
import net.minecraft.network.protocol.game.ServerboundChatSessionUpdatePacket;
import net.minecraft.network.protocol.game.ServerboundChunkBatchReceivedPacket;
import net.minecraft.network.protocol.game.ServerboundClientCommandPacket;
import net.minecraft.network.protocol.game.ServerboundClientTickEndPacket;
import net.minecraft.network.protocol.game.ServerboundCommandSuggestionPacket;
import net.minecraft.network.protocol.game.ServerboundConfigurationAcknowledgedPacket;
import net.minecraft.network.protocol.game.ServerboundContainerButtonClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClosePacket;
import net.minecraft.network.protocol.game.ServerboundContainerSlotStateChangedPacket;
import net.minecraft.network.protocol.game.ServerboundDebugSubscriptionRequestPacket;
import net.minecraft.network.protocol.game.ServerboundEditBookPacket;
import net.minecraft.network.protocol.game.ServerboundEntityTagQueryPacket;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundJigsawGeneratePacket;
import net.minecraft.network.protocol.game.ServerboundLockDifficultyPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundMoveVehiclePacket;
import net.minecraft.network.protocol.game.ServerboundPaddleBoatPacket;
import net.minecraft.network.protocol.game.ServerboundPickItemFromBlockPacket;
import net.minecraft.network.protocol.game.ServerboundPickItemFromEntityPacket;
import net.minecraft.network.protocol.game.ServerboundPlaceRecipePacket;
import net.minecraft.network.protocol.game.ServerboundPlayerAbilitiesPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerInputPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerLoadedPacket;
import net.minecraft.network.protocol.game.ServerboundRecipeBookChangeSettingsPacket;
import net.minecraft.network.protocol.game.ServerboundRecipeBookSeenRecipePacket;
import net.minecraft.network.protocol.game.ServerboundRenameItemPacket;
import net.minecraft.network.protocol.game.ServerboundSeenAdvancementsPacket;
import net.minecraft.network.protocol.game.ServerboundSelectBundleItemPacket;
import net.minecraft.network.protocol.game.ServerboundSelectTradePacket;
import net.minecraft.network.protocol.game.ServerboundSetBeaconPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundSetCommandBlockPacket;
import net.minecraft.network.protocol.game.ServerboundSetCommandMinecartPacket;
import net.minecraft.network.protocol.game.ServerboundSetCreativeModeSlotPacket;
import net.minecraft.network.protocol.game.ServerboundSetGameRulePacket;
import net.minecraft.network.protocol.game.ServerboundSetJigsawBlockPacket;
import net.minecraft.network.protocol.game.ServerboundSetStructureBlockPacket;
import net.minecraft.network.protocol.game.ServerboundSetTestBlockPacket;
import net.minecraft.network.protocol.game.ServerboundSignUpdatePacket;
import net.minecraft.network.protocol.game.ServerboundSpectatorActionPacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.network.protocol.game.ServerboundTeleportToEntityPacket;
import net.minecraft.network.protocol.game.ServerboundTestInstanceBlockActionPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action;
import net.minecraft.network.protocol.ping.ServerboundPingRequestPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import night.Night;
import night.events.impl.AttackBlockEvent;
import night.events.impl.PlayerJumpEvent;
import night.mixins.accessors.ClientPlayerEntityAccessor;
import night.modules.Module;
import night.modules.impl.player.SpeedMineModule;
import night.pingbypass.PingBypassFlags;
import night.pingbypass.modules.PbModule;
import night.pingbypass.modules.SyncModule;
import night.pingbypass.protocol.PbCustomPayload;
import night.pingbypass.protocol.packets.C2SFriendSyncPacket;
import night.pingbypass.protocol.packets.C2SModuleTogglePacket;
import night.pingbypass.protocol.packets.C2SOpenInventoryPacket;
import night.pingbypass.protocol.packets.C2SSettingChangePacket;
import night.pingbypass.server.ProxyServer;
import night.pingbypass.server.ProxyServerTickListener;
import night.pingbypass.server.S2CForwarder;
import night.settings.Setting;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.settings.impl.StringSetting;
import night.utils.minecraft.InventoryUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PbPlayHandler implements ServerGamePacketListener, TickablePacketListener {
   private static final Logger LOGGER = LoggerFactory.getLogger(PbPlayHandler.class);
   private static final long KEEP_ALIVE_INTERVAL_MS = 15000L;
   private final ProxyServer proxyServer;
   private final Connection clientConnection;
   private final GameProfile profile;
   private final S2CForwarder s2cForwarder;
   private boolean wasOnGround = true;
   private long lastKeepAliveSent;

   public PbPlayHandler(ProxyServer proxyServer, Connection clientConnection, GameProfile profile, S2CForwarder s2cForwarder, int initialTeleportId) {
      this.proxyServer = proxyServer;
      this.clientConnection = clientConnection;
      this.profile = profile;
      this.s2cForwarder = s2cForwarder;
      LOGGER.info("Play handler initialized for {} — dumb pipe mode", profile.name());
   }

   public GameProfile getProfile() {
      return this.profile;
   }

   public void tick() {
      long now = System.currentTimeMillis();
      if (now - this.lastKeepAliveSent >= 15000L) {
         this.lastKeepAliveSent = now;
         this.clientConnection.send(new ClientboundKeepAlivePacket(now));
      }
   }

   public void onDisconnect(DisconnectionDetails info) {
      LOGGER.info("Client {} disconnected: {}", this.profile.name(), info.reason());
      this.s2cForwarder.stop();
      Minecraft mc = Minecraft.getInstance();
      mc.execute(() -> {
         if (mc.level != null) {
            mc.level.disconnect(Component.literal("Client disconnected"));
         }

         if (mc.getConnection() != null) {
            mc.getConnection().getConnection().disconnect(Component.literal("Client disconnected"));
         }
      });
   }

   public boolean isAcceptingMessages() {
      return this.clientConnection.isConnected();
   }

   private void syncSlotForInteract() {
      InventoryUtils.flushPendingRestores();
      SpeedMineModule speedMine = Night.MODULE_MANAGER.getModule(SpeedMineModule.class);
      if (speedMine != null && speedMine.isToggled() && speedMine.isRunningOnProxy()) {
         Minecraft mc = Minecraft.getInstance();
         if (mc.player != null) {
            Object object = speedMine.interactSyncLock;
            synchronized (object) {
               int clientSlot = mc.player.getInventory().getSelectedSlot();
               this.forward(new ServerboundSetCarriedItemPacket(clientSlot));
               speedMine.setInteractPaused(true);
               return;
            }
         }
      }

      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         int clientSlot = mc.player.getInventory().getSelectedSlot();
         if (clientSlot != Night.POSITION_MANAGER.getServerSlot()) {
            this.forward(new ServerboundSetCarriedItemPacket(clientSlot));
         }
      }
   }

   private void forward(Packet<?> packet) {
      Connection serverConn = this.proxyServer.getServerConnection();
      if (serverConn != null && serverConn.isConnected()) {
         ProxyServerTickListener.allowSend(() -> serverConn.send(packet));
      }
   }

   public void handleMovePlayer(ServerboundMovePlayerPacket p) {
      Minecraft.getInstance().execute(() -> this.handleMovePlayer0(p));
   }

   private void handleMovePlayer0(ServerboundMovePlayerPacket p) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         double prevY = mc.player.getY();
         if (p.hasPosition()) {
            mc.player.setPos(p.getX(mc.player.getX()), p.getY(mc.player.getY()), p.getZ(mc.player.getZ()));
            double newY = mc.player.getY();
            if (newY < prevY && !p.isOnGround()) {
               mc.player.fallDistance += (float)(prevY - newY);
            } else if (p.isOnGround()) {
               mc.player.fallDistance = 0.0;
            }

            if (newY > prevY && !p.isOnGround() && this.wasOnGround) {
               Night.EVENT_HANDLER.post(new PlayerJumpEvent());
            }

            this.wasOnGround = p.isOnGround();
         }

         if (p.hasRotation()) {
            mc.player.setYRot(p.getYRot(mc.player.getYRot()));
            mc.player.setXRot(p.getXRot(mc.player.getXRot()));
         }

         mc.player.setOnGround(p.isOnGround());
         mc.player.horizontalCollision = p.horizontalCollision();
         ProxyServerTickListener.allowSend(() -> ((ClientPlayerEntityAccessor)mc.player).invokeSendMovementPackets());
      }

      PingBypassFlags.clientOnGround = p.isOnGround();
      PingBypassFlags.clientHorizontalCollision = p.horizontalCollision();
   }

   public void handleUseItemOn(ServerboundUseItemOnPacket p) {
      this.syncSlotForInteract();
      this.mirrorStartUsingItem(p.getHand());
      this.forward(p);
   }

   public void handleUseItem(ServerboundUseItemPacket p) {
      this.syncSlotForInteract();
      this.mirrorStartUsingItem(p.getHand());
      this.forward(p);
   }

   private void mirrorStartUsingItem(InteractionHand hand) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         ItemStack stack = mc.player.getItemInHand(hand);
         if (stack.getUseDuration(mc.player) > 0) {
            mc.player.startUsingItem(hand);
         }
      }
   }

   public void handleInteract(ServerboundInteractPacket p) {
      this.forward(p);
   }

   public void handlePlayerAction(ServerboundPlayerActionPacket p) {
      if (p.getAction() == Action.RELEASE_USE_ITEM) {
         Minecraft mc = Minecraft.getInstance();
         if (mc.player != null) {
            mc.player.stopUsingItem();
         }

         SpeedMineModule speedMine2;
         if ((speedMine2 = Night.MODULE_MANAGER.getModule(SpeedMineModule.class)) != null && speedMine2.isInteractPaused()) {
            speedMine2.setInteractPaused(false);
         }

         this.forward(p);
      } else {
         SpeedMineModule speedMine;
         if (p.getAction() == Action.START_DESTROY_BLOCK
            && (speedMine = Night.MODULE_MANAGER.getModule(SpeedMineModule.class)) != null
            && speedMine.isToggled()) {
            Minecraft mcx = Minecraft.getInstance();
            if (mcx.player != null) {
               mcx.execute(() -> {
                  AttackBlockEvent event = new AttackBlockEvent(p.getPos(), p.getDirection());
                  Night.EVENT_HANDLER.post(event);
                  if (!event.isCancelled()) {
                     this.forward(p);
                  }
               });
               return;
            }
         }

         this.forward(p);
      }
   }

   public void handleAnimate(ServerboundSwingPacket p) {
      this.forward(p);
   }

   public void handleContainerClick(ServerboundContainerClickPacket p) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         mc.execute(
            () -> {
               try {
                  AbstractContainerMenu handler = (AbstractContainerMenu)(p.containerId() == mc.player.containerMenu.containerId
                     ? mc.player.containerMenu
                     : mc.player.inventoryMenu);
                  handler.clicked(p.slotNum(), p.buttonNum(), p.containerInput(), mc.player);
                  ServerboundContainerClickPacket freshPacket = new ServerboundContainerClickPacket(
                     p.containerId(), handler.getStateId(), p.slotNum(), p.buttonNum(), p.containerInput(), Int2ObjectMaps.emptyMap(), HashedStack.EMPTY
                  );
                  this.forward(freshPacket);
               } catch (Exception var5) {
               }
            }
         );
      }
   }

   public void handleContainerClose(ServerboundContainerClosePacket p) {
      this.forward(p);
   }

   public void handleSetCarriedItem(ServerboundSetCarriedItemPacket p) {
      Minecraft mc = Minecraft.getInstance();
      SpeedMineModule speedMine = Night.MODULE_MANAGER.getModule(SpeedMineModule.class);
      boolean speedMineOwnsSlot = speedMine != null
         && speedMine.isToggled()
         && speedMine.isRunningOnProxy()
         && (speedMine.getPrimary() != null || speedMine.getSecondary() != null);
      if (mc.player != null) {
         mc.player.getInventory().setSelectedSlot(p.getSlot());
      }

      if (!speedMineOwnsSlot && !InventoryUtils.hasActiveSilentSwitch()) {
         this.forward(p);
      }
   }

   public void handleClientCommand(ServerboundClientCommandPacket p) {
      this.forward(p);
   }

   public void handleChat(ServerboundChatPacket p) {
      this.forward(p);
   }

   public void handleChatCommand(ServerboundChatCommandPacket p) {
      this.forward(p);
   }

   public void handleSignedChatCommand(ServerboundChatCommandSignedPacket p) {
      this.forward(p);
   }

   public void handleChatAck(ServerboundChatAckPacket p) {
      this.forward(p);
   }

   public void handleChatSessionUpdate(ServerboundChatSessionUpdatePacket p) {
      this.forward(p);
   }

   public void handleCustomCommandSuggestions(ServerboundCommandSuggestionPacket p) {
      this.forward(p);
   }

   public void handleSeenAdvancements(ServerboundSeenAdvancementsPacket p) {
      this.forward(p);
   }

   public void handleSpectatorAction(ServerboundSpectatorActionPacket p) {
      this.forward(p);
   }

   public void handleResourcePackResponse(ServerboundResourcePackPacket p) {
      this.forward(p);
   }

   public void handleCookieResponse(ServerboundCookieResponsePacket p) {
      this.forward(p);
   }

   public void handleAcceptTeleportPacket(ServerboundAcceptTeleportationPacket p) {
      this.forward(p);
   }

   public void handleChunkBatchReceived(ServerboundChunkBatchReceivedPacket p) {
      this.forward(p);
   }

   public void handleClientTickEnd(ServerboundClientTickEndPacket p) {
      this.forward(p);
   }

   public void handleConfigurationAcknowledged(ServerboundConfigurationAcknowledgedPacket p) {
      this.forward(p);
   }

   public void handleClientInformation(ServerboundClientInformationPacket p) {
      this.forward(p);
   }

   public void handleBlockEntityTagQuery(ServerboundBlockEntityTagQueryPacket p) {
      this.forward(p);
   }

   public void handleChangeDifficulty(ServerboundChangeDifficultyPacket p) {
      this.forward(p);
   }

   public void handleContainerSlotStateChanged(ServerboundContainerSlotStateChangedPacket p) {
      this.forward(p);
   }

   public void handleDebugSubscriptionRequest(ServerboundDebugSubscriptionRequestPacket p) {
      this.forward(p);
   }

   public void handleEditBook(ServerboundEditBookPacket p) {
      this.forward(p);
   }

   public void handleEntityTagQuery(ServerboundEntityTagQueryPacket p) {
      this.forward(p);
   }

   public void handleJigsawGenerate(ServerboundJigsawGeneratePacket p) {
      this.forward(p);
   }

   public void handleLockDifficulty(ServerboundLockDifficultyPacket p) {
      this.forward(p);
   }

   public void handleMoveVehicle(ServerboundMoveVehiclePacket p) {
      this.forward(p);
   }

   public void handlePaddleBoat(ServerboundPaddleBoatPacket p) {
      this.forward(p);
   }

   public void handlePickItemFromBlock(ServerboundPickItemFromBlockPacket p) {
      this.forward(p);
   }

   public void handlePickItemFromEntity(ServerboundPickItemFromEntityPacket p) {
      this.forward(p);
   }

   public void handlePlaceRecipe(ServerboundPlaceRecipePacket p) {
      this.forward(p);
   }

   public void handlePlayerAbilities(ServerboundPlayerAbilitiesPacket p) {
      this.forward(p);
   }

   public void handlePlayerCommand(ServerboundPlayerCommandPacket p) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         switch (p.getAction()) {
            case START_SPRINTING:
               mc.player.setSprinting(true);
               break;
            case STOP_SPRINTING:
               mc.player.setSprinting(false);
         }
      }

      this.forward(p);
   }

   public void handlePlayerInput(ServerboundPlayerInputPacket p) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         mc.player.setShiftKeyDown(p.input().shift());
      }

      this.forward(p);
   }

   public void handleAcceptPlayerLoad(ServerboundPlayerLoadedPacket p) {
      this.forward(p);
   }

   public void handleRecipeBookSeenRecipePacket(ServerboundRecipeBookSeenRecipePacket p) {
      this.forward(p);
   }

   public void handleRenameItem(ServerboundRenameItemPacket p) {
      this.forward(p);
   }

   public void handleBundleItemSelectedPacket(ServerboundSelectBundleItemPacket p) {
      this.forward(p);
   }

   public void handleSelectTrade(ServerboundSelectTradePacket p) {
      this.forward(p);
   }

   public void handleSetBeaconPacket(ServerboundSetBeaconPacket p) {
      this.forward(p);
   }

   public void handleSetCommandBlock(ServerboundSetCommandBlockPacket p) {
      this.forward(p);
   }

   public void handleSetCommandMinecart(ServerboundSetCommandMinecartPacket p) {
      this.forward(p);
   }

   public void handleSetCreativeModeSlot(ServerboundSetCreativeModeSlotPacket p) {
      this.forward(p);
   }

   public void handleSetGameRule(ServerboundSetGameRulePacket p) {
      this.forward(p);
   }

   public void handleSetJigsawBlock(ServerboundSetJigsawBlockPacket p) {
      this.forward(p);
   }

   public void handleSetStructureBlock(ServerboundSetStructureBlockPacket p) {
      this.forward(p);
   }

   public void handleSetTestBlock(ServerboundSetTestBlockPacket p) {
      this.forward(p);
   }

   public void handleSignUpdate(ServerboundSignUpdatePacket p) {
      this.forward(p);
   }

   public void handleTeleportToEntityPacket(ServerboundTeleportToEntityPacket p) {
      this.forward(p);
   }

   public void handleTestInstanceBlockAction(ServerboundTestInstanceBlockActionPacket p) {
      this.forward(p);
   }

   public void handleChangeGameMode(ServerboundChangeGameModePacket p) {
      this.forward(p);
   }

   public void handleAttack(ServerboundAttackPacket p) {
      this.forward(p);
   }

   public void handleContainerButtonClick(ServerboundContainerButtonClickPacket p) {
      this.forward(p);
   }

   public void handleRecipeBookChangeSettingsPacket(ServerboundRecipeBookChangeSettingsPacket p) {
      this.forward(p);
   }

   public void handleCustomClickAction(ServerboundCustomClickActionPacket p) {
      this.forward(p);
   }

   public void handleKeepAlive(ServerboundKeepAlivePacket p) {
   }

   public void handlePong(ServerboundPongPacket p) {
      this.forward(p);
   }

   public void handlePingRequest(ServerboundPingRequestPacket p) {
   }

   public void handleCustomPayload(ServerboundCustomPayloadPacket p) {
      if (p.payload() instanceof PbCustomPayload pbPayload) {
         this.handlePbPayload(pbPayload);
      } else {
         this.forward(p);
      }
   }

   private void handlePbPayload(PbCustomPayload pbPayload) {
      FriendlyByteBuf buf = pbPayload.toBuf();

      try {
         int packetId = buf.readVarInt();
         switch (packetId) {
            case 3: {
               C2SModuleTogglePacket pkt = new C2SModuleTogglePacket(buf);
               PbModule pbModule = Night.PB_MODULE_MANAGER.getModule(pkt.getModuleName());
               if (pbModule != null) {
                  Minecraft.getInstance().execute(() -> {
                     SyncModule.applyToggle(pbModule, pkt.isEnabled());
                     LOGGER.info("[PB] PbModule {} toggled to {}", pkt.getModuleName(), pkt.isEnabled());
                  });
                  return;
               } else {
                  Module module = Night.MODULE_MANAGER.getModule(pkt.getModuleName());
                  if (module == null) {
                     return;
                  }

                  Minecraft.getInstance().execute(() -> {
                     module.setToggled(pkt.isEnabled(), false);
                     LOGGER.info("[PB] Module {} toggled to {}", pkt.getModuleName(), pkt.isEnabled());
                  });
                  return;
               }
            }
            case 4: {
               C2SSettingChangePacket pkt = new C2SSettingChangePacket(buf);
               PbModule pbModulex = Night.PB_MODULE_MANAGER.getModule(pkt.getModuleName());
               if (pbModulex == null) {
                  this.handleSettingChange(pkt);
                  return;
               }

               Minecraft.getInstance().execute(() -> SyncModule.applySetting(pbModule, pkt.getSettingName(), pkt.getValue()));
               return;
            }
            case 14: {
               C2SFriendSyncPacket pkt = new C2SFriendSyncPacket(buf);
               Minecraft.getInstance().execute(() -> {
                  Night.FRIEND_MANAGER.clear();

                  for (String friend : pkt.getFriends()) {
                     Night.FRIEND_MANAGER.add(friend);
                  }

                  LOGGER.info("[PB] Synced {} friend(s) from client", pkt.getFriends().size());
               });
               return;
            }
            case 15: {
               C2SOpenInventoryPacket pkt = new C2SOpenInventoryPacket(buf);
               Minecraft.getInstance().execute(() -> {
                  Minecraft mc = Minecraft.getInstance();
                  if (mc.player != null) {
                     if (pkt.isOpen()) {
                        mc.gui.setScreen(new InventoryScreen(mc.player));
                     } else {
                        Screen patt0$temp = mc.gui.screen();
                        InventoryScreen inv;
                        if (patt0$temp instanceof InventoryScreen && (inv = (InventoryScreen)patt0$temp).getMenu() == mc.player.inventoryMenu) {
                           mc.gui.setScreen(null);
                        }
                     }
                  }
               });
               return;
            }
            default:
               LOGGER.debug("[PB] Unknown packet ID: {}", packetId);
         }
      } catch (Exception var10) {
         LOGGER.warn("[PB] Failed to handle payload", var10);
      } finally {
         buf.release();
      }
   }

   private void handleSettingChange(C2SSettingChangePacket pkt) {
      Module module = Night.MODULE_MANAGER.getModule(pkt.getModuleName());
      if (module != null) {
         Setting setting = module.getSetting(pkt.getSettingName());
         if (setting != null) {
            Minecraft.getInstance().execute(() -> {
               try {
                  String value = pkt.getValue();
                  if (setting instanceof BooleanSetting s) {
                     s.setValue(Boolean.parseBoolean(value));
                  } else if (setting instanceof NumberSetting s) {
                     switch (s.getType()) {
                        case INTEGER:
                           s.setValue(Integer.parseInt(value));
                           break;
                        case LONG:
                           s.setValue(Long.parseLong(value));
                           break;
                        case FLOAT:
                           s.setValue(Float.parseFloat(value));
                           break;
                        case DOUBLE:
                           s.setValue(Double.parseDouble(value));
                     }
                  } else if (setting instanceof ModeSetting s) {
                     s.setValue(value);
                  } else if (setting instanceof StringSetting s) {
                     s.setValue(value);
                  } else if (setting instanceof ColorSetting s) {
                     String[] parts = value.split(",");
                     if (parts.length >= 4) {
                        s.setColor(new Color(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), Integer.parseInt(parts[3])));
                        if (parts.length >= 5) {
                           s.setSync(Boolean.parseBoolean(parts[4]));
                        }

                        if (parts.length >= 6) {
                           s.setRainbow(Boolean.parseBoolean(parts[5]));
                        }
                     }
                  }

                  LOGGER.info("[PB] Setting {}.{} = {}", new Object[]{pkt.getModuleName(), pkt.getSettingName(), value});
               } catch (Exception var5) {
                  LOGGER.warn("[PB] Failed to apply setting {}.{}", new Object[]{pkt.getModuleName(), pkt.getSettingName(), var5});
               }
            });
         }
      }
   }
}
