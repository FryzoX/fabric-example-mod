package night.pingbypass.handler;

import com.mojang.authlib.GameProfile;
import java.util.List;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.Connection;
import net.minecraft.network.DisconnectionDetails;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.TickablePacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ServerboundClientInformationPacket;
import net.minecraft.network.protocol.common.ServerboundCustomClickActionPacket;
import net.minecraft.network.protocol.common.ServerboundCustomPayloadPacket;
import net.minecraft.network.protocol.common.ServerboundKeepAlivePacket;
import net.minecraft.network.protocol.common.ServerboundPongPacket;
import net.minecraft.network.protocol.common.ServerboundResourcePackPacket;
import net.minecraft.network.protocol.configuration.ClientboundFinishConfigurationPacket;
import net.minecraft.network.protocol.configuration.ClientboundSelectKnownPacks;
import net.minecraft.network.protocol.configuration.ServerConfigurationPacketListener;
import net.minecraft.network.protocol.configuration.ServerboundAcceptCodeOfConductPacket;
import net.minecraft.network.protocol.configuration.ServerboundFinishConfigurationPacket;
import net.minecraft.network.protocol.configuration.ServerboundSelectKnownPacks;
import net.minecraft.network.protocol.cookie.ServerboundCookieResponsePacket;
import net.minecraft.network.protocol.game.GameProtocols;
import net.minecraft.network.protocol.game.GameProtocols.Context;
import night.Night;
import night.pingbypass.server.ProxyServer;
import night.pingbypass.server.RegistryCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PbConfigurationHandler implements ServerConfigurationPacketListener, TickablePacketListener {
   private static final Logger LOGGER = LoggerFactory.getLogger(PbConfigurationHandler.class);
   private static final Context NO_INFINITE_MATERIALS = () -> false;
   private final ProxyServer proxyServer;
   private final Connection connection;
   private final GameProfile profile;
   private boolean knownPacksSent;

   public PbConfigurationHandler(ProxyServer proxyServer, Connection connection, GameProfile profile) {
      this.proxyServer = proxyServer;
      this.connection = connection;
      this.profile = profile;
   }

   public void tick() {
      if (!this.knownPacksSent) {
         this.knownPacksSent = true;
         RegistryCache cache = this.proxyServer.getRegistryCache();
         if (cache.isLoaded()) {
            this.connection.send(new ClientboundSelectKnownPacks(cache.getKnownPacks()));
         } else {
            this.connection.send(new ClientboundSelectKnownPacks(List.of()));
         }

         LOGGER.info("Sent SelectKnownPacks to {}", this.profile.name());
      }
   }

   public void handleSelectKnownPacks(ServerboundSelectKnownPacks packet) {
      LOGGER.info("Client {} responded with known packs, sending registries", this.profile.name());
      RegistryCache cache = this.proxyServer.getRegistryCache();
      if (cache.isLoaded()) {
         for (Packet<?> p : cache.getRegistryPackets()) {
            this.connection.send(p);
         }
      }

      this.connection.send(ClientboundFinishConfigurationPacket.INSTANCE);
      LOGGER.info("Sent {} registry packets and FINISH_CONFIGURATION to {}", cache.isLoaded() ? cache.getRegistryPackets().size() : 0, this.profile.name());
   }

   public void handleConfigurationFinished(ServerboundFinishConfigurationPacket packet) {
      LOGGER.info("Client {} acknowledged FINISH_CONFIGURATION, transitioning to PLAY", this.profile.name());
      RegistryCache cache = this.proxyServer.getRegistryCache();
      RegistryAccess registryManager = (RegistryAccess)(cache.isLoaded() ? cache.getRegistryManager() : RegistryAccess.EMPTY);
      this.connection.setupOutboundProtocol(GameProtocols.CLIENTBOUND_TEMPLATE.bind(RegistryFriendlyByteBuf.decorator(registryManager)));
      if (Night.PINGBYPASS_CONFIG.hasPassword()) {
         this.connection
            .setupInboundProtocol(
               GameProtocols.SERVERBOUND_TEMPLATE.bind(RegistryFriendlyByteBuf.decorator(RegistryAccess.EMPTY), NO_INFINITE_MATERIALS),
               new PbPasswordHandler(this.proxyServer, this.connection, this.profile, registryManager)
            );
         LOGGER.info("Transitioning {} to password verification", this.profile.name());
      } else {
         this.connection
            .setupInboundProtocol(
               GameProtocols.SERVERBOUND_TEMPLATE.bind(RegistryFriendlyByteBuf.decorator(RegistryAccess.EMPTY), NO_INFINITE_MATERIALS),
               new PbWaitingHandler(this.proxyServer, this.connection, this.profile, registryManager)
            );
         LOGGER.info("Transitioning {} to waiting state", this.profile.name());
      }
   }

   public void handleAcceptCodeOfConduct(ServerboundAcceptCodeOfConductPacket packet) {
   }

   public void onDisconnect(DisconnectionDetails info) {
      LOGGER.info("Client {} disconnected during configuration: {}", this.profile.name(), info.reason());
   }

   public boolean isAcceptingMessages() {
      return this.connection.isConnected();
   }

   public void handleClientInformation(ServerboundClientInformationPacket p) {
   }

   public void handleKeepAlive(ServerboundKeepAlivePacket p) {
   }

   public void handlePong(ServerboundPongPacket p) {
   }

   public void handleResourcePackResponse(ServerboundResourcePackPacket p) {
   }

   public void handleCookieResponse(ServerboundCookieResponsePacket p) {
   }

   public void handleCustomPayload(ServerboundCustomPayloadPacket p) {
   }

   public void handleCustomClickAction(ServerboundCustomClickActionPacket p) {
   }
}
