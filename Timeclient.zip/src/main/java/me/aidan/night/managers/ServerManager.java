package night.managers;

import it.unimi.dsi.fastutil.Pair;
import it.unimi.dsi.fastutil.objects.ObjectObjectImmutablePair;
import java.util.Arrays;
import java.util.UUID;
import lombok.Generated;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket.Action;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket.Entry;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.ClientConnectEvent;
import night.events.impl.PacketReceiveEvent;
import night.events.impl.PlayerConnectEvent;
import night.events.impl.PlayerDisconnectEvent;
import night.events.impl.ServerConnectEvent;
import night.modules.impl.miscellaneous.FastLatencyModule;
import night.pingbypass.PingBypassFlags;
import night.utils.IMinecraft;
import night.utils.system.Timer;

public class ServerManager implements IMinecraft {
   private final Timer setbackTimer = new Timer();
   private final Timer responseTimer = new Timer();
   private final float[] tickRates = new float[20];
   private int nextIndex = 0;
   private long lastUpdate = -1L;
   private long timeJoined;
   private Pair<ServerAddress, ServerData> lastConnection;

   public ServerManager() {
      Night.EVENT_HANDLER.subscribe(this);
   }

   @SubscribeEvent
   public void onPacketReceive(PacketReceiveEvent event) {
      this.responseTimer.reset();
      if (event.getPacket() instanceof ClientboundPlayerPositionPacket) {
         this.setbackTimer.reset();
      }

      if (event.getPacket() instanceof ClientboundSetTimePacket) {
         this.tickRates[this.nextIndex] = Math.clamp(20.0F / ((float)(System.currentTimeMillis() - this.lastUpdate) / 1000.0F), 0.0F, 20.0F);
         this.nextIndex = (this.nextIndex + 1) % this.tickRates.length;
         this.lastUpdate = System.currentTimeMillis();
      }
   }

   @SubscribeEvent
   public void onClientConnect(ClientConnectEvent event) {
      Arrays.fill(this.tickRates, 0.0F);
      this.nextIndex = 0;
      this.timeJoined = System.currentTimeMillis();
      this.lastUpdate = System.currentTimeMillis();
   }

   @SubscribeEvent
   public void handleConnections(PacketReceiveEvent event) {
      if (mc.level != null) {
         if (!(event.getPacket() instanceof ClientboundPlayerInfoUpdatePacket packet)) {
            if (event.getPacket() instanceof ClientboundPlayerInfoRemovePacket packetx) {
               for (UUID id : packetx.profileIds()) {
                  Night.EVENT_HANDLER.post(new PlayerDisconnectEvent(id));
               }
            }
         } else if (packet.actions().contains(Action.ADD_PLAYER)) {
            for (Entry entry : packet.newEntries()) {
               Night.EVENT_HANDLER.post(new PlayerConnectEvent(entry.profile().id()));
            }
         }
      }
   }

   @SubscribeEvent
   public void onServerConnect(ServerConnectEvent event) {
      this.lastConnection = new ObjectObjectImmutablePair(event.getAddress(), event.getInfo());
   }

   public float getTickRate() {
      if (mc.player == null) {
         return 0.0F;
      } else if (System.currentTimeMillis() - this.timeJoined < 4000L) {
         return 20.0F;
      } else {
         int ticks = 0;
         float tickRates = 0.0F;

         for (float tickRate : this.tickRates) {
            if (tickRate > 0.0F) {
               tickRates += tickRate;
               ticks++;
            }
         }

         return tickRates / ticks;
      }
   }

   public int getPingDelay() {
      return (int)(this.getPing() / 25.0F);
   }

   public int getPing() {
      if (Night.MODULE_MANAGER.getModule(FastLatencyModule.class).isToggled()) {
         return Night.MODULE_MANAGER.getModule(FastLatencyModule.class).getLatency();
      } else if (mc.getConnection() != null && mc.player != null) {
         PlayerInfo entry = mc.getConnection().getPlayerInfo(mc.player.getUUID());
         if (entry != null) {
            return entry.getLatency();
         } else {
            if (PingBypassFlags.proxyForwardingActive) {
               for (PlayerInfo e : mc.getConnection().getOnlinePlayers()) {
                  if (e.getProfile().name().equals(mc.player.getName().getString())) {
                     return e.getLatency();
                  }
               }

               for (PlayerInfo ex : mc.getConnection().getOnlinePlayers()) {
                  if (ex.getLatency() > 0) {
                     return ex.getLatency();
                  }
               }
            }

            return 0;
         }
      } else {
         return 0;
      }
   }

   public String getServerBrand() {
      return mc.getCurrentServer() != null && mc.getConnection() != null && mc.getConnection().serverBrand() != null
         ? mc.getConnection().serverBrand()
         : "Vanilla";
   }

   public String getServer() {
      return mc.hasSingleplayerServer() ? "Singleplayer" : ServerAddress.parseString(mc.getCurrentServer().ip).getHost();
   }

   @Generated
   public Timer getSetbackTimer() {
      return this.setbackTimer;
   }

   @Generated
   public Timer getResponseTimer() {
      return this.responseTimer;
   }

   @Generated
   public float[] getTickRates() {
      return this.tickRates;
   }

   @Generated
   public int getNextIndex() {
      return this.nextIndex;
   }

   @Generated
   public long getLastUpdate() {
      return this.lastUpdate;
   }

   @Generated
   public long getTimeJoined() {
      return this.timeJoined;
   }

   @Generated
   public Pair<ServerAddress, ServerData> getLastConnection() {
      return this.lastConnection;
   }
}
