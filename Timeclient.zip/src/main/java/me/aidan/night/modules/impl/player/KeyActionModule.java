package night.modules.impl.player;

import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.KeyInputEvent;
import night.events.impl.MouseInputEvent;
import night.events.impl.PlayerUpdateEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.impl.movement.SprintModule;
import night.pingbypass.server.ProxyServerTickListener;
import night.settings.impl.BindSetting;
import night.settings.impl.BooleanSetting;
import night.settings.impl.CategorySetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.input.KeyboardUtils;
import night.utils.minecraft.GrimV3Inventory;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.NetworkUtils;

@RegisterModule(
   name = "KeyAction",
   description = "Keybinds for throwing fireworks, pearls and experience bottles.",
   category = Module.Category.PLAYER,
   persistent = true,
   proxyEnhanced = true
)
public class KeyActionModule extends Module {
   public CategorySetting fireworkCategory = new CategorySetting("FireWork", "Keybind and settings for throwing a firework.");
   public BindSetting fireworkBind = new BindSetting(
      "FireWorkBind",
      "Bind",
      "The key that throws a firework. Hold/ReverseHold repeat it every tick the bind is (or isn't) held.",
      new CategorySetting.Visibility(this.fireworkCategory),
      0
   );
   public ModeSetting fireworkSwitch = new ModeSetting(
      "FireWorkSwitch",
      "Switch",
      "The mode that will be used for automatically switching to fireworks.",
      new CategorySetting.Visibility(this.fireworkCategory),
      "Silent",
      InventoryUtils.SWITCH_MODES
   );
   public CategorySetting pearlsCategory = new CategorySetting("Pearls", "Keybind and settings for throwing an ender pearl.");
   public BindSetting pearlsBind = new BindSetting(
      "PearlsBind",
      "Bind",
      "The key that throws an ender pearl. Hold/ReverseHold repeat it every tick the bind is (or isn't) held.",
      new CategorySetting.Visibility(this.pearlsCategory),
      0
   );
   public ModeSetting pearlsSwitch = new ModeSetting(
      "PearlsSwitch",
      "Switch",
      "The mode that will be used for automatically switching to pearls.",
      new CategorySetting.Visibility(this.pearlsCategory),
      "Silent",
      InventoryUtils.SWITCH_MODES
   );
   public BooleanSetting pearlsRotate = new BooleanSetting(
      "PearlsRotate", "Rotate", "Sends a packet rotation right before throwing the pearl.", new CategorySetting.Visibility(this.pearlsCategory), true
   );
   public CategorySetting xpCategory = new CategorySetting("XP", "Keybind and settings for throwing experience bottles.");
   public BindSetting xpBind = new BindSetting(
      "XPBind",
      "Bind",
      "The key that starts/stops throwing experience bottles. Hold/ReverseHold keep the loop matched to whether the bind is (or isn't) held instead of toggling it.",
      new CategorySetting.Visibility(this.xpCategory),
      0
   );
   public ModeSetting xpSwitch = new ModeSetting(
      "XPSwitch",
      "Switch",
      "The mode that will be used for automatically switching to experience bottles.",
      new CategorySetting.Visibility(this.xpCategory),
      "Silent",
      InventoryUtils.SWITCH_MODES
   );
   public BooleanSetting xpRotate = new BooleanSetting(
      "XPRotate", "Rotate", "Rotates down to your feet when throwing experience bottles.", new CategorySetting.Visibility(this.xpCategory), true
   );
   public NumberSetting xpDelay = new NumberSetting(
      "XPDelay", "Delay", "The delay in ticks between throwing experience bottles.", new CategorySetting.Visibility(this.xpCategory), 1, 0, 20
   );
   public NumberSetting xpRepeat = new NumberSetting(
      "XPRepeat", "Repeat", "Allows you to throw a lot more XP bottles at once.", new CategorySetting.Visibility(this.xpCategory), 1, 1, 15
   );
   public ModeSetting xpAntiWaste = new ModeSetting(
      "XPAntiWaste",
      "AntiWaste",
      "How wasting of experience bottles should be prevented.",
      new CategorySetting.Visibility(this.xpCategory),
      "Avoid",
      new String[]{"None", "Avoid", "Disable"}
   );
   public BooleanSetting xpItemDisable = new BooleanSetting(
      "XPItemDisable", "ItemDisable", "Automatically stops the XP loop when you run out of XP.", new CategorySetting.Visibility(this.xpCategory), true
   );
   private boolean xpActive = false;
   private boolean botXpActive = false;
   private int xpTicks = 0;
   private long lastPearlTime = 0L;
   public BooleanSetting botXpDebug = new BooleanSetting("BotXPDebug", "Log bot XP bursts locally without changing throw behavior.", true);
   private long lastXpDiagnostic;
   private long previousXpBurst;
   private int diagnosticBursts;
   private int diagnosticUses;
   private String diagnosticMode = "";
   public NumberSetting botXpBurstDelay = new NumberSetting(
      "BotXPBurstDelay", "Minimum milliseconds between bot-owned XP bursts; manual XP keeps XPDelay.", 50, 0, 50
   );
   private long nextBotXpBurstNanos;
   private long botXpBurstCount;

   public long getBotXpBurstCount() {
      return this.botXpBurstCount;
   }

   public boolean isXpActive() {
      return this.xpActive || this.botXpActive;
   }

   public void setBotXpActive(boolean active) {
      if (this.botXpDebug.getValue() && active != this.botXpActive) {
         Night.LOGGER
            .info(
               "[BotXP] request={} delayTicks={} repeat={} switch={}",
               new Object[]{active, this.xpDelay.getValue(), this.xpRepeat.getValue(), this.xpSwitch.getValue()}
            );
      }

      this.botXpActive = active;
      if (!active && !this.xpActive) {
         this.xpTicks = 0;
      }
   }

   public boolean isBotXpActive() {
      return this.botXpActive;
   }

   @SubscribeEvent
   public void onKeyInput(KeyInputEvent event) {
      if (!this.shouldRunOnProxy() && !this.getNull() && (mc.gui == null || mc.gui.screen() == null)) {
         if (this.fireworkBind.getValue() != 0 && event.getKey() == this.fireworkBind.getValue() && this.fireworkBind.getMode().equals("Bind")) {
            this.throwFirework();
         }

         if (this.pearlsBind.getValue() != 0 && event.getKey() == this.pearlsBind.getValue() && this.pearlsBind.getMode().equals("Bind")) {
            this.throwPearl();
         }

         if (this.xpBind.getValue() != 0 && event.getKey() == this.xpBind.getValue() && this.xpBind.getMode().equals("Bind")) {
            this.xpActive = !this.xpActive;
         }
      }
   }

   @SubscribeEvent
   public void onMouseInput(MouseInputEvent event) {
      if (!this.shouldRunOnProxy() && !this.getNull() && (mc.gui == null || mc.gui.screen() == null)) {
         int key = -event.getButton() - 1;
         if (this.fireworkBind.getValue() != 0 && key == this.fireworkBind.getValue() && this.fireworkBind.getMode().equals("Bind")) {
            this.throwFirework();
         }

         if (this.pearlsBind.getValue() != 0 && key == this.pearlsBind.getValue() && this.pearlsBind.getMode().equals("Bind")) {
            this.throwPearl();
         }

         if (this.xpBind.getValue() != 0 && key == this.xpBind.getValue() && this.xpBind.getMode().equals("Bind")) {
            this.xpActive = !this.xpActive;
         }
      }
   }

   private void throwFirework() {
      if (mc.player != null && mc.level != null) {
         if (this.fireworkSwitch.getValue().equalsIgnoreCase("None") && mc.player.getMainHandItem().getItem() != Items.FIREWORK_ROCKET) {
            Night.CHAT_MANAGER.tagged("You are currently not holding any fireworks.", this.getName());
         } else if (!mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.FIREWORK_ROCKET))) {
            int slot = InventoryUtils.find(
               Items.FIREWORK_ROCKET,
               0,
               !this.fireworkSwitch.getValue().equalsIgnoreCase("AltSwap") && !this.fireworkSwitch.getValue().equalsIgnoreCase("AltPickup") ? 8 : 35
            );
            int previousSlot = mc.player.getInventory().getSelectedSlot();
            if (slot == -1) {
               Night.CHAT_MANAGER.tagged("No fireworks could be found in your hotbar.", this.getName());
            } else {
               InventoryUtils.switchSlot(this.fireworkSwitch.getValue(), slot, previousSlot);
               NetworkUtils.sendSequencedPacket(
                  sequence -> new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, sequence, mc.player.getYRot(), mc.player.getXRot())
               );
               InventoryUtils.switchBack(this.fireworkSwitch.getValue(), slot, previousSlot);
            }
         }
      }
   }

   public boolean isPearlActive() {
      return System.currentTimeMillis() - this.lastPearlTime < 100L;
   }

   private void throwPearl() {
      if (mc.player != null && mc.level != null) {
         if (this.pearlsSwitch.getValue().equalsIgnoreCase("None") && mc.player.getMainHandItem().getItem() != Items.ENDER_PEARL) {
            Night.CHAT_MANAGER.tagged("You are currently not holding any pearls.", this.getName());
         } else if (!mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))) {
            this.lastPearlTime = System.currentTimeMillis();
            MultiTaskModule multiTask = Night.MODULE_MANAGER.getModule(MultiTaskModule.class);
            boolean keepEating = multiTask != null && multiTask.isToggled() && multiTask.pearl.getValue() && mc.player.isUsingItem();
            String pearlMode = keepEating ? "AltSwap" : this.pearlsSwitch.getValue();
            int slot = InventoryUtils.find(Items.ENDER_PEARL, 0, !pearlMode.equalsIgnoreCase("AltSwap") && !pearlMode.equalsIgnoreCase("AltPickup") ? 8 : 35);
            int previousSlot = mc.player.getInventory().getSelectedSlot();
            if (slot == -1) {
               Night.CHAT_MANAGER.tagged("No pearls could be found in your hotbar.", this.getName());
            } else {
               if (this.pearlsRotate.getValue()) {
                  Night.ROTATION_MANAGER.packetRotate(mc.player.getYRot(), mc.player.getXRot());
               }

               InventoryUtils.switchSlot(pearlMode, slot, previousSlot);
               NetworkUtils.sendSequencedPacket(
                  sequence -> new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, sequence, mc.player.getYRot(), mc.player.getXRot()), this::serverSend
               );
               this.serverSend(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
               InventoryUtils.switchBack(pearlMode, slot, previousSlot);
            }
         }
      }
   }

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (!this.shouldRunOnProxy() && !this.getNull() && (mc.gui == null || mc.gui.screen() == null)) {
         this.checkHoldBind(this.fireworkBind, this::throwFirework);
         this.checkHoldBind(this.pearlsBind, this::throwPearl);
         if (this.xpBind.getValue() != 0 && !this.xpBind.getMode().equals("Bind")) {
            boolean held = KeyboardUtils.isBindDown(this.xpBind.getValue());
            this.xpActive = this.xpBind.getMode().equals("Hold") == held;
         }

         this.tickXp();
      }
   }

   private void checkHoldBind(BindSetting bind, Runnable action) {
      if (bind.getValue() != 0 && !bind.getMode().equals("Bind")) {
         boolean held = KeyboardUtils.isBindDown(bind.getValue());
         if (bind.getMode().equals("Hold") == held) {
            action.run();
         }
      }
   }

   private void tickXp() {
      if (!GrimV3Inventory.totemTransaction()) {
         if (this.isXpActive()) {
            if (!this.shouldRunOnProxy()) {
               if (mc.player != null && mc.level != null) {
                  if (!this.botXpActive || System.nanoTime() >= this.nextBotXpBurstNanos) {
                     if (this.xpSwitch.getValue().equalsIgnoreCase("None") && !(mc.player.getMainHandItem().getItem() instanceof BlockItem)) {
                        Night.CHAT_MANAGER.tagged("You are currently not holding any experience bottles.", this.getName());
                        this.xpActive = false;
                        this.botXpActive = false;
                     } else if (this.xpTicks < this.xpDelay.getValue().intValue()) {
                        this.xpTicks++;
                     } else if (!this.needsExperience() && !this.xpAntiWaste.getValue().equals("None")) {
                        if (this.xpAntiWaste.getValue().equals("Disable")) {
                           this.xpActive = false;
                           this.botXpActive = false;
                        }
                     } else {
                        int slot = InventoryUtils.find(
                           Items.EXPERIENCE_BOTTLE,
                           0,
                           !this.xpSwitch.getValue().equalsIgnoreCase("AltSwap") && !this.xpSwitch.getValue().equalsIgnoreCase("AltPickup") ? 8 : 35
                        );
                        int previousSlot = mc.player.getInventory().getSelectedSlot();
                        if (slot == -1) {
                           Night.CHAT_MANAGER.tagged("No experience bottles could be found in your hotbar.", this.getName());
                           this.xpActive = false;
                           this.botXpActive = false;
                        } else {
                           SprintModule sprint = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(SprintModule.class) : null;
                           float yaw = sprint != null && sprint.isToggled() && sprint.isGrimCompensating() && sprint.getPendingYaw() != null
                              ? sprint.getPendingYaw()
                              : (
                                 Night.ROTATION_MANAGER != null && Night.ROTATION_MANAGER.getRotation() != null
                                    ? Night.ROTATION_MANAGER.getRotation().getYaw()
                                    : mc.player.getYRot()
                              );
                           float pitch = this.xpRotate.getValue() ? 90.0F : mc.player.getXRot();
                           if (this.xpRotate.getValue() && Night.ROTATION_MANAGER != null) {
                              Night.ROTATION_MANAGER.silentRotate(yaw, pitch);
                           }

                           long diagnosticNow = System.currentTimeMillis();
                           boolean diagnostic = this.botXpDebug.getValue();
                           String currentDiagnosticMode = this.botXpActive ? "bot" : "manual";
                           if (diagnostic && !currentDiagnosticMode.equals(this.diagnosticMode)) {
                              this.diagnosticMode = currentDiagnosticMode;
                              this.diagnosticBursts = this.diagnosticUses = 0;
                              this.lastXpDiagnostic = this.previousXpBurst = 0L;
                           }

                           boolean emitDiagnostic = diagnostic && diagnosticNow - this.lastXpDiagnostic >= 1000L;
                           String mainBefore = emitDiagnostic ? mc.player.getMainHandItem().toString() : "";
                           String offBefore = emitDiagnostic ? mc.player.getOffhandItem().toString() : "";
                           int serverBefore = emitDiagnostic ? Night.POSITION_MANAGER.getServerSlot() : -1;
                           boolean switchOk = InventoryUtils.switchSlot(this.xpSwitch.getValue(), slot, previousSlot);

                           for (int i = 0; i < this.xpRepeat.getValue().intValue(); i++) {
                              NetworkUtils.sendSequencedPacket(
                                 sequence -> new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, sequence, yaw, pitch), this::serverSend
                              );
                           }

                           this.serverSend(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
                           InventoryUtils.switchBack(this.xpSwitch.getValue(), slot, previousSlot);
                           if (this.botXpActive) {
                              this.botXpBurstCount++;
                              this.nextBotXpBurstNanos = System.nanoTime() + this.botXpBurstDelay.getValue().longValue() * 1000000L;
                           }

                           if (diagnostic) {
                              this.diagnosticBursts++;
                              this.diagnosticUses = this.diagnosticUses + this.xpRepeat.getValue().intValue();
                              if (emitDiagnostic) {
                                 AutoShopModule shop = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
                                 Night.LOGGER
                                    .info(
                                       "[XPDiag] player={} mode={} intervalMs={} bursts={} usePacketsRequested={} gapMs={} sourceSlot={} selectedBefore={} selectedAfter={} serverBefore={} serverAfter={} switchOk={} shop={} container={} mainBefore={} mainAfter={} offBefore={} offAfter={}",
                                       new Object[]{
                                          mc.player.getName().getString(),
                                          currentDiagnosticMode,
                                          this.lastXpDiagnostic == 0L ? 0L : diagnosticNow - this.lastXpDiagnostic,
                                          this.diagnosticBursts,
                                          this.diagnosticUses,
                                          this.previousXpBurst == 0L ? 0L : diagnosticNow - this.previousXpBurst,
                                          slot,
                                          previousSlot,
                                          mc.player.getInventory().getSelectedSlot(),
                                          serverBefore,
                                          Night.POSITION_MANAGER.getServerSlot(),
                                          switchOk,
                                          shop != null && shop.isRunning(),
                                          mc.player.hasContainerOpen(),
                                          mainBefore,
                                          mc.player.getMainHandItem(),
                                          offBefore,
                                          mc.player.getOffhandItem()
                                       }
                                    );
                                 this.lastXpDiagnostic = diagnosticNow;
                                 this.diagnosticBursts = this.diagnosticUses = 0;
                              }

                              this.previousXpBurst = diagnosticNow;
                           }

                           this.xpTicks = 0;
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void serverSend(Packet<?> packet) {
      Connection serverConn;
      if (this.isRunningOnProxy() && Night.PROXY_SERVER != null && (serverConn = Night.PROXY_SERVER.getServerConnection()) != null && serverConn.isConnected()) {
         ProxyServerTickListener.allowSend(() -> serverConn.send(packet));
      } else {
         mc.getConnection().send(packet);
      }
   }

   private boolean needsExperience() {
      for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD}) {
         ItemStack stack = mc.player.getItemBySlot(slot);
         if (!stack.isEmpty()
            && (stack.is(ItemTags.FOOT_ARMOR) || stack.is(ItemTags.LEG_ARMOR) || stack.is(ItemTags.CHEST_ARMOR) || stack.is(ItemTags.HEAD_ARMOR))
            && Math.round((stack.getMaxDamage() - stack.getDamageValue()) * 100.0F / stack.getMaxDamage()) < 100.0F) {
            return true;
         }
      }

      return false;
   }

   @Override
   public void onDisable() {
      this.nextBotXpBurstNanos = 0L;
      this.xpActive = false;
      this.botXpActive = false;
      this.xpTicks = 0;
   }
}
