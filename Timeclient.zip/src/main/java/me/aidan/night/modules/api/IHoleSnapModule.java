package night.modules.api;

public interface IHoleSnapModule {
   boolean isToggled();

   boolean isStepEnabled();
}
