package night.modules;

import java.util.ArrayList;
import java.util.List;

public final class ModulePin {
   private ModulePin() {
   }

   public static List<Module> pin(List<Module> var0) {
      int var1 = -1;

      for (int var2 = 0; var2 < var0.size(); var2++) {
         if ("Freeze".equals(((Module)var0.get(var2)).getName())) {
            var1 = var2;
            break;
         }
      }

      if (var1 >= 0 && var1 != 2) {
         ArrayList var4 = new ArrayList(var0);
         Module var3 = (Module)var4.remove(var1);
         var4.add(Math.min(2, var4.size()), var3);
         return var4;
      } else {
         return var0;
      }
   }
}
