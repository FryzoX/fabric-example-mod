package night.modules.impl.player;

import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.world.entity.Relative;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PacketReceiveEvent;
import night.mixins.accessors.PlayerPositionAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.utils.minecraft.PositionUtils;

@RegisterModule(
   name = "NoRotate",
   description = "Prevents the server from forcing rotations on you.",
   category = Module.Category.PLAYER
)
public class NoRotateModule extends Module {
   public BooleanSetting inBlocks = new BooleanSetting("InBlocks", "Whether or not to stop rotations whenever inside of a block.", false);
   public BooleanSetting spoof = new BooleanSetting("Spoof", "Sends rotation packets once you have been rubberbanded.", false);

   @SubscribeEvent
   public void onPacketReceive(PacketReceiveEvent event) {
      if (mc.player != null && mc.level != null) {
         if (this.inBlocks.getValue() || mc.level.getBlockState(PositionUtils.getFlooredPosition(mc.player)).canBeReplaced()) {
            if (event.getPacket() instanceof ClientboundPlayerPositionPacket packet2) {
               if (this.spoof.getValue()) {
                  Night.ROTATION_MANAGER.packetRotate(packet2.change().yRot(), packet2.change().xRot());
                  Night.ROTATION_MANAGER.packetRotate(mc.player.getYRot(), mc.player.getXRot());
               }

               ((PlayerPositionAccessor)packet2.change()).setYaw(mc.player.getYRot());
               ((PlayerPositionAccessor)packet2.change()).setPitch(mc.player.getXRot());
               packet2.relatives().remove(Relative.X_ROT);
               packet2.relatives().remove(Relative.Y_ROT);
            }
         }
      }
   }
}
