package night.modules;

import it.unimi.dsi.fastutil.objects.Reference2ReferenceOpenHashMap;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import lombok.Generated;
import night.Night;
import night.core.JarClassScanner;
import night.events.SubscribeEvent;
import night.events.impl.KeyInputEvent;
import night.events.impl.MouseInputEvent;
import night.events.impl.TickEvent;
import night.gui.api.Frame;
import night.gui.impl.ModuleButton;
import night.modules.impl.core.HUDModule;
import night.modules.impl.core.PingBypassModule;
import night.modules.impl.player.AutoShopModule;
import night.settings.Setting;
import night.settings.impl.CategorySetting;
import night.utils.IMinecraft;
import night.utils.input.KeyboardUtils;

public class ModuleManager implements IMinecraft {
   private final List<Module> modules = new ArrayList<>();
   private final Map<Class<? extends Module>, Module> moduleClasses = new Reference2ReferenceOpenHashMap();

   public ModuleManager() {
      try {
         Night.EVENT_HANDLER.subscribe(this);

         for (Class<?> clazz : JarClassScanner.findSubtypesOf(Module.class, Night.class)) {
            this.registerIfAnnotated(clazz);
         }

         Class<ModuleManager> clazz = ModuleManager.class;
         this.modules.sort(Comparator.comparing(Module::getName));
      } catch (Throwable var3) {
         throw var3;
      }
   }

   private void registerIfAnnotated(Class<?> clazz) throws NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException {
      if (clazz.getAnnotation(RegisterModule.class) != null) {
         Module module = (Module)clazz.getDeclaredConstructor().newInstance();
         this.register(module);
      }
   }

   public void register(Module module) {
      if (module != null) {
         try {
            for (Field field : module.getClass().getDeclaredFields()) {
               if (Setting.class.isAssignableFrom(field.getType())) {
                  if (!field.canAccess(module)) {
                     field.setAccessible(true);
                  }

                  Setting setting;
                  CategorySetting.Visibility v;
                  Setting.Visibility visibility;
                  if ((setting = (Setting)field.get(module)) != null
                     && !(
                        module instanceof HUDModule hud
                           && !HUDModule.isMusicAddonLoaded()
                           && (
                              setting == hud.musicHudCategory
                                 || setting == hud.musicHudPosition
                                 || (visibility = setting.getVisibility()) instanceof CategorySetting.Visibility
                                    && (v = (CategorySetting.Visibility)visibility).getValue() == hud.musicHudCategory
                           )
                     )) {
                     module.getSettings().add(setting);
                  }
               }
            }
         } catch (IllegalAccessException var10) {
            Night.LOGGER.error("Failed to register settings for module " + module.getName(), var10);
         }

         module.getSettings().add(module.chatNotify);
         module.getSettings().add(module.drawn);
         if (!module.isPersistent() && true) {
            module.getSettings().add(module.bind);
         }

         if (!this.modules.contains(module)) {
            this.modules.add(module);
            this.moduleClasses.put((Class<? extends Module>)module.getClass(), module);
            this.modules.sort(Comparator.comparing(Module::getName));
            if (Night.CLICK_GUI != null) {
               for (Frame frame : Night.CLICK_GUI.getFrames()) {
                  if (frame.getCategory() == module.getCategory() && !(module instanceof PingBypassModule)) {
                     frame.getButtons().add(new ModuleButton(module, frame, frame.getHeight()));
                  }
               }
            }
         }
      }
   }

   public void unregister(Module module) {
      if (module != null) {
         if (module.isToggled()) {
            module.setToggled(false);
         }

         this.modules.remove(module);
         this.moduleClasses.remove(module.getClass());
      }
   }

   @SubscribeEvent
   public void onKeyInput(KeyInputEvent event) {
      if (mc.gui == null || mc.gui.screen() == null) {
         this.modules.stream().filter(m -> m.getBind() == event.getKey() && m.bind.getMode().equals("Bind")).forEach(m -> m.setToggled(!m.isToggled()));
         AutoShopModule autoShop = this.getModule(AutoShopModule.class);
         if (autoShop != null) {
            autoShop.handleKey(event.getKey());
         }
      }
   }

   @SubscribeEvent
   public void onMouseInput(MouseInputEvent event) {
      if (mc.gui == null || mc.gui.screen() == null) {
         this.modules.stream().filter(m -> m.getBind() == -event.getButton() - 1 && m.bind.getMode().equals("Bind")).forEach(m -> m.setToggled(!m.isToggled()));
         AutoShopModule autoShop = this.getModule(AutoShopModule.class);
         if (autoShop != null) {
            autoShop.handleKey(-event.getButton() - 1);
         }
      }
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (mc.gui == null || mc.gui.screen() == null) {
         for (Module module : this.modules) {
            String mode = module.bind.getMode();
            if (!mode.equals("Bind") && module.getBind() != 0) {
               boolean held = KeyboardUtils.isBindDown(module.getBind());
               boolean shouldBeToggled = mode.equals("Hold") == held;
               if (module.isToggled() != shouldBeToggled) {
                  module.setToggled(shouldBeToggled);
               }
            }
         }
      }
   }

   public List<Module> getModules(Module.Category category) {
      return ModulePin.pin(this.modules.stream().filter(m -> m.getCategory() == category).toList());
   }

   public Module getModule(String name) {
      return this.modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
   }

   public <T extends Module> T getModule(Class<T> clazz) {
      return (T)this.moduleClasses.get(clazz);
   }

   @Generated
   public List<Module> getModules() {
      return this.modules;
   }

   @Generated
   public Map<Class<? extends Module>, Module> getModuleClasses() {
      return this.moduleClasses;
   }
}
