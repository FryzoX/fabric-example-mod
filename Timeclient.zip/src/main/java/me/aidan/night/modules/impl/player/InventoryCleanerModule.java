package night.modules.impl.player;

import java.util.ArrayList;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.ShulkerBoxMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import night.events.SubscribeEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.settings.impl.WhitelistSetting;

@RegisterModule(
   name = "InventoryCleaner",
   description = "Auto-drops unwanted items from your inventory each tick.",
   category = Module.Category.PLAYER
)
public class InventoryCleanerModule extends Module {
   public ModeSetting mode = new ModeSetting(
      "Mode",
      "WhiteList = drop items IN list. BlackList = drop items NOT in list. All = drop everything.",
      "WhiteList",
      new String[]{"WhiteList", "BlackList", "All"}
   );
   public WhitelistSetting whitelist = new WhitelistSetting("Whitelist", "Items this mode's WhiteList/BlackList compares against.", WhitelistSetting.Type.ITEMS);
   public BooleanSetting ignoreHotbar = new BooleanSetting("IgnoreHotbar", "Skip hotbar slots (0-8) when cleaning.", true);
   public BooleanSetting throwWorse = new BooleanSetting(
      "ThrowWorse", "Drop lower-tier duplicate tools/armor of the same type (e.g. diamond+iron pickaxe -> drop iron).", true
   );
   public BooleanSetting others = new BooleanSetting("Others", "Also drop from other open GUIs like Chest, Shulker, EnderChest.", false);
   public BooleanSetting ignoreCustomName = new BooleanSetting(
      "IgnoreCustomName",
      "(With Others on) skip acting on custom-titled containers such as a shop GUI, except shulker boxes. Does not affect individual items.",
      false
   );
   public NumberSetting delay = new NumberSetting("Delay", "Tick delay between drop passes.", 1, 0, 20);
   public NumberSetting actionsPerTick = new NumberSetting("ActionsPerTick", "Max items to drop per pass.", 5, 1, 20);
   private int ticks = 0;

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (mc.player != null && mc.level != null && mc.gameMode != null) {
         if (!mc.player.isCreative()) {
            if (mc.player.containerMenu.getCarried().isEmpty()) {
               long now = System.currentTimeMillis();
               if (now - RekitModule.lastContainerActionMs >= 200L && now - InventorySorterModule.lastContainerActionMs >= 200L) {
                  boolean externalGui = mc.gui.screen() instanceof AbstractContainerScreen && !(mc.gui.screen() instanceof InventoryScreen);
                  if (this.ticks < this.delay.getValue().intValue()) {
                     this.ticks++;
                  } else {
                     this.ticks = 0;
                     int containerId = mc.player.containerMenu.containerId;
                     int actions = 0;
                     int maxActions = this.actionsPerTick.getValue().intValue();

                     for (int invSlot = 0; invSlot < 36 && actions < maxActions; invSlot++) {
                        int handlerSlot;
                        ItemStack stack;
                        if ((!this.ignoreHotbar.getValue() || invSlot > 8)
                           && !(stack = mc.player.getInventory().getItem(invSlot)).isEmpty()
                           && this.shouldDrop(stack)
                           && (handlerSlot = this.invToHandlerSlot(invSlot)) >= 0) {
                           this.throwSlot(containerId, handlerSlot);
                           actions++;
                        }
                     }

                     if (this.throwWorse.getValue() && actions < maxActions) {
                        actions += this.runThrowWorsePass(containerId, maxActions - actions);
                     }

                     boolean customShopGui = this.ignoreCustomName.getValue()
                        && this.hasCustomContainerTitle()
                        && !(mc.player.containerMenu instanceof ShulkerBoxMenu);
                     if (externalGui && this.others.getValue() && !customShopGui && actions < maxActions) {
                        int totalSlots = mc.player.containerMenu.slots.size();
                        int containerSlotCount = totalSlots - 36;

                        for (int slot = 0; slot < containerSlotCount && actions < maxActions; slot++) {
                           ItemStack stack = ((Slot)mc.player.containerMenu.slots.get(slot)).getItem();
                           if (!stack.isEmpty() && this.shouldDrop(stack)) {
                              this.throwSlot(containerId, slot);
                              actions++;
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void throwSlot(int containerId, int slot) {
      mc.gameMode.handleContainerInput(containerId, slot, 1, ContainerInput.THROW, mc.player);
   }

   private boolean hasCustomContainerTitle() {
      if (!(mc.gui.screen() instanceof AbstractContainerScreen screen2)) {
         return false;
      } else {
         Component title = screen2.getTitle();
         return title == null ? false : !(title.getContents() instanceof TranslatableContents);
      }
   }

   private boolean shouldDrop(ItemStack stack) {
      boolean listed = this.whitelist.isWhitelistContains(stack.getItem());
      String var3 = this.mode.getValue();

      return switch (var3) {
         case "All" -> true;
         case "BlackList" -> !listed;
         default -> listed;
      };
   }

   private int runThrowWorsePass(int containerId, int budget) {
      String[] suffixes = new String[]{"_pickaxe", "_axe", "_shovel", "_hoe", "_sword", "_helmet", "_chestplate", "_leggings", "_boots"};
      int remaining = budget;

      for (String suffix : suffixes) {
         if (remaining <= 0) {
            break;
         }

         ArrayList<int[]> group = new ArrayList<>();

         for (int invSlot = 0; invSlot < 36; invSlot++) {
            ItemStack stack;
            if ((!this.ignoreHotbar.getValue() || invSlot > 8)
               && !(stack = mc.player.getInventory().getItem(invSlot)).isEmpty()
               && BuiltInRegistries.ITEM.getKey(stack.getItem()).toString().endsWith(suffix)) {
               group.add(new int[]{invSlot, stack.getMaxDamage()});
            }
         }

         if (group.size() >= 2) {
            int maxDur = group.stream().mapToInt(e -> e[1]).max().orElse(0);

            for (int[] entry : group) {
               if (remaining <= 0) {
                  break;
               }

               int handlerSlot;
               if (entry[1] < maxDur && (handlerSlot = this.invToHandlerSlot(entry[0])) >= 0) {
                  this.throwSlot(containerId, handlerSlot);
                  remaining--;
               }
            }
         }
      }

      return budget - remaining;
   }

   private int invToHandlerSlot(int invSlot) {
      Inventory playerInv = mc.player.getInventory();

      for (Slot slot : mc.player.containerMenu.slots) {
         if (slot.container == playerInv && slot.getContainerSlot() == invSlot) {
            return slot.index;
         }
      }

      return -1;
   }
}
