package night.modules.impl.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PacketReceiveEvent;
import night.events.impl.PlayerMineEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.impl.movement.HoleSnapModule;
import night.modules.impl.movement.PhaseModule;
import night.modules.impl.player.AutoShopModule;
import night.modules.impl.player.KeyActionModule;
import night.modules.impl.player.ReplenishModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.settings.impl.StringSetting;
import night.utils.minecraft.BotPearlAccess;
import night.utils.minecraft.CenteringProgressTracker;
import night.utils.minecraft.EntityUtils;
import night.utils.minecraft.FootSupportGeometry;
import night.utils.minecraft.GrimV3Inventory;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.NetworkUtils;
import night.utils.minecraft.RecoveryLayerTracker;
import night.utils.minecraft.SoloBotDefensePolicy;
import night.utils.minecraft.SurroundNudgeTracker;
import night.utils.minecraft.SurroundPressureTracker;
import night.utils.minecraft.XpDefenseCoordinator;

@RegisterModule(
   name = "SoloBot",
   description = "Practice a one-on-one fight on the local training server.",
   category = Module.Category.COMBAT
)
public class SoloBotModule extends Module {
   public StringSetting server = new StringSetting("Server", "Server address where the bot is allowed to act.", "127.0.0.1:25566");
   public BooleanSetting approach = new BooleanSetting("Approach", "Walk toward the opponent until in crystal range.", true);
   public NumberSetting targetRange = new NumberSetting("TargetRange", "Maximum distance for acquiring and chasing the opponent.", 48.0, 6.0, 64.0);
   public ModeSetting movementMode = new ModeSetting(
      "Movement", "Hold position, seek a hole, or chase the opponent.", "Chase", new String[]{"Hold", "HoleSnap", "Chase"}
   );
   public BooleanSetting autoSurround = new BooleanSetting("AutoSurround", "Enable Surround while the opponent is nearby.", true);
   public NumberSetting surroundRange = new NumberSetting("SurroundRange", "Opponent distance that activates Surround.", 6.0, 2.0, 12.0);
   public BooleanSetting autoPhase = new BooleanSetting("AutoPhase", "Repeat Phase while the opponent is nearby and pearls are available.", true);
   public NumberSetting phaseRange = new NumberSetting("PhaseRange", "Opponent distance that activates Phase before Surround is active.", 6.0, 2.0, 16.0);
   public NumberSetting phaseDelay = new NumberSetting("PhaseDelay", "Minimum milliseconds between Phase attempts.", 1200, 250, 5000);
   public NumberSetting stopDistance = new NumberSetting("StopDistance", "Stop walking this many blocks from the opponent.", 3.5, 2.0, 16.0);
   public BooleanSetting autoPursuitPearl = new BooleanSetting(
      "PursuitPearl", "Throw a pearl toward a distant walking opponent; enemy pearls remain PearlChase's job.", true
   );
   public NumberSetting pursuitPearlRange = new NumberSetting("PursuitPearlRange", "Minimum opponent distance for an active chase pearl.", 14.0, 8.0, 40.0);
   public NumberSetting pursuitPearlDelay = new NumberSetting("PursuitPearlDelay", "Minimum seconds between active chase pearls.", 8.0, 3.0, 30.0);
   public NumberSetting escapePearlPitch = new NumberSetting(
      "EscapePearlPitch", "Direct escape throw pitch: positive looks down, negative looks up. No landing scan.", 10.0, -30.0, 45.0
   );
   public BooleanSetting autoArmorXp = new BooleanSetting("AutoArmorXP", "Use KeyAction XP when equipped armor durability becomes low.", true);
   public NumberSetting armorXpStart = new NumberSetting(
      "ArmorXPStart", "Start KeyAction XP when any equipped armor piece is at or below this durability percent.", 50.0, 35.0, 50.0
   );
   public NumberSetting armorXpStop = new NumberSetting(
      "ArmorXPStop", "Stop bot-owned KeyAction XP when equipped armor reaches this durability percent.", 85.0, 80.0, 90.0
   );
   public BooleanSetting pauseMinedSurround = new BooleanSetting(
      "PauseMinedSurround", "Hold Surround off after repeated side mining until occupied protection is lost or no longer safe.", true
   );
   private final SurroundPressureTracker pressure = new SurroundPressureTracker();
   private BlockPos occupiedCover;
   private BlockPos lostCover;
   private BlockPos pressureSide;
   private boolean pressurePaused;
   private long nextPressurePause;
   private long nextMinePressureDiagnostic;
   private long nextBlockPressureDiagnostic;
   private long nextPressureContextDiagnostic;
   private long lastPressureActivity;
   private long nextXpDefenseDiagnostic;
   private Object pressureWorld;
   private boolean enabledCrystal;
   private boolean enabledTotem;
   private boolean combatActivated;
   private boolean enabledSurround;
   private boolean[] previousShopEnabled;
   private String previousShopMode;
   private boolean savedSurroundFloor;
   private boolean savedSurroundUnderFeet;
   private boolean savedSurroundPearlDisable;
   private boolean savedSurroundJumpDisable;
   private boolean savedSurroundRubberbandDisable;
   private boolean savedSurroundSelfDisable;
   private boolean savedSurroundWhileEating;
   private boolean savedSurroundItemDisable;
   private boolean ownsSurroundSettings;
   private boolean enabledHoleSnap;
   private boolean enabledPearlChase;
   private String previousPearlChaseTarget;
   private long nextPursuitPearl;
   private long pearlFlightUntil;
   private Vec3 pearlLaunchPosition;
   private long nextHoleSnapAttempt;
   private long nextPhaseAttempt;
   private long nextSurroundAttempt;
   private long floorThreatUntil;
   private long nextEmergencyPhaseAttempt;
   private long nextPhaseDiagnostic;
   private long coverThreatUntil;
   private BlockPos phaseCoverTarget;
   private BlockPos phaseApproachCover;
   private long nextPhaseApproachDiagnostic;
   private Vec3 lastBotPosition;
   private final SurroundNudgeTracker surroundNudge = new SurroundNudgeTracker();
   private Vec3 nudgeStart;
   private Vec3 nudgeGoal;
   private long nudgeStartedAt;
   private final CenteringProgressTracker recoveryCenterProgress = new CenteringProgressTracker();
   private BlockPos recoveryCenterCover;
   private long phaseCenterDeadline;
   private BlockPos defenseAnchor;
   private Vec3 recoveryProgressPosition;
   private long recoveryProgressAt;
   private long recoveryGuardAt;
   private long nextRecoveryPearl;
   private boolean recoveryActive;
   private boolean recoveryPearlInFlight;
   private volatile boolean recoveryPositionPacketSeen;
   private long recoveryPearlThrownAt;
   private BlockPos recoveryIntendedLanding;
   private BlockPos recoveryFailedLanding;
   private boolean landingNeedsDefense;
   private boolean recoveryPhaseAttempted;
   private Vec3 recoveryLaunchPosition;
   private int stableRecoveryTicks;
   private int recoveryDefenseY = Integer.MIN_VALUE;
   private final RecoveryLayerTracker recoveryLayer = new RecoveryLayerTracker();
   private boolean recoverySeekBedrock;
   private long nextBedrockSearch;
   private long nextRecoveryDefenseDiagnostic;
   private String previousCrystalTargetMode;
   private String currentTargetName;
   private boolean armorRepairNeeded;
   private final XpDefenseCoordinator xpDefense = new XpDefenseCoordinator();
   private String lastXpCoordinationReason = "";
   private boolean lastXpCoordinationAllowed;
   private long nextXpCoordinationDiagnostic;
   private SoloBotModule.State state = SoloBotModule.State.IDLE;

   @Override
   public void onEnable() {
      this.setState(SoloBotModule.State.WAITING);
   }

   private void activateCombat() {
      if (!this.combatActivated) {
         AutoCrystalModule crystal = Night.MODULE_MANAGER.getModule(AutoCrystalModule.class);
         AutoTotemModule totem = Night.MODULE_MANAGER.getModule(AutoTotemModule.class);
         PearlChaseModule pearlChase = Night.MODULE_MANAGER.getModule(PearlChaseModule.class);
         SurroundModule surround = Night.MODULE_MANAGER.getModule(SurroundModule.class);
         this.previousCrystalTargetMode = crystal.targetMode.getValue();
         this.enabledCrystal = !crystal.isToggled();
         this.enabledTotem = !totem.isToggled();
         crystal.targetMode.setValue("Nearest");
         if (this.enabledCrystal) {
            crystal.setToggled(true);
         }

         if (this.enabledTotem) {
            totem.setToggled(true);
         }

         if (surround != null) {
            this.savedSurroundFloor = surround.floor.getValue();
            this.savedSurroundUnderFeet = surround.underFeet.getValue();
            this.savedSurroundPearlDisable = surround.pearlDisable.getValue();
            this.savedSurroundJumpDisable = surround.jumpDisable.getValue();
            this.savedSurroundRubberbandDisable = surround.rubberbandDisable.getValue();
            this.savedSurroundSelfDisable = surround.selfDisable.getValue();
            this.savedSurroundWhileEating = surround.whileEating.getValue();
            this.savedSurroundItemDisable = surround.itemDisable.getValue();
            surround.floor.setValue(true);
            surround.underFeet.setValue(true);
            surround.pearlDisable.setValue(false);
            surround.jumpDisable.setValue(false);
            surround.rubberbandDisable.setValue(false);
            surround.selfDisable.setValue(false);
            surround.whileEating.setValue(true);
            surround.itemDisable.setValue(false);
            this.ownsSurroundSettings = true;
         }

         if (pearlChase != null) {
            this.previousPearlChaseTarget = pearlChase.targetPlayer.getValue();
            this.enabledPearlChase = !pearlChase.isToggled();
            pearlChase.targetPlayer.setValue("");
         }

         AutoShopModule shop = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
         if (shop != null) {
            this.previousShopEnabled = new boolean[]{
               shop.totemBelowThreshold.getValue(),
               shop.crystalBelowThreshold.getValue(),
               shop.expBelowThreshold.getValue(),
               shop.obsidianBelowThreshold.getValue(),
               shop.enderPearlBelowThreshold.getValue()
            };
            this.previousShopMode = shop.restockMode.getValue();
            shop.totemBelowThreshold.setValue(true);
            shop.crystalBelowThreshold.setValue(true);
            shop.expBelowThreshold.setValue(true);
            shop.obsidianBelowThreshold.setValue(true);
            shop.enderPearlBelowThreshold.setValue(true);
            shop.restockMode.setValue("KitPercent");
         }

         this.combatActivated = true;
      }
   }

   @Override
   public void onDisable() {
      this.releaseMovement();
      this.deactivateCombat();
      this.setState(SoloBotModule.State.IDLE);
   }

   private void deactivateCombat() {
      if (this.combatActivated) {
         AutoCrystalModule crystal = Night.MODULE_MANAGER.getModule(AutoCrystalModule.class);
         AutoTotemModule totem = Night.MODULE_MANAGER.getModule(AutoTotemModule.class);
         PearlChaseModule pearlChase = Night.MODULE_MANAGER.getModule(PearlChaseModule.class);
         if (crystal != null) {
            if (this.previousCrystalTargetMode != null) {
               crystal.targetMode.setValue(this.previousCrystalTargetMode);
            }

            if (this.enabledCrystal) {
               crystal.setToggled(false);
            }
         }

         if (totem != null && this.enabledTotem) {
            totem.setToggled(false);
         }

         if (pearlChase != null) {
            if (this.previousPearlChaseTarget != null) {
               pearlChase.targetPlayer.setValue(this.previousPearlChaseTarget);
            }

            if (this.enabledPearlChase) {
               pearlChase.setToggled(false);
            }
         }

         SurroundModule surround = Night.MODULE_MANAGER.getModule(SurroundModule.class);
         HoleSnapModule holeSnap = Night.MODULE_MANAGER.getModule(HoleSnapModule.class);
         if (surround != null && this.enabledSurround && surround.isToggled()) {
            surround.setToggled(false);
         }

         if (surround != null && this.ownsSurroundSettings) {
            surround.floor.setValue(this.savedSurroundFloor);
            surround.underFeet.setValue(this.savedSurroundUnderFeet);
            surround.pearlDisable.setValue(this.savedSurroundPearlDisable);
            surround.jumpDisable.setValue(this.savedSurroundJumpDisable);
            surround.rubberbandDisable.setValue(this.savedSurroundRubberbandDisable);
            surround.selfDisable.setValue(this.savedSurroundSelfDisable);
            surround.whileEating.setValue(this.savedSurroundWhileEating);
            surround.itemDisable.setValue(this.savedSurroundItemDisable);
         }

         this.ownsSurroundSettings = false;
         if (holeSnap != null && this.enabledHoleSnap && holeSnap.isToggled()) {
            holeSnap.setToggled(false);
         }

         this.enabledSurround = false;
         this.enabledHoleSnap = false;
         this.enabledPearlChase = false;
         this.pearlFlightUntil = 0L;
         this.pearlLaunchPosition = null;
         this.floorThreatUntil = 0L;
         this.coverThreatUntil = 0L;
         this.pressure.reset();
         this.xpDefense.reset();
         this.lastXpCoordinationReason = "";
         this.surroundNudge.reset();
         this.nudgeStart = this.nudgeGoal = null;
         this.recoveryCenterProgress.reset();
         this.recoveryCenterCover = null;
         this.occupiedCover = this.lostCover = this.pressureSide = null;
         this.pressurePaused = false;
         this.nextPressurePause = this.nextXpDefenseDiagnostic = 0L;
         this.nextMinePressureDiagnostic = this.nextBlockPressureDiagnostic = this.nextPressureContextDiagnostic = this.lastPressureActivity = 0L;
         this.pressureWorld = null;
         this.phaseCoverTarget = null;
         this.phaseApproachCover = null;
         this.lastBotPosition = null;
         this.nextPhaseApproachDiagnostic = 0L;
         this.phaseCenterDeadline = 0L;
         this.defenseAnchor = null;
         this.currentTargetName = null;
         this.recoveryProgressPosition = null;
         this.recoveryProgressAt = 0L;
         this.recoveryGuardAt = 0L;
         this.nextRecoveryPearl = 0L;
         this.recoveryActive = false;
         this.recoveryPearlInFlight = false;
         this.recoveryPositionPacketSeen = false;
         this.recoveryPearlThrownAt = 0L;
         this.recoveryIntendedLanding = null;
         this.recoveryFailedLanding = null;
         this.landingNeedsDefense = false;
         this.recoveryPhaseAttempted = false;
         this.recoveryLaunchPosition = null;
         this.stableRecoveryTicks = 0;
         this.recoveryDefenseY = Integer.MIN_VALUE;
         this.recoveryLayer.reset();
         this.recoverySeekBedrock = false;
         this.nextBedrockSearch = 0L;
         this.nextRecoveryDefenseDiagnostic = 0L;
         this.armorRepairNeeded = false;
         this.xpDefense.reset();
         KeyActionModule keyAction = Night.MODULE_MANAGER.getModule(KeyActionModule.class);
         if (keyAction != null) {
            keyAction.setBotXpActive(false);
         }

         AutoShopModule shop = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
         if (shop != null && this.previousShopEnabled != null) {
            shop.totemBelowThreshold.setValue(this.previousShopEnabled[0]);
            shop.crystalBelowThreshold.setValue(this.previousShopEnabled[1]);
            shop.expBelowThreshold.setValue(this.previousShopEnabled[2]);
            shop.obsidianBelowThreshold.setValue(this.previousShopEnabled[3]);
            shop.enderPearlBelowThreshold.setValue(this.previousShopEnabled[4]);
            if (this.previousShopMode != null) {
               shop.restockMode.setValue(this.previousShopMode);
            }
         }

         this.previousShopEnabled = null;
         this.combatActivated = false;
      }
   }

   @SubscribeEvent
   public void onPlayerMine(PlayerMineEvent event) {
      if (mc.player != null && event.getPosition() != null) {
         if (event.getActorID() != mc.player.getId()) {
            BlockPos feet = mc.player.blockPosition();
            BlockPos mined = event.getPosition();
            this.pressure.mined(mined.asLong(), System.currentTimeMillis());
            long mineNow = System.currentTimeMillis();
            if (mined.getY() == feet.getY() && Math.abs(mined.getX() - feet.getX()) + Math.abs(mined.getZ() - feet.getZ()) == 1) {
               this.pressureSide = mined.immutable();
            }

            if (Math.abs(mined.getY() - feet.getY()) <= 1 && Math.abs(mined.getX() - feet.getX()) + Math.abs(mined.getZ() - feet.getZ()) <= 2) {
               this.lastPressureActivity = mineNow;
               if (mineNow >= this.nextMinePressureDiagnostic) {
                  Night.LOGGER
                     .info(
                        "[BotMineDiag] MINE player={} actor={} position={} feet={} tracker={}",
                        new Object[]{mc.player.getName().getString(), event.getActorID(), mined, feet, this.pressure.debugState(mined.asLong(), mineNow)}
                     );
                  this.nextMinePressureDiagnostic = mineNow + 500L;
               }
            }

            if (mined.equals(feet.below())) {
               this.floorThreatUntil = System.currentTimeMillis() + 1500L;
               this.coverThreatUntil = this.floorThreatUntil;
            } else if (mined.equals(feet) || mined.getY() == feet.getY() && Math.abs(mined.getX() - feet.getX()) + Math.abs(mined.getZ() - feet.getZ()) == 1) {
               this.coverThreatUntil = System.currentTimeMillis() + 1500L;
            }
         }
      }
   }

   @SubscribeEvent
   public void onPacketReceive(PacketReceiveEvent event) {
      Object world = mc.level;
      if (event.getPacket() instanceof ClientboundBlockUpdatePacket update) {
         BlockPos pos = update.getPos().immutable();
         boolean solid = this.isSurroundBlock(update.getBlockState().getBlock());
         mc.execute(() -> {
            if (this.isToggled() && mc.level == world) {
               this.observeProtection(pos, solid);
            }
         });
      } else if (event.getPacket() instanceof ClientboundSectionBlocksUpdatePacket updates) {
         updates.runUpdates((position, blockState) -> {
            BlockPos pos = position.immutable();
            boolean solidx = this.isSurroundBlock(blockState.getBlock());
            mc.execute(() -> {
               if (this.isToggled() && mc.level == world) {
                  this.observeProtection(pos, solidx);
               }
            });
         });
      }

      if (this.recoveryPearlInFlight && event.getPacket() instanceof ClientboundPlayerPositionPacket) {
         this.recoveryPositionPacketSeen = true;
      }
   }

   private void observeProtection(BlockPos pos, boolean solid) {
      if (mc.player != null && mc.level != null) {
         BlockPos feet = mc.player.blockPosition();
         long now = System.currentTimeMillis();
         boolean side = pos.getY() == feet.getY() && Math.abs(pos.getX() - feet.getX()) + Math.abs(pos.getZ() - feet.getZ()) == 1;
         if (!solid && this.occupiedCover != null && pos.equals(this.occupiedCover)) {
            this.lostCover = pos;
            this.occupiedCover = null;
            this.phaseCoverTarget = null;
            this.nextPhaseAttempt = 0L;
            this.nextEmergencyPhaseAttempt = 0L;
            Night.LOGGER.info("[BotCover] LOST occupied={} -> prioritize another Phase block", pos);
         }

         if (side) {
            boolean report = now >= this.nextBlockPressureDiagnostic;
            String before = report ? this.pressure.debugState(pos.asLong(), now) : "rate_limited";
            boolean detected = this.pressure.observe(pos.asLong(), solid, now);
            if (detected) {
               this.pressureSide = pos;
            }

            this.lastPressureActivity = now;
            if (report || detected) {
               Night.LOGGER
                  .info(
                     "[BotMineDiag] BLOCK player={} position={} incomingSolid={} detected={} before={} after={}",
                     new Object[]{mc.player.getName().getString(), pos, solid, detected, before, this.pressure.debugState(pos.asLong(), now)}
                  );
               this.nextBlockPressureDiagnostic = now + 250L;
            }
         }
      }
   }

   private void updateSurroundPressure(BlockPos feet, SurroundModule surround, long now) {
      if (this.pressureWorld != mc.level) {
         Night.LOGGER.info("[BotMineDiag] WORLD_RESET player={} previousHold={}", mc.player.getName().getString(), this.pressurePaused);
         this.pressure.reset();
         this.occupiedCover = this.lostCover = this.pressureSide = null;
         this.recoveryCenterProgress.reset();
         this.recoveryCenterCover = null;
         this.pressurePaused = false;
         this.nextPressurePause = 0L;
         this.pressureWorld = mc.level;
      }

      boolean centered = this.isCenteredInCover(feet);
      if (centered && !feet.equals(this.lostCover)) {
         this.occupiedCover = feet.immutable();
         this.lostCover = null;
      }

      if (this.occupiedCover != null && !this.isSurroundBlock(mc.level.getBlockState(this.occupiedCover).getBlock())) {
         this.lostCover = this.occupiedCover;
         this.occupiedCover = null;
         this.phaseCoverTarget = null;
         this.nextPhaseAttempt = this.nextEmergencyPhaseAttempt = 0L;
      }

      for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
         BlockPos side = feet.relative(d);
         this.pressure.seed(side.asLong(), this.isSurroundBlock(mc.level.getBlockState(side).getBlock()), now);
      }

      boolean intact = centered && this.lostCover == null && mc.player.onGround() && !mc.level.getBlockState(feet.below()).canBeReplaced();
      Long previousHeldCover = this.pressure.heldCoverKey();
      boolean hold = this.pressure.keepCoverHold(feet.asLong(), intact && this.pauseMinedSurround.getValue() && this.autoSurround.getValue());
      if (this.pressurePaused && !hold) {
         this.pressurePaused = false;
         this.nextSurroundAttempt = now;
         if (this.autoSurround.getValue() && mc.player.onGround() && !surround.isToggled()) {
            surround.setToggled(true);
            this.enabledSurround = true;
         }

         String reason = !this.pauseMinedSurround.getValue()
            ? "hold_option_off"
            : (
               !this.autoSurround.getValue()
                  ? "auto_surround_off"
                  : (
                     !this.isSurroundBlock(mc.level.getBlockState(feet).getBlock())
                        ? "current_cover_missing"
                        : (
                           this.lostCover != null
                              ? "lost_cover_record"
                              : (
                                 !centered
                                    ? "off_center"
                                    : (
                                       !mc.player.onGround()
                                          ? "airborne"
                                          : (mc.level.getBlockState(feet.below()).canBeReplaced() ? "support_missing" : "held_cell_changed")
                                    )
                              )
                        )
                  )
            );
         Night.LOGGER
            .info(
               "[BotCover] SURROUND_RESUME player={} reason={} feet={} previousHeld={} position={} centered={} ground={} support={} lostCover={}",
               new Object[]{
                  mc.player.getName().getString(),
                  reason,
                  feet,
                  previousHeldCover,
                  mc.player.position(),
                  centered,
                  mc.player.onGround(),
                  mc.level.getBlockState(feet.below()).getBlock(),
                  this.lostCover
               }
            );
      }

      if (hold && surround.isToggled()) {
         surround.setToggled(false);
         this.enabledSurround = false;
      }

      if (this.pauseMinedSurround.getValue()
         && this.autoSurround.getValue()
         && !this.pressurePaused
         && this.pressureSide != null
         && intact
         && surround.isToggled()
         && this.pressure.isPressured(this.pressureSide.asLong(), now)
         && this.pressureSide.getY() == feet.getY()
         && Math.abs(this.pressureSide.getX() - feet.getX()) + Math.abs(this.pressureSide.getZ() - feet.getZ()) == 1) {
         this.pressure.holdCover(feet.asLong());
         this.pressurePaused = true;
         this.nextPressurePause = now + 1500L;
         surround.setToggled(false);
         this.enabledSurround = false;
         Night.LOGGER.info("[BotCover] SURROUND_HOLD side={} cover={} until=protection_lost_or_displaced", this.pressureSide, feet);
         this.pressureSide = null;
      }

      if (now >= this.nextPressureContextDiagnostic && (this.pressurePaused || this.pressureSide != null || now - this.lastPressureActivity < 2000L)) {
         StringBuilder sides = new StringBuilder();

         for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
            BlockPos side = feet.relative(d);
            sides.append(d)
               .append('=')
               .append(side)
               .append('{')
               .append("worldSolid=")
               .append(this.isSurroundBlock(mc.level.getBlockState(side).getBlock()))
               .append(',')
               .append(this.pressure.debugState(side.asLong(), now))
               .append("} ");
         }

         Night.LOGGER
            .info(
               "[BotMineDiag] CONTEXT player={} feet={} position={} centered={} ground={} core={} support={} intact={} holdOption={} autoSurround={} surround={} paused={} candidate={} pauseGateMs={} sides={}",
               new Object[]{
                  mc.player.getName().getString(),
                  feet,
                  mc.player.position(),
                  centered,
                  mc.player.onGround(),
                  mc.level.getBlockState(feet).getBlock(),
                  mc.level.getBlockState(feet.below()).getBlock(),
                  intact,
                  this.pauseMinedSurround.getValue(),
                  this.autoSurround.getValue(),
                  surround.isToggled(),
                  this.pressurePaused,
                  this.pressureSide,
                  Math.max(0L, this.nextPressurePause - now),
                  sides
               }
            );
         this.nextPressureContextDiagnostic = now + 1000L;
      }
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (mc.player != null && mc.level != null && mc.getCurrentServer() != null && mc.getCurrentServer().ip.equalsIgnoreCase(this.server.getValue().trim())) {
         this.activateCombat();
         this.updateArmorXp();
         if (GrimV3Inventory.holdMovement()) {
            this.releaseMovement();
         } else {
            AutoCrystalModule crystal = Night.MODULE_MANAGER.getModule(AutoCrystalModule.class);
            if (!crystal.targetMode.getValue().equalsIgnoreCase("Nearest")) {
               crystal.targetMode.setValue("Nearest");
            }

            Player target = null;
            double bestDistance = this.targetRange.getValue().doubleValue() * this.targetRange.getValue().doubleValue();

            for (Player player : mc.level.players()) {
               if (player != mc.player && player.isAlive() && !player.isSpectator() && !EntityUtils.isGhost(player) && !this.isListedFriend(player)) {
                  double distance = player.distanceToSqr(mc.player);
                  if (!(distance > bestDistance)) {
                     bestDistance = distance;
                     target = player;
                  }
               }
            }

            PearlChaseModule pearlChaseTarget = Night.MODULE_MANAGER.getModule(PearlChaseModule.class);
            this.currentTargetName = target == null ? null : target.getName().getString();
            if (pearlChaseTarget != null) {
               String pearlTarget = this.currentTargetName == null ? (this.enabledPearlChase ? "" : this.previousPearlChaseTarget) : this.currentTargetName;
               if (!pearlChaseTarget.targetPlayer.getValue().equalsIgnoreCase(pearlTarget)) {
                  pearlChaseTarget.targetPlayer.setValue(pearlTarget);
               }

               if (this.enabledPearlChase) {
                  if (target != null && !pearlChaseTarget.isToggled()) {
                     pearlChaseTarget.setToggled(true);
                  } else if (target == null && pearlChaseTarget.isToggled()) {
                     pearlChaseTarget.setToggled(false);
                  }
               }
            }

            if (!mc.player.isAlive()) {
               this.releaseMovement();
               this.defenseAnchor = null;
               this.recoveryProgressPosition = null;
               this.recoveryGuardAt = 0L;
               SurroundModule surround = Night.MODULE_MANAGER.getModule(SurroundModule.class);
               if (this.enabledSurround && surround.isToggled()) {
                  surround.setToggled(false);
               }

               this.enabledSurround = false;
               this.setState(SoloBotModule.State.WAITING);
            } else {
               BlockPos feet = mc.player.blockPosition();
               boolean inHole = HoleSnapModule.isInHole(feet);
               SurroundModule surround = Night.MODULE_MANAGER.getModule(SurroundModule.class);
               HoleSnapModule holeSnap = Night.MODULE_MANAGER.getModule(HoleSnapModule.class);
               PhaseModule phase = Night.MODULE_MANAGER.getModule(PhaseModule.class);
               double dx = target == null ? 0.0 : target.getX() - mc.player.getX();
               double dz = target == null ? 0.0 : target.getZ() - mc.player.getZ();
               double distanceSquared = target == null ? Double.POSITIVE_INFINITY : dx * dx + dz * dz;
               long now = System.currentTimeMillis();
               if (this.lastBotPosition != null
                  && !this.recoveryPearlInFlight
                  && mc.player.onGround()
                  && mc.player.position().distanceToSqr(this.lastBotPosition) >= 4.0
                  && mc.level.getBlockState(feet.below()).getBlock() == Blocks.BEDROCK) {
                  this.landingNeedsDefense = true;
                  this.phaseCoverTarget = this.phaseApproachCover = null;
                  this.occupiedCover = this.lostCover = null;
                  this.defenseAnchor = feet;
                  Night.LOGGER.info("[BotPhaseApproach] POSITION_JUMP from={} to={} defend_without_target=true", this.lastBotPosition, feet);
               }

               this.lastBotPosition = mc.player.position();
               this.updateSurroundPressure(feet, surround, now);
               boolean bedrockFloor = mc.level.getBlockState(feet.below()).getBlock() == Blocks.BEDROCK;
               if (bedrockFloor && !this.recoveryPearlInFlight) {
                  if (this.defenseAnchor == null || this.defenseAnchor.getY() != feet.getY()) {
                     this.defenseAnchor = feet;
                  }

                  this.recoveryActive = false;
                  this.recoveryDefenseY = Integer.MIN_VALUE;
               }

               boolean displacedAbove = this.defenseAnchor != null && feet.getY() > this.defenseAnchor.getY() && !bedrockFloor;
               BlockPos recoverySupport = this.findRecoveryFootSupport();
               boolean stableLanding = this.recoveryLayer
                  .ready(feet.getY(), mc.player.onGround(), recoverySupport != null, bedrockFloor, mc.player.getY(), now);
               if (bedrockFloor && mc.player.onGround()) {
                  this.recoverySeekBedrock = false;
               }

               if ((displacedAbove || this.recoveryPearlInFlight) && stableLanding && this.recoveryDefenseY != feet.getY()) {
                  int oldLayer = this.recoveryDefenseY;
                  this.recoveryDefenseY = feet.getY();
                  if (this.phaseCoverTarget != null && this.phaseCoverTarget.getY() != feet.getY()) {
                     this.phaseCoverTarget = null;
                  }

                  this.phaseApproachCover = null;
                  this.recoveryCenterProgress.reset();
                  this.recoveryCenterCover = null;
                  Night.LOGGER
                     .info(
                        "[BotRecoveryDefense] RECAPTURE_LAYER player={} oldY={} newY={} feet={} bedrock={} actualSupport={}",
                        new Object[]{mc.player.getName().getString(), oldLayer, this.recoveryDefenseY, feet, bedrockFloor, recoverySupport}
                     );
               }

               boolean defendRecoveryLayer = SoloBotDefensePolicy.canDefendLayer(this.recoveryDefenseY, feet.getY(), mc.player.onGround());
               if (!mc.player.onGround() || (displacedAbove || this.recoveryPearlInFlight) && !defendRecoveryLayer) {
                  if (surround.isToggled()) {
                     surround.setToggled(false);
                  }

                  this.enabledSurround = false;
                  this.stableRecoveryTicks = 0;
                  this.landingNeedsDefense = true;
                  this.phaseCoverTarget = null;
               }

               boolean keepLowSurround = bedrockFloor
                  && mc.player.onGround()
                  && !this.landingNeedsDefense
                  && !this.recoveryPearlInFlight
                  && this.autoSurround.getValue()
                  && (target != null || this.armorRepairNeeded || this.landingNeedsDefense);
               if (keepLowSurround && !this.pressurePaused && !surround.isToggled() && now >= this.nextSurroundAttempt) {
                  surround.setToggled(true);
                  this.enabledSurround = true;
                  this.nextSurroundAttempt = now + 250L;
                  Night.LOGGER.info("[SoloBot] Maintain bedrock Surround at {} repairing={}", feet, this.armorRepairNeeded);
               }

               if (this.defenseAnchor == null && mc.level.getBlockState(feet.below()).getBlock() == Blocks.OBSIDIAN) {
                  for (int drop = 2; drop <= 8; drop++) {
                     if (mc.level.getBlockState(feet.below(drop)).getBlock() == Blocks.BEDROCK) {
                        this.defenseAnchor = feet.below(drop - 1);
                        break;
                     }
                  }
               }

               if (bedrockFloor
                  || this.recoveryCenterCover != null
                     && (
                        !this.isSurroundBlock(mc.level.getBlockState(this.recoveryCenterCover).getBlock())
                           || Math.hypot(mc.player.getX() - this.recoveryCenterCover.getX() - 0.5, mc.player.getZ() - this.recoveryCenterCover.getZ() - 0.5)
                              > 2.0
                     )) {
                  this.recoveryCenterProgress.reset();
                  this.recoveryCenterCover = null;
               }

               if (mc.player.onGround() && this.autoPhase.getValue() && !this.recoveryCenterProgress.blocked()) {
                  BlockPos entered = null;
                  double bestOverlap = 1.0E-4;

                  for (BlockPos candidate : new BlockPos[]{feet, feet.north(), feet.south(), feet.east(), feet.west()}) {
                     double overlap = this.protectiveOverlap(candidate);
                     if (overlap > bestOverlap) {
                        entered = candidate;
                        bestOverlap = overlap;
                     }
                  }

                  if (entered != null) {
                     this.phaseCoverTarget = null;
                     if (this.isCenteredInCover(entered)) {
                        this.occupiedCover = entered;
                        this.lostCover = null;
                        this.recoveryCenterProgress.reset();
                        this.recoveryCenterCover = null;
                     } else {
                        boolean elevatedRecovery = !bedrockFloor && (displacedAbove || this.recoveryActive || this.recoveryPearlInFlight);
                        double centerDistance = Math.hypot(entered.getX() + 0.5 - mc.player.getX(), entered.getZ() + 0.5 - mc.player.getZ());
                        if (elevatedRecovery) {
                           this.recoveryCenterCover = entered.immutable();
                        }

                        if (!elevatedRecovery || this.recoveryCenterProgress.continueCentering(entered.asLong(), centerDistance, now)) {
                           this.centerToward(entered.getX() + 0.5 - mc.player.getX(), entered.getZ() + 0.5 - mc.player.getZ());
                           this.setState(SoloBotModule.State.CENTERING);
                           if (now >= this.nextPhaseApproachDiagnostic) {
                              Night.LOGGER
                                 .info(
                                    "[BotPhaseApproach] ENTERED_CENTER cover={} overlap={} position={}",
                                    new Object[]{entered, bestOverlap, mc.player.position()}
                                 );
                              this.nextPhaseApproachDiagnostic = now + 1000L;
                           }

                           return;
                        }

                        this.recoveryActive = true;
                        this.landingNeedsDefense = true;
                        this.phaseCoverTarget = null;
                        this.releaseMovement();
                        Night.LOGGER
                           .info(
                              "[BotPhaseApproach] CENTER_STALLED player={} cover={} distance={} position={} next=recovery",
                              new Object[]{mc.player.getName().getString(), entered, centerDistance, mc.player.position()}
                           );
                     }
                  }
               }

               if (target != null
                  && this.lostCover != null
                  && this.phaseCoverTarget == null
                  && this.autoPhase.getValue()
                  && mc.player.onGround()
                  && !this.recoveryPearlInFlight
                  && !this.recoveryActive) {
                  Direction replacement = this.findSurroundDirection(feet, dx, dz);
                  AutoShopModule activeShop = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
                  PearlChaseModule chase = Night.MODULE_MANAGER.getModule(PearlChaseModule.class);
                  if (chase != null) {
                     chase.cancelPendingForDefense();
                  }

                  if (replacement != null
                     && !phase.isToggled()
                     && now >= this.nextEmergencyPhaseAttempt
                     && !mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))
                     && BotPearlAccess.find() >= 0
                     && !mc.player.hasContainerOpen()
                     && mc.gui.screen() == null
                     && (activeShop == null || !activeShop.isRunning())
                     && (chase == null || !chase.isChasingEnemyPearl())) {
                     if (!this.preparePhaseApproach(feet, replacement, now)) {
                        return;
                     }

                     this.nextEmergencyPhaseAttempt = now + 500L;
                     this.nextPhaseAttempt = now + this.phaseDelay.getValue().longValue();
                     phase.phaseTowards(replacement.toYRot());
                     this.phaseCoverTarget = feet.relative(replacement);
                     this.phaseCenterDeadline = now + 2200L;
                     Night.LOGGER.info("[BotCover] REPHASE lost={} destination={}", this.lostCover, this.phaseCoverTarget);
                     this.releaseMovement();
                     this.setState(SoloBotModule.State.PHASING);
                     return;
                  }
               }

               if (!this.handleXpSurroundNudge(feet, surround, now)) {
                  if (!this.handleRecovery(feet, target, surround, phase, now)) {
                     if (target == null) {
                        this.releaseMovement();
                        this.setState(SoloBotModule.State.WAITING);
                     } else if (now < this.pearlFlightUntil
                        && this.pearlLaunchPosition != null
                        && mc.player.position().distanceToSqr(this.pearlLaunchPosition) < 9.0) {
                        this.releaseMovement();
                        this.setState(SoloBotModule.State.PEARLING);
                     } else {
                        if (this.pearlFlightUntil != 0L
                           && this.pearlLaunchPosition != null
                           && mc.player.position().distanceToSqr(this.pearlLaunchPosition) >= 9.0) {
                           this.defenseAnchor = null;
                        }

                        this.pearlFlightUntil = 0L;
                        if (this.defenseAnchor != null
                           && (Math.abs(feet.getX() - this.defenseAnchor.getX()) > 6 || Math.abs(feet.getZ() - this.defenseAnchor.getZ()) > 6)) {
                           this.defenseAnchor = null;
                        }

                        this.recoveryProgressPosition = null;
                        this.recoveryGuardAt = 0L;
                        if (this.defenseAnchor != null && feet.getY() < this.defenseAnchor.getY()) {
                           this.defenseAnchor = feet;
                        }

                        if (mc.level.getBlockState(feet.below()).canBeReplaced()) {
                           this.phaseCoverTarget = null;
                           if (this.autoSurround.getValue() && !surround.isToggled()) {
                              surround.setToggled(true);
                              this.enabledSurround = true;
                           }

                           BlockPos escape = this.findSafeFloorEscape(feet, target);
                           if (escape != null) {
                              this.moveToward(escape.getX() + 0.5 - mc.player.getX(), escape.getZ() + 0.5 - mc.player.getZ());
                              this.setState(SoloBotModule.State.ESCAPING);
                           } else {
                              this.releaseMovement();
                              this.setState(SoloBotModule.State.DEFENDING);
                           }
                        } else {
                           if (this.phaseCoverTarget != null) {
                              BlockPos cover = this.phaseCoverTarget;
                              if (this.isCenteredInCover(cover)) {
                                 Night.LOGGER.info("[SoloBot] Phase centered in cover {} pos={}", cover, mc.player.position());
                                 this.occupiedCover = cover;
                                 this.lostCover = null;
                                 this.phaseCoverTarget = null;
                              } else {
                                 if (SoloBotDefensePolicy.waitForCentering(
                                    this.isSurroundBlock(mc.level.getBlockState(cover).getBlock()),
                                    this.protectiveOverlap(cover),
                                    mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL)),
                                    now,
                                    this.phaseCenterDeadline
                                 )) {
                                    double overlap = this.protectiveOverlap(cover);
                                    if (overlap > 1.0E-4) {
                                       this.centerToward(cover.getX() + 0.5 - mc.player.getX(), cover.getZ() + 0.5 - mc.player.getZ());
                                       this.setState(SoloBotModule.State.CENTERING);
                                    } else {
                                       this.releaseMovement();
                                       this.setState(SoloBotModule.State.PHASING);
                                    }

                                    return;
                                 }

                                 this.phaseCoverTarget = null;
                                 this.nextPhaseAttempt = Math.max(now, this.nextEmergencyPhaseAttempt);
                                 Night.LOGGER
                                    .info(
                                       "[BotPhaseApproach] COMBAT_RETRY_READY oldTarget={} overlap={} cooldown={} retryGateMs={}",
                                       new Object[]{
                                          cover,
                                          this.protectiveOverlap(cover),
                                          mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL)),
                                          Math.max(0L, this.nextPhaseAttempt - now)
                                       }
                                    );
                              }
                           }

                           if (this.pressurePaused) {
                              this.releaseMovement();
                              this.setState(SoloBotModule.State.FIGHTING);
                           } else {
                              BlockPos descent = this.findSafeDescent(feet, target);
                              if (descent != null) {
                                 if (!keepLowSurround) {
                                    if (this.enabledSurround && surround.isToggled()) {
                                       surround.setToggled(false);
                                    }

                                    this.enabledSurround = false;
                                 }

                                 this.moveToward(descent.getX() + 0.5 - mc.player.getX(), descent.getZ() + 0.5 - mc.player.getZ());
                                 this.setState(SoloBotModule.State.DESCENDING);
                              } else if (mc.level.getBlockState(feet.below()).getBlock() == Blocks.OBSIDIAN && this.hasOpenSide(feet)) {
                                 if (this.enabledSurround && surround.isToggled()) {
                                    surround.setToggled(false);
                                 }

                                 this.enabledSurround = false;
                                 this.releaseMovement();
                                 this.setState(SoloBotModule.State.HOLDING);
                              } else if (!mc.player.onGround()) {
                                 this.releaseMovement();
                                 this.setState(SoloBotModule.State.DESCENDING);
                              } else {
                                 double engageRange = this.surroundRange.getValue().doubleValue() + (this.enabledSurround ? 1.0 : 0.0);
                                 boolean nearSurround = distanceSquared <= engageRange * engageRange;
                                 if (nearSurround
                                    && this.defenseAnchor == null
                                    && mc.player.onGround()
                                    && !mc.level.getBlockState(feet.below()).canBeReplaced()) {
                                    this.defenseAnchor = feet;
                                 }

                                 if (this.autoSurround.getValue()
                                    && !this.pressurePaused
                                    && (nearSurround || keepLowSurround)
                                    && !surround.isToggled()
                                    && now >= this.nextSurroundAttempt) {
                                    surround.setToggled(true);
                                    this.enabledSurround = true;
                                    this.nextSurroundAttempt = now + 250L;
                                 } else if ((!this.autoSurround.getValue() || !nearSurround && !keepLowSurround)
                                    && this.enabledSurround
                                    && surround.isToggled()) {
                                    surround.setToggled(false);
                                    this.enabledSurround = false;
                                 }

                                 AutoShopModule shop = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
                                 PearlChaseModule pearlChase = Night.MODULE_MANAGER.getModule(PearlChaseModule.class);
                                 boolean nearPhase = distanceSquared <= this.phaseRange.getValue().doubleValue() * this.phaseRange.getValue().doubleValue();
                                 boolean floorThreat = now < this.floorThreatUntil || mc.level.getBlockState(feet.below()).canBeReplaced();
                                 Direction phaseDirection = this.findSurroundDirection(feet, dx, dz);
                                 boolean inPhaseEngagement = nearPhase
                                    || surround.isToggled()
                                    || distanceSquared < this.pursuitPearlRange.getValue().doubleValue() * this.pursuitPearlRange.getValue().doubleValue();
                                 if (this.autoPhase.getValue() && inPhaseEngagement && !this.isSafelyCenteredInCover(feet) && now >= this.nextPhaseDiagnostic) {
                                    String reason = phaseDirection == null
                                       ? "no adjacent protective block"
                                       : (
                                          BotPearlAccess.find() < 0
                                             ? "no pearl in inventory"
                                             : (
                                                mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))
                                                   ? "pearl cooldown"
                                                   : (
                                                      pearlChase != null && pearlChase.isChasingEnemyPearl()
                                                         ? "PearlChase active"
                                                         : (shop != null && shop.isRunning() ? "shop active" : "ready")
                                                   )
                                             )
                                       );
                                    Night.LOGGER.info("[SoloBot] Phase check: {} at {} side={}", new Object[]{reason, feet, phaseDirection});
                                    this.nextPhaseDiagnostic = now + 5000L;
                                 }

                                 if (!this.autoPhase.getValue()
                                    || !inPhaseEngagement
                                    || phaseDirection == null
                                    || this.isSafelyCenteredInCover(feet)
                                    || phase.isToggled()
                                    || pearlChase != null && pearlChase.isChasingEnemyPearl()
                                    || mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))
                                    || mc.player.hasContainerOpen()
                                    || mc.gui.screen() != null
                                    || shop != null && shop.isRunning()
                                    || BotPearlAccess.find() == -1
                                    || now < this.nextPhaseAttempt && (!floorThreat || now < this.nextEmergencyPhaseAttempt)) {
                                    if (now < this.coverThreatUntil) {
                                       this.releaseMovement();
                                       this.setState(SoloBotModule.State.DEFENDING);
                                    } else if (nearSurround && this.autoSurround.getValue()) {
                                       this.releaseMovement();
                                       this.setState(SoloBotModule.State.FIGHTING);
                                    } else if (this.autoPursuitPearl.getValue()
                                       && this.approach.getValue()
                                       && this.movementMode.getValue().equalsIgnoreCase("Chase")
                                       && Math.sqrt(distanceSquared) >= this.pursuitPearlRange.getValue().doubleValue()
                                       && now >= this.nextPursuitPearl
                                       && (pearlChase == null || !pearlChase.isChasingEnemyPearl())
                                       && !mc.player.hasContainerOpen()
                                       && mc.gui.screen() == null
                                       && (shop == null || !shop.isRunning())
                                       && this.throwPursuitPearl(target)) {
                                       this.nextPursuitPearl = now + this.pursuitPearlDelay.getValue().longValue() * 1000L;
                                       this.pearlFlightUntil = now + 3500L;
                                       this.pearlLaunchPosition = mc.player.position();
                                       this.releaseMovement();
                                       this.setState(SoloBotModule.State.PEARLING);
                                    } else if (this.movementMode.getValue().equalsIgnoreCase("Hold")) {
                                       this.releaseMovement();
                                       this.setState(SoloBotModule.State.HOLDING);
                                    } else if (this.movementMode.getValue().equalsIgnoreCase("HoleSnap")) {
                                       this.releaseMovement();
                                       if (!holeSnap.isToggled() && System.currentTimeMillis() >= this.nextHoleSnapAttempt) {
                                          holeSnap.setToggled(true);
                                          this.enabledHoleSnap = true;
                                          this.nextHoleSnapAttempt = System.currentTimeMillis() + 3000L;
                                       }

                                       this.setState(holeSnap.isToggled() ? SoloBotModule.State.SEEKING_HOLE : SoloBotModule.State.HOLDING);
                                    } else if (inHole && this.movementMode.getValue().equalsIgnoreCase("Hold")) {
                                       this.releaseMovement();
                                       this.setState(SoloBotModule.State.FIGHTING);
                                    } else {
                                       double stop = this.stopDistance.getValue().doubleValue();
                                       if (!this.approach.getValue() || distanceSquared <= stop * stop || mc.gui.screen() != null) {
                                          this.releaseMovement();
                                          this.setState(SoloBotModule.State.FIGHTING);
                                       } else if (this.state != SoloBotModule.State.APPROACHING && distanceSquared < (stop + 1.0) * (stop + 1.0)) {
                                          this.releaseMovement();
                                          this.setState(SoloBotModule.State.FIGHTING);
                                       } else {
                                          SoloBotModule.MovementStep step = this.getSafeStep(dx, dz);
                                          if (step == SoloBotModule.MovementStep.BLOCKED) {
                                             this.releaseMovement();
                                             this.setState(SoloBotModule.State.HOLDING);
                                          } else {
                                             this.moveToward(dx, dz);
                                             this.setState(SoloBotModule.State.APPROACHING);
                                          }
                                       }
                                    }
                                 } else if (this.preparePhaseApproach(feet, phaseDirection, now)) {
                                    if (this.defenseAnchor == null) {
                                       this.defenseAnchor = feet;
                                    }

                                    this.nextPhaseAttempt = now + this.phaseDelay.getValue().longValue();
                                    this.nextEmergencyPhaseAttempt = now + 500L;
                                    phase.phaseTowards(phaseDirection.toYRot());
                                    this.phaseCoverTarget = feet.relative(phaseDirection);
                                    this.phaseCenterDeadline = now + 2200L;
                                    Night.LOGGER.info("[SoloBot] Requested Phase toward {} at {}", phaseDirection, feet);
                                    this.releaseMovement();
                                    this.setState(SoloBotModule.State.PHASING);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      } else {
         this.releaseMovement();
         this.deactivateCombat();
         this.setState(SoloBotModule.State.WAITING);
      }
   }

   private boolean throwPursuitPearl(Player target) {
      this.nextPursuitPearl = System.currentTimeMillis() + 1500L;
      if (mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))) {
         return false;
      } else {
         int slot = BotPearlAccess.find();
         if (slot < 0) {
            return false;
         } else {
            Vec3 predicted = target.position().add(target.getDeltaMovement().scale(5.0));
            double dx = predicted.x - mc.player.getX();
            double dz = predicted.z - mc.player.getZ();
            double distance = Math.hypot(dx, dz);
            if (distance < 8.0) {
               return false;
            } else {
               double wantedX = predicted.x - dx / distance * 4.0;
               double wantedZ = predicted.z - dz / distance * 4.0;
               Vec3 landing = null;
               double bestCellScore = Double.POSITIVE_INFINITY;
               BlockPos center = BlockPos.containing(wantedX, target.getY(), wantedZ);

               for (int x = -2; x <= 2; x++) {
                  for (int z = -2; z <= 2; z++) {
                     for (int y = -3; y <= 1; y++) {
                        BlockPos floor = center.offset(x, y - 1, z);
                        BlockPos standing = floor.above();
                        if (mc.level.getBlockState(floor).getBlock() == Blocks.BEDROCK
                           && mc.level.getBlockState(standing).canBeReplaced()
                           && mc.level.getBlockState(standing.above()).canBeReplaced()) {
                           Vec3 candidate = new Vec3(standing.getX() + 0.5, standing.getY(), standing.getZ() + 0.5);
                           double opponentDistance = Math.hypot(candidate.x - target.getX(), candidate.z - target.getZ());
                           if (!(opponentDistance < 3.0) && !(candidate.distanceTo(mc.player.position()) < 8.0)) {
                              double score = Math.hypot(candidate.x - wantedX, candidate.z - wantedZ) + Math.abs(candidate.y - target.getY());
                              if (score < bestCellScore) {
                                 bestCellScore = score;
                                 landing = candidate;
                              }
                           }
                        }
                     }
                  }
               }

               return landing != null && this.throwPearlAtLanding(landing, "pursuit " + target.getName().getString());
            }
         }
      }
   }

   private boolean throwRecoveryPearl(Player target) {
      if (mc.level.getBlockState(mc.player.blockPosition().below()).getBlock() != Blocks.BEDROCK
         && this.defenseAnchor != null
         && !mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))
         && BotPearlAccess.find() >= 0) {
         double dx = target == null ? -Math.sin(Math.toRadians(mc.player.getYRot())) : mc.player.getX() - target.getX();
         double dz = target == null ? Math.cos(Math.toRadians(mc.player.getYRot())) : mc.player.getZ() - target.getZ();
         if (Math.hypot(dx, dz) < 0.1) {
            dx = 1.0;
            dz = 0.0;
         }

         if (this.recoverySeekBedrock) {
            return this.throwRecoveryToBedrock();
         } else {
            this.recoveryIntendedLanding = null;
            float preferredYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
            float configuredPitch = this.escapePearlPitch.getValue().floatValue();

            for (float offset : new float[]{0.0F, 45.0F, -45.0F, 90.0F, -90.0F, 135.0F, -135.0F, 180.0F}) {
               for (float pitch : new float[]{configuredPitch, -10.0F, -25.0F}) {
                  float yaw = preferredYaw + offset;
                  if (this.clearNearEscape(yaw, pitch)) {
                     Night.LOGGER
                        .info(
                           "[BotRecoveryStage] player={} stage=FAST_ESCAPE feet={} yaw={} pitch={} nearCheck=2.0 landingScan=false",
                           new Object[]{mc.player.getName().getString(), mc.player.blockPosition(), yaw, pitch}
                        );
                     return this.sendPearl(new SoloBotModule.PursuitSolution(yaw, pitch, null), "escape-direct");
                  }
               }
            }

            this.nextRecoveryPearl = System.currentTimeMillis() + 250L;
            Night.LOGGER
               .info("[BotRecoveryStage] player={} stage=FAST_ESCAPE_BLOCKED feet={} next=defend", mc.player.getName().getString(), mc.player.blockPosition());
            return false;
         }
      } else {
         return false;
      }
   }

   private BlockPos findRecoveryFootSupport() {
      if (mc.player != null && mc.level != null) {
         AABB feetBox = mc.player.getBoundingBox();
         int minX = (int)Math.floor(feetBox.minX + 1.0E-5);
         int maxX = (int)Math.floor(feetBox.maxX - 1.0E-5);
         int minZ = (int)Math.floor(feetBox.minZ + 1.0E-5);
         int maxZ = (int)Math.floor(feetBox.maxZ - 1.0E-5);

         for (int y = (int)Math.floor(feetBox.minY - 0.05); y <= (int)Math.floor(feetBox.minY); y++) {
            for (int x = minX; x <= maxX; x++) {
               for (int z = minZ; z <= maxZ; z++) {
                  BlockPos block = new BlockPos(x, y, z);
                  BlockState state = mc.level.getBlockState(block);
                  if (this.isSurroundBlock(state.getBlock())) {
                     for (AABB part : state.getCollisionShape(mc.level, block).toAabbs()) {
                        AABB surface = part.move(block);
                        if (FootSupportGeometry.touches(
                           feetBox.minX,
                           feetBox.minZ,
                           feetBox.maxX,
                           feetBox.maxZ,
                           feetBox.minY,
                           surface.minX,
                           surface.minZ,
                           surface.maxX,
                           surface.maxZ,
                           surface.maxY
                        )) {
                           return block;
                        }
                     }
                  }
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private boolean clearNearEscape(float yaw, float pitch) {
      double yr = Math.toRadians(yaw);
      double pr = Math.toRadians(pitch);
      Vec3 direction = new Vec3(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
      Vec3 eye = mc.player.getEyePosition();
      return mc.level.clip(new ClipContext(eye, eye.add(direction.scale(2.0)), Block.COLLIDER, Fluid.NONE, mc.player)).getType() == Type.MISS;
   }

   private boolean throwRecoveryToBedrock() {
      long now = System.currentTimeMillis();
      if (now < this.nextBedrockSearch) {
         return false;
      } else {
         this.nextBedrockSearch = now + 500L;
         BlockPos feet = mc.player.blockPosition();
         List<Vec3> candidates = new ArrayList<>();

         for (int x = -12; x <= 12; x++) {
            for (int z = -12; z <= 12; z++) {
               if (x * x + z * z <= 144) {
                  for (int drop = 1; drop <= 8; drop++) {
                     BlockPos floor = feet.offset(x, -drop, z);
                     if (mc.level.getBlockState(floor).getBlock() == Blocks.BEDROCK
                        && mc.level.getBlockState(floor.above()).canBeReplaced()
                        && mc.level.getBlockState(floor.above(2)).canBeReplaced()) {
                        Vec3 landing = new Vec3(floor.getX() + 0.5, floor.getY() + 1.0, floor.getZ() + 0.5);
                        AABB body = new AABB(landing.x - 0.3, landing.y, landing.z - 0.3, landing.x + 0.3, landing.y + 1.8, landing.z + 0.3);
                        if (mc.level.noCollision(body)) {
                           candidates.add(landing);
                        }
                        break;
                     }
                  }
               }
            }
         }

         candidates.sort(Comparator.comparingDouble(p -> p.distanceToSqr(mc.player.position())));

         for (int i = 0; i < Math.min(3, candidates.size()); i++) {
            Vec3 landing = candidates.get(i);
            if (this.throwPearlAtLanding(landing, "recovery")) {
               this.recoveryIntendedLanding = BlockPos.containing(landing);
               Night.LOGGER
                  .info(
                     "[BotRecoveryStage] player={} stage=BEDROCK_THROW intended={} candidateCount={}",
                     new Object[]{mc.player.getName().getString(), landing, candidates.size()}
                  );
               return true;
            }
         }

         Night.LOGGER
            .info(
               "[BotRecoveryStage] player={} stage=BEDROCK_NO_ROUTE feet={} candidateCount={} next=defend",
               new Object[]{mc.player.getName().getString(), feet, candidates.size()}
            );
         return false;
      }
   }

   private boolean throwPearlAtLanding(Vec3 landing, String purpose) {
      int slot = BotPearlAccess.find();
      if (slot < 0) {
         return false;
      } else {
         Vec3 eye = mc.player.getEyePosition();
         double aimX = landing.x - eye.x;
         double aimZ = landing.z - eye.z;
         float yaw = (float)Math.toDegrees(Math.atan2(-aimX, aimZ));
         SoloBotModule.PursuitSolution best = null;
         double bestScore = Double.POSITIVE_INFINITY;
         float pitch = -70.0F;

         while (pitch <= (!purpose.equals("escape") && !purpose.equals("recovery") ? 20.0F : 85.0F)) {
            double pitchRadians = Math.toRadians(pitch);
            double yawRadians = Math.toRadians(yaw);
            Vec3 velocity = new Vec3(-Math.sin(yawRadians) * Math.cos(pitchRadians), -Math.sin(pitchRadians), Math.cos(yawRadians) * Math.cos(pitchRadians))
               .scale(1.5)
               .add(mc.player.getDeltaMovement().x, 0.0, mc.player.getDeltaMovement().z);
            Vec3 pos = eye;

            for (int tick = 0; tick < 100; tick++) {
               Vec3 next = pos.add(velocity);
               BlockHitResult hit = mc.level.clip(new ClipContext(pos, next, Block.COLLIDER, Fluid.NONE, mc.player));
               if (hit.getType() != Type.MISS) {
                  boolean shortEscape = purpose.equals("escape")
                     && Math.hypot(hit.getLocation().x - mc.player.getX(), hit.getLocation().z - mc.player.getZ()) >= 2.0
                     && Math.hypot(hit.getLocation().x - mc.player.getX(), hit.getLocation().z - mc.player.getZ()) <= 8.5;
                  if (!shortEscape
                     && (
                        purpose.equals("escape")
                           || hit.getDirection() != Direction.UP
                           || mc.level.getBlockState(hit.getBlockPos()).getBlock() != Blocks.BEDROCK
                           || purpose.equals("recovery") && !(Math.abs(hit.getLocation().y - landing.y) <= 0.25)
                     )) {
                     break;
                  }

                  double score = hit.getLocation().distanceTo(landing);
                  if (score < 2.0 && score < bestScore) {
                     bestScore = score;
                     best = new SoloBotModule.PursuitSolution(yaw, pitch, hit.getLocation());
                  }
                  break;
               }

               pos = next;
               velocity = velocity.scale(0.99).subtract(0.0, 0.03, 0.0);
            }

            pitch += purpose.equals("recovery") ? 2.0F : 1.0F;
         }

         return best == null ? false : this.sendPearl(best, purpose);
      }
   }

   private boolean sendPearl(SoloBotModule.PursuitSolution best, String purpose) {
      int slot = BotPearlAccess.find();
      if (slot < 0) {
         return false;
      } else {
         int previousSlot = mc.player.getInventory().getSelectedSlot();
         String pearlMode = BotPearlAccess.mode();
         if (!InventoryUtils.switchSlot(pearlMode, slot, previousSlot)) {
            return false;
         } else {
            boolean var8;
            try {
               Night.ROTATION_MANAGER.packetRotate(best.yaw(), best.pitch(), true);
               float throwYaw = best.yaw();
               float throwPitch = best.pitch();
               NetworkUtils.sendSequencedPacket(sequence -> new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, sequence, throwYaw, throwPitch));
               mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
               Night.LOGGER
                  .info(
                     "[SoloBot] {} pearl from={} floor={} intended={} pitch={}",
                     new Object[]{
                        purpose, mc.player.blockPosition(), mc.level.getBlockState(mc.player.blockPosition().below()).getBlock(), best.landing(), best.pitch()
                     }
                  );
               var8 = true;
            } finally {
               InventoryUtils.switchBack(pearlMode, slot, previousSlot);
            }

            return var8;
         }
      }
   }

   private Direction findSurroundDirection(BlockPos feet, double dx, double dz) {
      if (this.phaseApproachCover != null) {
         for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
            BlockPos cover = feet.relative(d);
            if (cover.equals(this.phaseApproachCover)
               && !cover.equals(this.lostCover)
               && !this.pressure.isPressured(cover.asLong(), System.currentTimeMillis())
               && this.isSurroundBlock(mc.level.getBlockState(cover).getBlock())
               && this.isSurroundBlock(mc.level.getBlockState(cover.below()).getBlock())) {
               return d;
            }
         }

         this.phaseApproachCover = null;
      }

      Direction best = null;
      double bestScore = Double.NEGATIVE_INFINITY;

      for (Direction direction : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
         BlockPos cover = feet.relative(direction);
         if (!cover.equals(this.lostCover) && !this.pressure.isPressured(cover.asLong(), System.currentTimeMillis())) {
            net.minecraft.world.level.block.Block block = mc.level.getBlockState(cover).getBlock();
            if (this.isSurroundBlock(block)) {
               net.minecraft.world.level.block.Block support = mc.level.getBlockState(cover.below()).getBlock();
               if (this.isSurroundBlock(support)) {
                  double score = block == Blocks.BEDROCK ? 4.0 : 0.0;
                  score += support == Blocks.BEDROCK ? 3.0 : 0.0;

                  for (Direction neighbor : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
                     if (this.isSurroundBlock(mc.level.getBlockState(cover.relative(neighbor)).getBlock())) {
                        score++;
                     }
                  }

                  score -= (dx * direction.getStepX() + dz * direction.getStepZ()) / Math.max(1.0, Math.hypot(dx, dz));
                  if (score > bestScore) {
                     bestScore = score;
                     best = direction;
                  }
               }
            }
         }
      }

      return best;
   }

   public boolean needsPhaseDefense() {
      if (this.isToggled() && this.autoPhase.getValue() && mc.player != null && mc.level != null) {
         boolean lost = this.occupiedCover != null && !this.isSurroundBlock(mc.level.getBlockState(this.occupiedCover).getBlock());
         return (lost || this.lostCover != null || this.landingNeedsDefense || this.recoveryActive) && !this.isSafelyCenteredInCover(mc.player.blockPosition());
      } else {
         return false;
      }
   }

   private boolean preparePhaseApproach(BlockPos feet, Direction direction, long now) {
      BlockPos cover = feet.relative(direction);
      if (!cover.equals(this.phaseApproachCover)) {
         this.phaseApproachCover = cover;
         Night.LOGGER.info("[BotPhaseApproach] LOCK cover={} position={}", cover, mc.player.position());
      }

      if (!mc.player.onGround()) {
         this.releaseMovement();
         this.setState(SoloBotModule.State.DEFENDING);
         return false;
      } else if (this.protectiveOverlap(feet) > 1.0E-4 && !this.isCenteredInCover(feet)) {
         this.centerToward(feet.getX() + 0.5 - mc.player.getX(), feet.getZ() + 0.5 - mc.player.getZ());
         this.setState(SoloBotModule.State.CENTERING);
         if (now >= this.nextPhaseApproachDiagnostic) {
            Night.LOGGER.info("[BotPhaseApproach] CENTER_CURRENT cover={} position={}", feet, mc.player.position());
            this.nextPhaseApproachDiagnostic = now + 1000L;
         }

         return false;
      } else if (this.protectiveOverlap(cover) > 1.0E-4) {
         this.centerToward(cover.getX() + 0.5 - mc.player.getX(), cover.getZ() + 0.5 - mc.player.getZ());
         this.setState(SoloBotModule.State.CENTERING);
         return false;
      } else {
         AABB box = mc.player.getBoundingBox();
         boolean singleCell = box.minX >= feet.getX() && box.maxX <= feet.getX() + 1.0 && box.minZ >= feet.getZ() && box.maxZ <= feet.getZ() + 1.0;

         for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
            singleCell &= this.isSurroundBlock(mc.level.getBlockState(feet.relative(d)).getBlock());
         }

         SoloBotDefensePolicy.PhaseApproach approach = SoloBotDefensePolicy.phaseApproach(
            mc.player.getX(), mc.player.getZ(), cover.getX(), cover.getZ(), direction.getStepX(), direction.getStepZ(), box.getXsize() / 2.0
         );
         if (!singleCell && !approach.ready()) {
            double dx = approach.x() - mc.player.getX();
            double dz = approach.z() - mc.player.getZ();
            double length = Math.hypot(dx, dz);
            boolean safe = length > 0.01;

            for (double travel = 0.0; safe && travel < length + 0.12; travel += 0.12) {
               double step = Math.min(travel, length);
               AABB moved = box.move(dx / length * step, 0.0, dz / length * step);
               if (!mc.level.noCollision(moved)) {
                  safe = false;
                  break;
               }

               for (double x : new double[]{moved.minX + 0.001, moved.maxX - 0.001}) {
                  for (double z : new double[]{moved.minZ + 0.001, moved.maxZ - 0.001}) {
                     if (!this.isSurroundBlock(mc.level.getBlockState(BlockPos.containing(x, moved.minY - 0.01, z)).getBlock())) {
                        safe = false;
                     }
                  }
               }
            }

            if (now >= this.nextPhaseApproachDiagnostic) {
               Night.LOGGER
                  .info(
                     "[BotPhaseApproach] {} cover={} from={} approach=({}, {})",
                     new Object[]{safe ? "MOVE_TO_FACE" : "BLOCKED_PATH", cover, mc.player.position(), approach.x(), approach.z()}
                  );
               this.nextPhaseApproachDiagnostic = now + 1000L;
            }

            if (safe) {
               this.centerToward(dx, dz);
               this.setState(SoloBotModule.State.CENTERING);
            } else {
               this.releaseMovement();
               this.setState(SoloBotModule.State.DEFENDING);
            }

            return false;
         } else {
            this.phaseApproachCover = null;
            this.releaseMovement();
            Night.LOGGER.info("[BotPhaseApproach] READY cover={} singleCell={} position={}", new Object[]{cover, singleCell, mc.player.position()});
            return true;
         }
      }
   }

   private boolean isSafelyCenteredInCover(BlockPos feet) {
      if (mc.level.getBlockState(feet.below()).canBeReplaced()) {
         return false;
      } else if (this.isCenteredInCover(feet)) {
         return true;
      } else {
         for (Direction direction : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
            if (this.isCenteredInCover(feet.relative(direction))) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean isCenteredInCover(BlockPos cover) {
      return this.isSurroundBlock(mc.level.getBlockState(cover).getBlock())
         && Math.abs(mc.player.getX() - cover.getX() - 0.5) <= 0.22
         && Math.abs(mc.player.getZ() - cover.getZ() - 0.5) <= 0.22
         && Math.abs(mc.player.getY() - cover.getY()) < 0.6;
   }

   private double protectiveOverlap(BlockPos side) {
      AABB box = mc.player.getBoundingBox();
      if (!this.isSurroundBlock(mc.level.getBlockState(side).getBlock())) {
         return 0.0;
      } else {
         double overlapX = Math.max(0.0, Math.min(box.maxX, side.getX() + 1.0) - Math.max(box.minX, (double)side.getX()));
         double overlapZ = Math.max(0.0, Math.min(box.maxZ, side.getZ() + 1.0) - Math.max(box.minZ, (double)side.getZ()));
         double overlapY = Math.max(0.0, Math.min(box.maxY, side.getY() + 1.0) - Math.max(box.minY, (double)side.getY()));
         return overlapY >= 0.5 ? overlapX * overlapZ : 0.0;
      }
   }

   private BlockPos findSafeFloorEscape(BlockPos feet, Player target) {
      BlockPos best = null;
      double bestScore = Double.POSITIVE_INFINITY;

      for (Direction direction : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
         BlockPos candidate = feet.relative(direction);
         if (this.isSurroundBlock(mc.level.getBlockState(candidate.below()).getBlock())
            && mc.level.getBlockState(candidate).canBeReplaced()
            && mc.level.getBlockState(candidate.above()).canBeReplaced()) {
            double enemyDistance = Math.hypot(target.getX() - candidate.getX() - 0.5, target.getZ() - candidate.getZ() - 0.5);
            if (!(enemyDistance < 3.0)) {
               double score = Math.abs(enemyDistance - Math.max(4.0, this.stopDistance.getValue().doubleValue()));
               if (score < bestScore) {
                  bestScore = score;
                  best = candidate;
               }
            }
         }
      }

      return best;
   }

   private boolean isSurroundBlock(net.minecraft.world.level.block.Block block) {
      return block == Blocks.OBSIDIAN
         || block == Blocks.BEDROCK
         || block == Blocks.CRYING_OBSIDIAN
         || block == Blocks.ENDER_CHEST
         || block == Blocks.NETHERITE_BLOCK
         || block == Blocks.RESPAWN_ANCHOR
         || block == Blocks.ANCIENT_DEBRIS
         || block == Blocks.ENCHANTING_TABLE
         || block == Blocks.ANVIL
         || block == Blocks.CHIPPED_ANVIL
         || block == Blocks.DAMAGED_ANVIL;
   }

   private boolean isListedFriend(Player player) {
      return Night.FRIEND_MANAGER != null && Night.FRIEND_MANAGER.getFriends().stream().anyMatch(name -> name.equalsIgnoreCase(player.getName().getString()));
   }

   private SoloBotModule.MovementStep getSafeStep(double dx, double dz) {
      double length = Math.hypot(dx, dz);
      if (length < 0.01) {
         return SoloBotModule.MovementStep.BLOCKED;
      } else if (!mc.player.onGround()) {
         return this.state == SoloBotModule.State.APPROACHING ? SoloBotModule.MovementStep.WALK : SoloBotModule.MovementStep.BLOCKED;
      } else {
         double nx = dx / length;
         double nz = dz / length;

         for (double distance : new double[]{0.8, 1.3}) {
            BlockPos ahead = BlockPos.containing(mc.player.getX() + nx * distance, mc.player.getY(), mc.player.getZ() + nz * distance);
            if (!mc.level.getBlockState(ahead.above()).canBeReplaced()) {
               return SoloBotModule.MovementStep.BLOCKED;
            }

            if (!mc.level.getBlockState(ahead).canBeReplaced()) {
               if (!mc.level.getBlockState(ahead.above(2)).canBeReplaced()) {
                  return SoloBotModule.MovementStep.BLOCKED;
               }

               return SoloBotModule.MovementStep.BLOCKED;
            }

            if (mc.level.getBlockState(ahead.below()).canBeReplaced()) {
               return SoloBotModule.MovementStep.BLOCKED;
            }
         }

         return SoloBotModule.MovementStep.WALK;
      }
   }

   private BlockPos findSafeDescent(BlockPos feet, Player target) {
      if (!mc.player.onGround()) {
         return null;
      } else {
         BlockPos best = null;
         double bestScore = Double.POSITIVE_INFINITY;

         for (Direction direction : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
            for (int drop = 1; drop <= 3; drop++) {
               BlockPos lowerFeet = feet.relative(direction).below(drop);
               if (mc.level.getBlockState(lowerFeet.below()).getBlock() == Blocks.BEDROCK) {
                  boolean clear = true;

                  for (int y = lowerFeet.getY(); y <= feet.getY() + 1; y++) {
                     if (!mc.level.getBlockState(new BlockPos(lowerFeet.getX(), y, lowerFeet.getZ())).canBeReplaced()) {
                        clear = false;
                        break;
                     }
                  }

                  if (clear) {
                     double targetDistance = Math.hypot(target.getX() - lowerFeet.getX() - 0.5, target.getZ() - lowerFeet.getZ() - 0.5);
                     double preferredDistance = Math.max(4.0, this.stopDistance.getValue().doubleValue());
                     double score = Math.abs(targetDistance - preferredDistance) + drop * 0.5;
                     if (targetDistance < 3.0) {
                        score += 20.0;
                     }

                     if (score < bestScore) {
                        bestScore = score;
                        best = lowerFeet;
                     }
                  }
               }
            }
         }

         return best;
      }
   }

   private boolean hasOpenSide(BlockPos feet) {
      for (Direction direction : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
         if (mc.level.getBlockState(feet.relative(direction)).canBeReplaced() && mc.level.getBlockState(feet.relative(direction).below()).canBeReplaced()) {
            return true;
         }
      }

      return false;
   }

   private boolean handleXpSurroundNudge(BlockPos feet, SurroundModule surround, long now) {
      KeyActionModule key = Night.MODULE_MANAGER.getModule(KeyActionModule.class);
      boolean eligible = this.autoSurround.getValue()
         && this.autoPhase.getValue()
         && surround.isToggled()
         && !this.pressurePaused
         && key != null
         && key.isXpActive()
         && mc.player.onGround()
         && mc.level.getBlockState(feet).canBeReplaced()
         && this.isSurroundBlock(mc.level.getBlockState(feet.below()).getBlock())
         && !this.isSafelyCenteredInCover(feet)
         && this.phaseCoverTarget == null
         && this.findSurroundDirection(feet, 0.0, 0.0) == null;

      for (BlockPos cell : new BlockPos[]{feet, feet.north(), feet.south(), feet.east(), feet.west()}) {
         if (this.protectiveOverlap(cell) > 1.0E-4) {
            eligible = false;
         }
      }

      boolean start = this.surroundNudge.shouldStart(eligible, now);
      if (!eligible) {
         if (this.nudgeStart != null) {
            this.releaseMovement();
         }

         this.nudgeStart = this.nudgeGoal = null;
         return false;
      } else {
         if (start) {
            double toCenterX = feet.getX() + 0.5 - mc.player.getX();
            double toCenterZ = feet.getZ() + 0.5 - mc.player.getZ();
            double length = Math.hypot(toCenterX, toCenterZ);
            double[][] choices = length > 0.01
               ? new double[][]{{toCenterX / length * 0.12, toCenterZ / length * 0.12}, {0.12, 0.0}, {-0.12, 0.0}, {0.0, 0.12}, {0.0, -0.12}}
               : new double[][]{{0.12, 0.0}, {-0.12, 0.0}, {0.0, 0.12}, {0.0, -0.12}};

            for (double[] delta : choices) {
               if (this.safeNudgePath(feet, delta[0], delta[1])) {
                  this.nudgeStart = mc.player.position();
                  this.nudgeGoal = this.nudgeStart.add(delta[0], 0.0, delta[1]);
                  this.nudgeStartedAt = now;
                  Night.LOGGER
                     .info(
                        "[BotSurroundNudge] START player={} position={} goal={} xp=unchanged",
                        new Object[]{mc.player.getName().getString(), this.nudgeStart, this.nudgeGoal}
                     );
                  break;
               }
            }
         }

         if (this.nudgeStart == null) {
            return false;
         } else {
            double travelled = Math.hypot(mc.player.getX() - this.nudgeStart.x, mc.player.getZ() - this.nudgeStart.z);
            if (SurroundNudgeTracker.keepMoving(travelled, now - this.nudgeStartedAt)
               && this.safeNudgePath(feet, this.nudgeGoal.x - mc.player.getX(), this.nudgeGoal.z - mc.player.getZ())) {
               this.centerToward(this.nudgeGoal.x - mc.player.getX(), this.nudgeGoal.z - mc.player.getZ());
               this.setState(SoloBotModule.State.DEFENDING);
               return true;
            } else {
               this.releaseMovement();
               Night.LOGGER
                  .info(
                     "[BotSurroundNudge] STOP player={} travelled={} elapsedMs={}",
                     new Object[]{mc.player.getName().getString(), travelled, now - this.nudgeStartedAt}
                  );
               this.nudgeStart = this.nudgeGoal = null;
               return false;
            }
         }
      }
   }

   private boolean safeNudgePath(BlockPos feet, double dx, double dz) {
      for (int sample = 0; sample <= 4; sample++) {
         double scale = sample / 4.0;
         double x = mc.player.getX() + dx * scale;
         double z = mc.player.getZ() + dz * scale;
         if ((int)Math.floor(x) != feet.getX() || (int)Math.floor(z) != feet.getZ()) {
            return false;
         }

         AABB box = mc.player.getBoundingBox().move(dx * scale, 0.0, dz * scale);
         if (!mc.level.noCollision(box)) {
            return false;
         }

         for (double cx : new double[]{box.minX + 0.001, box.maxX - 0.001}) {
            for (double cz : new double[]{box.minZ + 0.001, box.maxZ - 0.001}) {
               if (!this.isSurroundBlock(mc.level.getBlockState(BlockPos.containing(cx, box.minY - 0.01, cz)).getBlock())) {
                  return false;
               }
            }
         }
      }

      return true;
   }

   private void moveToward(double dx, double dz) {
      this.releaseMovement();
      mc.player.setYRot((float)Math.toDegrees(Math.atan2(-dx, dz)));
      mc.options.keyUp.setDown(true);
      mc.options.keyJump.setDown(false);
   }

   private void centerToward(double dx, double dz) {
      SoloBotDefensePolicy.CenterInput input = SoloBotDefensePolicy.centerInput(dx, dz, mc.player.getYRot());
      mc.options.keyUp.setDown(input.forward());
      mc.options.keyDown.setDown(input.backward());
      mc.options.keyLeft.setDown(input.left());
      mc.options.keyRight.setDown(input.right());
      mc.options.keyJump.setDown(false);
   }

   private void releaseMovement() {
      mc.options.keyUp.setDown(false);
      mc.options.keyDown.setDown(false);
      mc.options.keyLeft.setDown(false);
      mc.options.keyRight.setDown(false);
      mc.options.keyJump.setDown(false);
   }

   private void setState(SoloBotModule.State next) {
      this.logXpDefense(next);
      if (this.state != next) {
         Night.LOGGER.info("[SoloBot] {} -> {} target={}", new Object[]{this.state, next, this.currentTargetName == null ? "none" : this.currentTargetName});
         this.state = next;
      }
   }

   private void logXpDefense(SoloBotModule.State next) {
      if (mc.player != null && mc.level != null && Night.MODULE_MANAGER != null) {
         KeyActionModule key = Night.MODULE_MANAGER.getModule(KeyActionModule.class);
         long now = System.currentTimeMillis();
         if ((this.armorRepairNeeded || key != null && key.isXpActive()) && now >= this.nextXpDefenseDiagnostic) {
            this.nextXpDefenseDiagnostic = now + 1000L;
            SurroundModule surround = Night.MODULE_MANAGER.getModule(SurroundModule.class);
            PhaseModule phase = Night.MODULE_MANAGER.getModule(PhaseModule.class);
            AutoShopModule shop = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
            BlockPos feet = mc.player.blockPosition();
            Direction candidate = this.findSurroundDirection(feet, 0.0, 0.0);
            String gate = !this.autoPhase.getValue()
               ? "auto_phase_off"
               : (
                  this.isSafelyCenteredInCover(feet)
                     ? "already_centered"
                     : (
                        this.recoveryPearlInFlight
                           ? "recovery_pearl_flight"
                           : (
                              !mc.player.onGround()
                                 ? "airborne"
                                 : (
                                    mc.player.hasContainerOpen() || mc.gui.screen() != null
                                       ? "gui_or_container"
                                       : (
                                          shop != null && shop.isRunning()
                                             ? "shop_running"
                                             : (
                                                mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))
                                                   ? "pearl_cooldown"
                                                   : (
                                                      BotPearlAccess.find() < 0
                                                         ? "no_pearl"
                                                         : (
                                                            candidate == null
                                                               ? "no_protective_destination"
                                                               : (phase.isToggled() ? "phase_active" : "check_bot_state_or_delay")
                                                         )
                                                   )
                                             )
                                       )
                                 )
                           )
                     )
               );
            Night.LOGGER
               .info(
                  "[BotXPDefense] player={} state={} feet={} ground={} repair={} xp={} surround={} surroundSwitch={} obsidianHotbar={} obsidianInventory={} hold={} landing={} recovery={} phaseTarget={} candidate={} phaseGate={} nextPhaseMs={}",
                  new Object[]{
                     mc.player.getName().getString(),
                     next,
                     feet,
                     mc.player.onGround(),
                     this.armorRepairNeeded,
                     key != null && key.isXpActive(),
                     surround.isToggled(),
                     surround.autoSwitch.getValue(),
                     InventoryUtils.find(Items.OBSIDIAN, 0, 8),
                     InventoryUtils.findInventory(Items.OBSIDIAN),
                     this.pressurePaused,
                     this.landingNeedsDefense,
                     this.recoveryActive,
                     this.phaseCoverTarget,
                     candidate,
                     gate,
                     Math.max(0L, this.nextPhaseAttempt - now)
                  }
               );
         }
      }
   }

   private BlockPos findRecoveryStep(BlockPos feet) {
      if (this.defenseAnchor == null) {
         return null;
      } else {
         int drop = feet.getY() - this.defenseAnchor.getY();
         if (drop >= 1 && drop <= 2) {
            if (Math.abs(feet.getX() - this.defenseAnchor.getX()) + Math.abs(feet.getZ() - this.defenseAnchor.getZ()) <= 1
               && mc.level.getBlockState(this.defenseAnchor.below()).getBlock() == Blocks.BEDROCK) {
               boolean clear = true;

               for (int y = this.defenseAnchor.getY(); y <= feet.getY() + 1; y++) {
                  if (!mc.level.getBlockState(new BlockPos(this.defenseAnchor.getX(), y, this.defenseAnchor.getZ())).canBeReplaced()) {
                     clear = false;
                     break;
                  }
               }

               if (clear) {
                  return this.defenseAnchor;
               }
            }

            for (Direction direction : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
               BlockPos lower = feet.relative(direction).below(drop);
               if (mc.level.getBlockState(lower.below()).getBlock() == Blocks.BEDROCK) {
                  boolean clear = true;

                  for (int yx = lower.getY(); yx <= feet.getY() + 1; yx++) {
                     if (!mc.level.getBlockState(new BlockPos(lower.getX(), yx, lower.getZ())).canBeReplaced()) {
                        clear = false;
                        break;
                     }
                  }

                  if (clear) {
                     return lower;
                  }
               }
            }

            return null;
         } else {
            return null;
         }
      }
   }

   private boolean tryRecoveryDescent(BlockPos feet, SurroundModule surround, long now) {
      if (this.defenseAnchor != null && mc.player.onGround() && this.recoveryGuardAt != Long.MAX_VALUE) {
         BlockPos step = this.findRecoveryStep(feet);
         if (step == null) {
            return false;
         } else {
            if (this.recoveryProgressPosition == null) {
               this.recoveryProgressPosition = mc.player.position();
               this.recoveryGuardAt = now;
               Night.LOGGER
                  .info(
                     "[BotRecoveryReturn] START player={} from={} to={} pearlPending={}",
                     new Object[]{mc.player.getName().getString(), feet, step, this.recoveryPearlInFlight}
                  );
            }

            double progress = mc.player.position().distanceTo(this.recoveryProgressPosition);
            if (!SoloBotDefensePolicy.recoveryDescentAllowed(feet.getY() - step.getY(), true, now - this.recoveryGuardAt, progress)) {
               this.recoveryGuardAt = Long.MAX_VALUE;
               this.releaseMovement();
               Night.LOGGER.info("[BotRecoveryReturn] BLOCKED player={} progress={} next=defend_then_pearl", mc.player.getName().getString(), progress);
               return false;
            } else {
               KeyActionModule key = Night.MODULE_MANAGER.getModule(KeyActionModule.class);
               if (key != null) {
                  key.setBotXpActive(false);
               }

               if (surround.isToggled()) {
                  surround.setToggled(false);
               }

               this.enabledSurround = false;
               this.phaseCoverTarget = null;
               this.moveToward(step.getX() + 0.5 - mc.player.getX(), step.getZ() + 0.5 - mc.player.getZ());
               this.setState(SoloBotModule.State.DESCENDING);
               return true;
            }
         }
      } else {
         return false;
      }
   }

   private boolean handleRecovery(BlockPos feet, Player target, SurroundModule surround, PhaseModule phase, long now) {
      if (mc.player.onGround() && mc.level.getBlockState(feet.below()).getBlock() == Blocks.BEDROCK) {
         this.recoveryProgressPosition = null;
         this.recoveryGuardAt = 0L;
      }

      if (this.recoveryPearlInFlight) {
         boolean movedFromLaunch = this.recoveryLaunchPosition != null
            && Math.hypot(mc.player.getX() - this.recoveryLaunchPosition.x, mc.player.getZ() - this.recoveryLaunchPosition.z) >= 2.0;
         SoloBotDefensePolicy.FlightStatus flight = SoloBotDefensePolicy.flightStatus(
            movedFromLaunch, this.recoveryPositionPacketSeen, mc.player.onGround(), now - this.recoveryPearlThrownAt
         );
         if (flight == SoloBotDefensePolicy.FlightStatus.WAITING) {
            if (this.tryRecoveryDescent(feet, surround, now)) {
               return true;
            }

            this.releaseMovement();
            if (!this.maintainRecoveryDefense(feet, surround, phase, now, true)) {
               this.setState(SoloBotModule.State.PEARLING);
            }

            return true;
         }

         this.recoveryProgressPosition = null;
         this.recoveryGuardAt = 0L;
         boolean low = mc.level.getBlockState(feet.below()).getBlock() == Blocks.BEDROCK;
         Night.LOGGER.info("[SoloBot] Recovery pearl result={} intended={} observed={} low={}", new Object[]{flight, this.recoveryIntendedLanding, feet, low});
         this.recoveryPearlInFlight = false;
         this.recoveryPhaseAttempted = false;
         this.phaseCoverTarget = null;
         this.recoveryPositionPacketSeen = false;
         if (flight == SoloBotDefensePolicy.FlightStatus.LANDED || low) {
            this.recoveryDefenseY = Integer.MIN_VALUE;
         }

         if (low) {
            this.recoveryActive = false;
            this.landingNeedsDefense = true;
            this.defenseAnchor = feet;
            this.recoveryFailedLanding = null;
         } else {
            if (flight == SoloBotDefensePolicy.FlightStatus.LANDED) {
               this.recoverySeekBedrock = true;
               this.nextBedrockSearch = 0L;
               Night.LOGGER.info("[BotRecoveryStage] player={} stage=SEEK_BEDROCK observed={}", mc.player.getName().getString(), feet);
            }

            this.recoveryFailedLanding = this.recoveryIntendedLanding;
            this.nextRecoveryPearl = Math.max(this.nextRecoveryPearl, now + 250L);
         }

         this.recoveryIntendedLanding = null;
      }

      if (this.defenseAnchor != null && feet.getY() > this.defenseAnchor.getY() && mc.level.getBlockState(feet.below()).getBlock() != Blocks.BEDROCK) {
         this.recoveryActive = true;
         this.landingNeedsDefense = true;
         this.updateArmorXp();
         if (this.tryRecoveryDescent(feet, surround, now)) {
            return true;
         } else {
            this.releaseMovement();
            boolean centering = this.maintainRecoveryDefense(feet, surround, phase, now, false);
            AutoShopModule shop = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
            PearlChaseModule pearlChase = Night.MODULE_MANAGER.getModule(PearlChaseModule.class);
            if (mc.player.onGround()
               && now >= this.nextRecoveryPearl
               && SoloBotDefensePolicy.canDefendLayer(this.recoveryDefenseY, feet.getY(), true)
               && !mc.player.hasContainerOpen()
               && mc.gui.screen() == null
               && (shop == null || !shop.isRunning())
               && (pearlChase == null || !pearlChase.isChasingEnemyPearl())
               && this.throwRecoveryPearl(target)) {
               this.recoveryPearlInFlight = true;
               this.recoveryPearlThrownAt = now;
               this.recoveryLaunchPosition = mc.player.position();
               this.recoveryPositionPacketSeen = false;
               this.nextRecoveryPearl = now + 1000L;
               this.setState(SoloBotModule.State.PEARLING);
            } else if (!centering && !this.maintainRecoveryDefense(feet, surround, phase, now, true)) {
               this.setState(SoloBotModule.State.HOLDING);
            }

            return true;
         }
      } else if (!this.landingNeedsDefense) {
         return false;
      } else {
         this.recoveryActive = false;
         this.recoveryPhaseAttempted = false;
         this.releaseMovement();
         if (mc.player.onGround() && mc.level.getBlockState(feet.below()).getBlock() == Blocks.BEDROCK) {
            if (this.autoSurround.getValue() && !this.pressurePaused && !surround.isToggled()) {
               surround.setToggled(true);
               this.enabledSurround = true;
               this.nextSurroundAttempt = now + 250L;
            }

            if (this.phaseCoverTarget != null) {
               BlockPos cover = this.phaseCoverTarget;
               if (this.isCenteredInCover(cover)) {
                  this.phaseCoverTarget = null;
                  this.landingNeedsDefense = false;
                  Night.LOGGER.info("[SoloBot] Recovery protected at {}", feet);
                  return true;
               }

               if (SoloBotDefensePolicy.waitForCentering(
                  this.isSurroundBlock(mc.level.getBlockState(cover).getBlock()),
                  this.protectiveOverlap(cover),
                  mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL)),
                  now,
                  this.phaseCenterDeadline
               )) {
                  if (this.protectiveOverlap(cover) > 1.0E-4) {
                     this.centerToward(cover.getX() + 0.5 - mc.player.getX(), cover.getZ() + 0.5 - mc.player.getZ());
                  }

                  this.setState(SoloBotModule.State.CENTERING);
                  return true;
               }

               Night.LOGGER
                  .info(
                     "[BotRecoveryDefense] RETRY_READY oldTarget={} overlap={} cooldown={}",
                     new Object[]{cover, this.protectiveOverlap(cover), mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))}
                  );
               this.phaseCoverTarget = null;
            }

            if (surround.isToggled() && this.isSafelyCenteredInCover(feet)) {
               this.landingNeedsDefense = false;
               Night.LOGGER.info("[SoloBot] Recovery protected at {}", feet);
               return true;
            } else {
               Direction direction = this.findSurroundDirection(feet, 0.0, 0.0);
               AutoShopModule shop = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
               if (this.autoPhase.getValue()
                  && surround.isToggled()
                  && direction != null
                  && now >= Math.max(this.nextPhaseAttempt, this.nextEmergencyPhaseAttempt)
                  && !phase.isToggled()
                  && !mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))
                  && BotPearlAccess.find() >= 0
                  && !mc.player.hasContainerOpen()
                  && mc.gui.screen() == null
                  && (shop == null || !shop.isRunning())) {
                  if (!this.preparePhaseApproach(feet, direction, now)) {
                     return true;
                  }

                  this.nextPhaseAttempt = now + this.phaseDelay.getValue().longValue();
                  this.nextEmergencyPhaseAttempt = now + 500L;
                  phase.phaseTowards(direction.toYRot());
                  this.phaseCoverTarget = feet.relative(direction);
                  this.phaseCenterDeadline = now + 2200L;
                  this.setState(SoloBotModule.State.PHASING);
               } else {
                  if (now >= this.nextPhaseDiagnostic) {
                     Night.LOGGER
                        .info(
                           "[SoloBot] Recovery defense waiting at {} surround={} cover={} pearl={} cooldown={}",
                           new Object[]{
                              feet,
                              surround.isToggled(),
                              direction,
                              BotPearlAccess.find() >= 0,
                              mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))
                           }
                        );
                     this.nextPhaseDiagnostic = now + 5000L;
                  }

                  this.setState(SoloBotModule.State.DEFENDING);
               }

               return true;
            }
         } else {
            this.stableRecoveryTicks = 0;
            this.setState(SoloBotModule.State.DESCENDING);
            return true;
         }
      }
   }

   private boolean maintainRecoveryDefense(BlockPos feet, SurroundModule surround, PhaseModule phase, long now, boolean allowPhase) {
      boolean sameLayer = SoloBotDefensePolicy.canDefendLayer(this.recoveryDefenseY, feet.getY(), mc.player.onGround());
      if (now >= this.nextRecoveryDefenseDiagnostic) {
         Night.LOGGER
            .info(
               "[BotRecoveryDefense] feet={} savedY={} ground={} sameLayer={} flight={} flightMs={} surround={} phaseTarget={} allowPhase={}",
               new Object[]{
                  feet,
                  this.recoveryDefenseY,
                  mc.player.onGround(),
                  sameLayer,
                  this.recoveryPearlInFlight,
                  this.recoveryPearlInFlight ? now - this.recoveryPearlThrownAt : 0L,
                  surround.isToggled(),
                  this.phaseCoverTarget,
                  allowPhase
               }
            );
         this.nextRecoveryDefenseDiagnostic = now + 1000L;
      }

      if (!sameLayer) {
         return false;
      } else {
         if (this.recoveryCenterProgress.blocked()) {
            this.phaseCoverTarget = null;
            allowPhase = false;
         }

         if (this.autoSurround.getValue() && !this.pressurePaused && !surround.isToggled()) {
            surround.setToggled(true);
            this.enabledSurround = true;
         }

         if (this.phaseCoverTarget != null) {
            BlockPos cover = this.phaseCoverTarget;
            if (!SoloBotDefensePolicy.waitForCentering(
               this.isSurroundBlock(mc.level.getBlockState(cover).getBlock()),
               this.protectiveOverlap(cover),
               mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL)),
               now,
               this.phaseCenterDeadline
            )) {
               Night.LOGGER
                  .info(
                     "[BotRecoveryDefense] RETRY_READY oldTarget={} overlap={} cooldown={}",
                     new Object[]{cover, this.protectiveOverlap(cover), mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))}
                  );
               this.phaseCoverTarget = null;
            } else {
               if (!this.isCenteredInCover(cover)) {
                  if (this.protectiveOverlap(cover) > 1.0E-4) {
                     this.centerToward(cover.getX() + 0.5 - mc.player.getX(), cover.getZ() + 0.5 - mc.player.getZ());
                     this.setState(SoloBotModule.State.CENTERING);
                  } else {
                     this.releaseMovement();
                     this.setState(SoloBotModule.State.PHASING);
                  }

                  return true;
               }

               this.occupiedCover = cover;
               this.lostCover = null;
               this.phaseCoverTarget = null;
               Night.LOGGER.info("[BotRecoveryDefense] CENTERED cover={} escapeStillPending={}", cover, this.recoveryPearlInFlight);
            }
         }

         AutoShopModule shop = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
         PearlChaseModule chase = Night.MODULE_MANAGER.getModule(PearlChaseModule.class);
         Direction direction = this.findSurroundDirection(feet, 0.0, 0.0);
         if (allowPhase
            && this.autoPhase.getValue()
            && !this.isSafelyCenteredInCover(feet)
            && direction != null
            && !phase.isToggled()
            && now >= this.nextPhaseAttempt
            && !mc.player.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))
            && BotPearlAccess.find() >= 0
            && !mc.player.hasContainerOpen()
            && mc.gui.screen() == null
            && (shop == null || !shop.isRunning())
            && (chase == null || !chase.isChasingEnemyPearl())) {
            if (!this.preparePhaseApproach(feet, direction, now)) {
               return true;
            } else {
               this.nextPhaseAttempt = now + this.phaseDelay.getValue().longValue();
               phase.phaseTowards(direction.toYRot());
               this.phaseCoverTarget = feet.relative(direction);
               this.phaseCenterDeadline = now + 2200L;
               Night.LOGGER.info("[BotRecoveryDefense] PHASE requested={} escapeStillPending=true", this.phaseCoverTarget);
               this.setState(SoloBotModule.State.PHASING);
               return true;
            }
         } else {
            this.setState(SoloBotModule.State.DEFENDING);
            return false;
         }
      }
   }

   private void updateArmorXp() {
      KeyActionModule keyAction = Night.MODULE_MANAGER.getModule(KeyActionModule.class);
      if (keyAction != null) {
         if (this.autoArmorXp.getValue() && mc.player.isAlive()) {
            boolean belowStart = false;
            boolean allAtStop = true;
            double lowest = 100.0;

            for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
               ItemStack armor = mc.player.getItemBySlot(slot);
               if (!armor.isEmpty() && armor.getMaxDamage() > 0) {
                  double durability = 100.0 * (armor.getMaxDamage() - armor.getDamageValue()) / armor.getMaxDamage();
                  lowest = Math.min(lowest, durability);
                  if (durability <= this.armorXpStart.getValue().doubleValue()) {
                     belowStart = true;
                  }

                  if (durability < this.armorXpStop.getValue().doubleValue()) {
                     allAtStop = false;
                  }
               }
            }

            if (!this.armorRepairNeeded && belowStart) {
               this.armorRepairNeeded = true;
               Night.LOGGER.info("[SoloBot] Armor XP requested, lowest durability={} percent", Math.round(lowest));
            } else if (this.armorRepairNeeded && allAtStop) {
               this.armorRepairNeeded = false;
               Night.LOGGER.info("[SoloBot] Armor XP complete, lowest durability={} percent", Math.round(lowest));
            }

            AutoShopModule shop = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
            boolean silentXpAllowed = shop != null && shop.allowsSilentXp();
            boolean paused = !keyAction.isToggled()
               || !silentXpAllowed && (mc.player.hasContainerOpen() || mc.gui.screen() != null || shop != null && shop.isRunning());
            int maxSlot = !keyAction.xpSwitch.getValue().equalsIgnoreCase("AltSwap") && !keyAction.xpSwitch.getValue().equalsIgnoreCase("AltPickup") ? 8 : 35;
            boolean hasBottles = InventoryUtils.find(Items.EXPERIENCE_BOTTLE, 0, maxSlot) >= 0;
            ReplenishModule refill = Night.MODULE_MANAGER.getModule(ReplenishModule.class);
            if (GrimV3Inventory.refilling()
               || refill != null
                  && refill.hasReadyRefill()
                  && (shop == null || !shop.isRunning())
                  && (Night.MODULE_MANAGER.getModule(PhaseModule.class) == null || !Night.MODULE_MANAGER.getModule(PhaseModule.class).isToggled())
                  && !InventoryUtils.hasActiveSilentSwitch()) {
               paused = true;
            }

            boolean requested = this.armorRepairNeeded && !paused && hasBottles;
            boolean safeCover = mc.player.onGround() && this.isSafelyCenteredInCover(mc.player.blockPosition());
            long now = System.currentTimeMillis();
            boolean allowed = this.xpDefense.allow(requested, safeCover, lowest < 20.0, now, keyAction.getBotXpBurstCount());
            keyAction.setBotXpActive(allowed);
            String reason = this.xpDefense.reason();
            if ((requested || !reason.equals(this.lastXpCoordinationReason) || allowed != this.lastXpCoordinationAllowed)
               && (!reason.equals(this.lastXpCoordinationReason) || allowed != this.lastXpCoordinationAllowed || now >= this.nextXpCoordinationDiagnostic)) {
               Night.LOGGER
                  .info(
                     "[BotXPCoord] player={} reason={} requested={} allowed={} safeCover={} lowestPercent={} burstsRequested={} state={} feet={}",
                     new Object[]{
                        mc.player.getName().getString(),
                        reason,
                        requested,
                        allowed,
                        safeCover,
                        Math.round(lowest),
                        keyAction.getBotXpBurstCount(),
                        this.state,
                        mc.player.blockPosition()
                     }
                  );
               this.nextXpCoordinationDiagnostic = now + 1000L;
            }

            this.lastXpCoordinationReason = reason;
            this.lastXpCoordinationAllowed = allowed;
         } else {
            this.armorRepairNeeded = false;
            this.xpDefense.reset();
            keyAction.setBotXpActive(false);
         }
      }
   }

   public boolean canRunRoutineInventory() {
      if (mc.player != null && mc.level != null) {
         KeyActionModule key = Night.MODULE_MANAGER.getModule(KeyActionModule.class);
         if (this.armorRepairNeeded && key != null && key.isToggled()) {
            String mode = key.xpSwitch.getValue();
            int maxSlot = !mode.equalsIgnoreCase("AltSwap") && !mode.equalsIgnoreCase("AltPickup") ? 8 : 35;
            ReplenishModule refill = Night.MODULE_MANAGER.getModule(ReplenishModule.class);
            if (InventoryUtils.find(Items.EXPERIENCE_BOTTLE, 0, maxSlot) >= 0 && !GrimV3Inventory.refilling() && (refill == null || !refill.hasReadyRefill())) {
               return false;
            }
         }

         return mc.player != null && mc.level != null && mc.player.onGround() && this.isSafelyCenteredInCover(mc.player.blockPosition());
      } else {
         return false;
      }
   }

   private static enum MovementStep {
      WALK,
      JUMP,
      BLOCKED;
   }

   private record PursuitSolution(float yaw, float pitch, Vec3 landing) {
   }

   private static enum State {
      IDLE,
      WAITING,
      SEEKING_HOLE,
      HOLDING,
      APPROACHING,
      DESCENDING,
      ESCAPING,
      DEFENDING,
      PHASING,
      CENTERING,
      PEARLING,
      FIGHTING;
   }
}
