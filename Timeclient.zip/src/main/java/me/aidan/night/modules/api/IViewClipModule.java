package night.modules.api;

public interface IViewClipModule {
   boolean isToggled();

   boolean isExtend();

   float getDistanceValue();
}
