package night.modules.impl.movement;

import lombok.Generated;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.ClientRotationEvent;
import night.events.impl.PlayerMoveEvent;
import night.events.impl.PlayerUpdateEvent;
import night.mixins.accessors.ClientPlayerEntityAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.api.IFreecamModule;
import night.modules.api.ISprintModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.MovementUtils;

@RegisterModule(
   name = "Sprint",
   description = "Makes it so that you are always sprinting when possible.",
   category = Module.Category.MOVEMENT
)
public class SprintModule extends Module implements ISprintModule {
   public ModeSetting mode = new ModeSetting("Mode", "The limits to when you can be sprinting.", "Rage", new String[]{"Legit", "Rage", "Instant", "Grim"});
   public NumberSetting instantSpeed = new NumberSetting(
      "InstantSpeed",
      "Per-tick horizontal speed to move at (blocks/tick) when Mode is Instant.",
      new ModeSetting.Visibility(this.mode, "Instant"),
      (float)MovementUtils.DEFAULT_SPEED,
      0.05F,
      0.6F
   );
   public BooleanSetting instantWater = new BooleanSetting(
      "Water", "Keeps applying the Instant speed override while in water.", new ModeSetting.Visibility(this.mode, "Instant"), true
   );
   public BooleanSetting instantLava = new BooleanSetting(
      "Lava", "Keeps applying the Instant speed override while in lava.", new ModeSetting.Visibility(this.mode, "Instant"), false
   );
   public BooleanSetting pauseOnSetback = new BooleanSetting(
      "PauseOnSetback", "Briefly pauses sprinting when receiving a setback from the server to allow GrimAC buffer to decay.", true
   );
   private float cachedYaw;
   private Vec2 cachedMove;
   private boolean grimQueued;
   private Float pendingYaw;
   private float pendingPitch;
   private int grimStrafe;

   @Override
   public int getGrimStrafe() {
      return this.grimStrafe;
   }

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (mc.player != null) {
         this.cachedYaw = mc.player.getYRot();
         this.cachedMove = mc.player.input.getMoveVector();
         if (this.isGrim()) {
            this.grimUpdate();
         } else {
            this.pendingYaw = null;
         }

         boolean sprint = this.shouldSprint();
         if (sprint) {
            mc.player.setSprinting(true);
         } else if (mc.player.isSprinting()) {
            mc.player.setSprinting(false);
         }
      }
   }

   @SubscribeEvent
   public void onPlayerMove(PlayerMoveEvent event) {
      if (mc.player != null) {
         if (this.mode.getValue().equalsIgnoreCase("Instant")) {
            ElytraFlyModule elytra = Night.MODULE_MANAGER.getModule(ElytraFlyModule.class);
            if (!elytra.isToggled() || !elytra.mode.getValue().equalsIgnoreCase("Control") || !mc.player.isFallFlying()) {
               HoleSnapModule holeSnap = Night.MODULE_MANAGER.getModule(HoleSnapModule.class);
               if (!holeSnap.isToggled() || holeSnap.hole == null) {
                  boolean instantAllowed = mc.player.getFoodData().getFoodLevel() > 6
                     && (this.instantLava.getValue() || !mc.player.isInLava())
                     && (this.instantWater.getValue() || !mc.player.isInWater())
                     && (!this.pauseOnSetback.getValue() || Night.SERVER_MANAGER == null || Night.SERVER_MANAGER.getSetbackTimer().hasTimeElapsed(150L));
                  if (instantAllowed) {
                     Vec2 move = this.cachedMove;
                     if (move.x == 0.0F && move.y == 0.0F) {
                        event.setMovement(new Vec3(0.0, event.getMovement().y, 0.0));
                     } else {
                        double moveLength = Math.sqrt(move.x * move.x + move.y * move.y);
                        double normX = move.x / moveLength;
                        double normY = move.y / moveLength;
                        double yawRad = Math.toRadians(this.cachedYaw);
                        double sin = Math.sin(yawRad);
                        double cos = Math.cos(yawRad);
                        double vx = normX * cos - normY * sin;
                        double vz = normX * sin + normY * cos;
                        double speed = this.instantSpeed.getValue().doubleValue();
                        event.setMovement(new Vec3(vx * speed, event.getMovement().y, vz * speed));
                     }

                     event.setCancelled(true);
                  }
               }
            }
         }
      }
   }

   @SubscribeEvent
   public void onClientRotation(ClientRotationEvent event) {
      if (this.pendingYaw != null && !event.isCancelled()) {
         event.setYaw(this.pendingYaw);
         event.setPitch(this.pendingPitch);
         event.setOwner(this);
      }
   }

   private boolean isGrim() {
      return this.mode.getValue().equalsIgnoreCase("Grim");
   }

   private void grimUpdate() {
      this.grimQueued = false;
      this.pendingYaw = null;
      if (!mc.player.isFallFlying() && !mc.player.isPassenger()) {
         if (!this.pauseOnSetback.getValue() || Night.SERVER_MANAGER == null || Night.SERVER_MANAGER.getSetbackTimer().hasTimeElapsed(150L)) {
            if (!((IFreecamModule)Night.MODULE_MANAGER.getModule("Freecam")).isToggled()) {
               int inputX = (mc.options.keyRight.isDown() ? 1 : 0) - (mc.options.keyLeft.isDown() ? 1 : 0);
               int inputZ = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
               if (inputX != 0 || inputZ != 0) {
                  float moveAngle = (float)Math.toDegrees(Math.atan2(inputX, inputZ));
                  int strafe = 0;
                  float targetYaw;
                  if (inputX != 0 && inputZ != 0) {
                     strafe = inputX < 0 ? 1 : -1;
                     targetYaw = Mth.wrapDegrees(mc.player.getYRot() + moveAngle + (strafe > 0 ? 45.0F : -45.0F));
                  } else {
                     targetYaw = Mth.wrapDegrees(mc.player.getYRot() + moveAngle);
                  }

                  this.pendingYaw = targetYaw;
                  this.pendingPitch = mc.player.getXRot();
                  this.grimStrafe = strafe;
                  this.grimQueued = true;
               }
            }
         }
      }
   }

   @Override
   public boolean isGrimCompensating() {
      if (mc.player != null && this.isToggled() && this.isGrim() && this.grimQueued) {
         return this.pauseOnSetback.getValue() && Night.SERVER_MANAGER != null && !Night.SERVER_MANAGER.getSetbackTimer().hasTimeElapsed(150L)
            ? false
            : Night.ROTATION_MANAGER.getRotation() != null && Night.ROTATION_MANAGER.getRotationOwner() == this;
      } else {
         return false;
      }
   }

   @Override
   public float getGrimYaw() {
      return Night.ROTATION_MANAGER.getRotation().getYaw();
   }

   @Override
   public boolean isInstantMode() {
      return this.mode.getValue().equalsIgnoreCase("Instant");
   }

   @Override
   public void onEnable() {
      if (mc.player != null) {
         mc.player.setSprinting(this.shouldSprint());
      }
   }

   @Override
   public void onDisable() {
      this.grimQueued = false;
      if (mc.player != null) {
         mc.player.setSprinting(false);
      }
   }

   @Override
   public String getMetaData() {
      return this.mode.getValue();
   }

   @Override
   public boolean shouldSprint() {
      if (this.pauseOnSetback.getValue() && Night.SERVER_MANAGER != null && !Night.SERVER_MANAGER.getSetbackTimer().hasTimeElapsed(150L)) {
         return false;
      } else if (!((ClientPlayerEntityAccessor)mc.player).invokeCanSprint(true)) {
         return false;
      } else if (mc.player.isInWater() && !mc.player.isUnderWater()) {
         return false;
      } else if (mc.player.isSwimming() && !mc.player.onGround() && !mc.player.input.keyPresses.shift() && !mc.player.isInWater()) {
         return false;
      } else if (mc.player.isInLava()) {
         return false;
      } else if (mc.player.onClimbable()) {
         return false;
      } else {
         if (mc.player.isFallFlying()) {
            ElytraFlyModule ef = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(ElytraFlyModule.class) : null;
            if (ef == null || !ef.isToggled() || !ef.mode.getValue().equalsIgnoreCase("Bounce")) {
               return false;
            }
         }

         if (mc.player.getFoodData().getFoodLevel() <= 6) {
            return false;
         } else if (mc.player.isUsingItem()
            && (!Night.MODULE_MANAGER.getModule(NoSlowModule.class).isToggled() || !Night.MODULE_MANAGER.getModule(NoSlowModule.class).items.getValue())) {
            return false;
         } else if (!this.mode.getValue().equalsIgnoreCase("Rage") && !this.mode.getValue().equalsIgnoreCase("Instant") && !this.isGrim()) {
            if (!((ClientPlayerEntityAccessor)mc.player).invokeIsWalking()) {
               return false;
            } else {
               return mc.player.horizontalCollision && !mc.player.minorHorizontalCollision ? false : mc.player.input.hasForwardImpulse();
            }
         } else if (mc.player.horizontalCollision && !mc.player.minorHorizontalCollision) {
            return false;
         } else {
            return this.isGrim() && !this.isGrimCompensating()
               ? mc.player.input.keyPresses.forward()
               : mc.player.input.keyPresses.forward()
                  || mc.player.input.keyPresses.backward()
                  || mc.player.input.keyPresses.left()
                  || mc.player.input.keyPresses.right();
         }
      }
   }

   @Generated
   public Float getPendingYaw() {
      return this.pendingYaw;
   }
}
