package night.modules.api;

public interface IAutoWalkModule {
   boolean isToggled();

   boolean isBackward();
}
