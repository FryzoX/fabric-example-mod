package night.modules.impl.movement;

import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PlayerMoveEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.MovementUtils;
import org.joml.Vector2d;

@RegisterModule(
   name = "FastSwim",
   description = "Modifies your swim speed in water and lava.",
   category = Module.Category.MOVEMENT
)
public class FastSwimModule extends Module {
   private static final double DEFAULT_VERTICAL_SPEED = 0.04;
   public NumberSetting hWater = new NumberSetting("H-Water", "Horizontal swim speed multiplier in water.", 1.0F, 0.1F, 20.0F);
   public NumberSetting vWater = new NumberSetting("V-Water", "Vertical (up/down) swim speed multiplier in water.", 1.0F, 0.1F, 20.0F);
   public NumberSetting hLava = new NumberSetting("H-Lava", "Horizontal swim speed multiplier in lava.", 1.0F, 0.1F, 20.0F);
   public NumberSetting vLava = new NumberSetting("V-Lava", "Vertical (up/down) swim speed multiplier in lava.", 1.0F, 0.1F, 20.0F);

   @SubscribeEvent
   public void onPlayerMove(PlayerMoveEvent event) {
      if (mc.player != null) {
         if (!mc.player.onGround()) {
            ElytraFlyModule elytra = Night.MODULE_MANAGER.getModule(ElytraFlyModule.class);
            if (!elytra.isToggled() || !elytra.mode.getValue().equalsIgnoreCase("Control") || !mc.player.isFallFlying()) {
               float v;
               float h;
               if (mc.player.isInLava()) {
                  h = this.hLava.getValue().floatValue();
                  v = this.vLava.getValue().floatValue();
               } else {
                  if (!mc.player.isInWater()) {
                     return;
                  }

                  h = this.hWater.getValue().floatValue();
                  v = this.vWater.getValue().floatValue();
               }

               Vector2d horizontal = MovementUtils.forward(MovementUtils.DEFAULT_SPEED * h);
               double y = event.getMovement().y;
               if (mc.options.keyJump.isDown()) {
                  y = 0.04 * v;
               } else if (mc.options.keyShift.isDown()) {
                  y = -0.04 * v;
               }

               event.setMovement(new Vec3(horizontal.x, y, horizontal.y));
               event.setCancelled(true);
            }
         }
      }
   }
}
