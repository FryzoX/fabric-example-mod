package night.modules.impl.combat;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.VoxelShape;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PlayerUpdateEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.settings.impl.WhitelistSetting;
import night.utils.minecraft.InventoryUtils;
import night.utils.system.Timer;

@RegisterModule(
   name = "AutoPot",
   description = "Throws a splash potion under/above you to keep whitelisted potions' effects topped up.",
   category = Module.Category.COMBAT
)
public class AutoPotModule extends Module {
   public ModeSetting mode = new ModeSetting(
      "Mode",
      "WhiteList = keep these potions' effects topped up. BlackList = keep every potion's effects topped up except these.",
      "WhiteList",
      new String[]{"WhiteList", "BlackList"}
   );
   public WhitelistSetting whitelist = new WhitelistSetting(
      "Whitelist", "Potions this mode's WhiteList/BlackList compares against.", WhitelistSetting.Type.POTIONS
   );
   public NumberSetting amplifier = new NumberSetting("Amplifier", "Minimum amplifier level required before an effect counts as \"already have it\".", 1, 0, 4);
   public BooleanSetting rotate = new BooleanSetting(
      "Rotate", "Rotates to look straight up/down before throwing (nami: real rotation, waits for it to land before throwing).", false
   );
   public ModeSetting throwMode = new ModeSetting(
      "Throw", "Where the potion lands relative to you.", new BooleanSetting.Visibility(this.rotate, true), "Under", new String[]{"Above", "Under"}
   );
   public ModeSetting swapMode = new ModeSetting("Swap", "How the potion slot gets selected before throwing.", "Silent", new String[]{"Normal", "Silent"});
   public BooleanSetting whenNoTarget = new BooleanSetting("NoTarget", "Only throws while no enemy is nearby.", false);
   public BooleanSetting onlyPhased = new BooleanSetting("OnlyPhased", "Only throws while phased into a block.", false);
   public BooleanSetting selfToggle = new BooleanSetting("SelfToggle", "Turns the module off once every whitelisted effect is already topped up.", true);
   public NumberSetting range = new NumberSetting(
      "Range", "How close an enemy has to be for NoTarget to see them.", new BooleanSetting.Visibility(this.whenNoTarget, true), 32, 4, 64
   );
   private final Timer throwTimer = new Timer();
   private static final long THROW_DELAY_MS = 5000L;

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (mc.player != null && mc.level != null) {
         Potion missing = this.findMissingPotion();
         if (missing == null) {
            if (this.selfToggle.getValue()) {
               this.setToggled(false);
            }
         } else if (this.whenNoTarget.getValue() && this.hasNearbyEnemy()) {
            if (this.selfToggle.getValue()) {
               this.setToggled(false);
            }
         } else if (this.onlyPhased.getValue() && !this.isPhased()) {
            if (this.selfToggle.getValue()) {
               this.setToggled(false);
            }
         } else {
            int potInvSlot = this.findPot(missing);
            if (potInvSlot == -1) {
               if (this.selfToggle.getValue()) {
                  this.setToggled(false);
               }
            } else if (this.throwTimer.hasTimeElapsed(5000L)) {
               int potSlot = potInvSlot < 9 ? potInvSlot : -1;
               int previousSlot = mc.player.getInventory().getSelectedSlot();
               if (potSlot == -1) {
                  InventoryUtils.swap("Pickup", potInvSlot, InventoryUtils.HOTBAR_START);
                  potSlot = InventoryUtils.HOTBAR_START;
               }

               float pitch = this.throwMode.getValue().equalsIgnoreCase("Above") ? -90.0F : 90.0F;
               if (this.rotate.getValue()) {
                  float[] target = new float[]{mc.player.getYRot(), pitch};
                  Night.ROTATION_MANAGER.legacyRotate(target, this, Night.ROTATION_MANAGER.getLegacyModulePriority(this));
               }

               this.throwTimer.reset();
               InventoryUtils.switchSlot(this.swapMode.getValue(), potSlot, previousSlot);
               mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
               InventoryUtils.switchBack(this.swapMode.getValue(), potSlot, previousSlot);
            }
         }
      }
   }

   private Potion findMissingPotion() {
      int requiredAmp = this.amplifier.getValue().intValue();

      for (Potion potionType : this.whitelist.getWhitelistedPotions()) {
         boolean missingAny = false;

         for (MobEffectInstance want : potionType.getEffects()) {
            boolean have = false;

            for (MobEffectInstance active : mc.player.getActiveEffects()) {
               if (active.getEffect() == want.getEffect() && active.getAmplifier() >= requiredAmp) {
                  have = true;
                  break;
               }
            }

            if (!have) {
               missingAny = true;
               break;
            }
         }

         if (missingAny) {
            return potionType;
         }
      }

      return null;
   }

   private int findPot(Potion targetPotion) {
      for (int i = 0; i < 36; i++) {
         ItemStack stack = mc.player.getInventory().getItem(i);
         PotionContents contents;
         if (!stack.isEmpty()
            && stack.getItem() == Items.SPLASH_POTION
            && (contents = (PotionContents)stack.get(DataComponents.POTION_CONTENTS)) != null
            && !contents.potion().isEmpty()
            && ((Holder)contents.potion().get()).value() == targetPotion) {
            return i;
         }
      }

      return -1;
   }

   private boolean hasNearbyEnemy() {
      double rangeSq = Mth.square(this.range.getValue().doubleValue());

      for (Player player : mc.level.players()) {
         if (player != mc.player && !Night.FRIEND_MANAGER.contains(player.getName().getString()) && mc.player.distanceToSqr(player) <= rangeSq) {
            return true;
         }
      }

      return false;
   }

   private boolean isPhased() {
      AABB box = mc.player.getBoundingBox();
      int minX = Mth.floor(box.minX);
      int maxX = Mth.ceil(box.maxX);
      int minY = Mth.floor(box.minY);
      int maxY = Mth.ceil(box.maxY);
      int minZ = Mth.floor(box.minZ);
      int maxZ = Mth.ceil(box.maxZ);

      for (int x = minX; x < maxX; x++) {
         for (int y = minY; y < maxY; y++) {
            for (int z = minZ; z < maxZ; z++) {
               BlockPos pos = new BlockPos(x, y, z);
               VoxelShape shape = mc.level.getBlockState(pos).getCollisionShape(mc.level, pos);
               if (!shape.isEmpty() && shape.bounds().move(pos).intersects(box)) {
                  return true;
               }
            }
         }
      }

      return false;
   }
}
