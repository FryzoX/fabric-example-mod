package night.modules.impl.player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.impl.combat.MainhandModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.GrimV3Inventory;
import night.utils.minecraft.GrimV3Policy;
import night.utils.minecraft.TotemRefillPolicy;
import night.utils.minecraft.TotemSlotOwnership;

@RegisterModule(
   name = "InventorySorter",
   description = "Auto-sorts your inventory into the active Rekit kit's layout.",
   category = Module.Category.PLAYER
)
public class InventorySorterModule extends Module {
   public NumberSetting delay;
   public NumberSetting actionsPerTick;
   public BooleanSetting ignoreHotbar;
   private final List<GrimV3Inventory.Click> planned;
   private boolean planning;
   private int ticks;
   private boolean settled;
   public static volatile long lastContainerActionMs = 0L;
   private int cursorWaitTicks;
   private static final int CURSOR_DUMP_AFTER_TICKS = 20;
   public NumberSetting sortDelayMs = new NumberSetting(
      "SortDelayMs", "Additional module delay, 0-2000 milliseconds. Existing inventory synchronization still applies.", 200, 0, 2000
   );

   public static boolean transactionBusy() {
      return GrimV3Inventory.busy();
   }

   public boolean isSettled() {
      return this.settled;
   }

   public void invalidateSort() {
      this.settled = false;
   }

   @Override
   public void onEnable() {
      this.settled = false;
   }

   private void legacyTick(TickEvent event) {
      if (mc.player == null) {
         this.settled = false;
      } else {
         AutoShopModule shop = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
         if ((shop == null || !shop.isRunning()) && mc.player.containerMenu == mc.player.inventoryMenu) {
            RekitModule rekit = Night.MODULE_MANAGER.getModule(RekitModule.class);
            if (rekit.getActiveKit().isEmpty()) {
               this.settled = true;
            } else if (!mc.player.isCreative()) {
               if (!(mc.gui.screen() instanceof AbstractContainerScreen) || mc.gui.screen() instanceof InventoryScreen) {
                  if (this.ticks < this.delay.getValue().intValue()) {
                     this.ticks++;
                  } else {
                     this.ticks = 0;
                     this.settled = false;
                     int executed = 0;

                     while (executed < this.actionsPerTick.getValue().intValue() && this.sortTick(rekit)) {
                        executed++;
                     }
                  }
               }
            }
         } else {
            this.settled = false;
         }
      }
   }

   public boolean hasHotbarLayoutWork() {
      if (this.isToggled() && mc.player != null && !this.ignoreHotbar.getValue()) {
         RekitModule rekit = Night.MODULE_MANAGER.getModule(RekitModule.class);
         return rekit != null && !rekit.getActiveKit().isEmpty() && this.repairHotbar(mc.player.inventoryMenu, rekit, false);
      } else {
         return false;
      }
   }

   private void atomicSwap(int slot1, int slot2) {
      this.click(slot1, 0, ContainerInput.PICKUP);
      this.click(slot2, 0, ContainerInput.PICKUP);
      this.click(slot1, 0, ContainerInput.PICKUP);
   }

   private boolean refillOwnsKitSlot(int slot, RekitModule.KitItem wanted) {
      ReplenishModule refill = Night.MODULE_MANAGER.getModule(ReplenishModule.class);
      if (slot >= 0 && slot < 9 && refill != null && refill.managesHotbarSlot(slot) && wanted != null && wanted.id != null) {
         Identifier id = Identifier.tryParse(wanted.id);
         if (id == null) {
            return false;
         } else {
            int max = ((Item)BuiltInRegistries.ITEM.getValue(id)).getDefaultInstance().getMaxStackSize();
            return max > 1 && (refill.keepInventoryStack.getValue() || wanted.desiredCount() >= max);
         }
      } else {
         return false;
      }
   }

   private void click(int slotId, int button, ContainerInput type) {
      if (this.planning) {
         this.planned.add(new GrimV3Inventory.Click(slotId, button, type));
      } else {
         lastContainerActionMs = System.currentTimeMillis();
         mc.gameMode.handleContainerInput(mc.player.containerMenu.containerId, slotId, button, type, mc.player);
      }
   }

   private boolean isCorrectItem(ItemStack stack, RekitModule.KitItem kit) {
      if (kit == null) {
         return true;
      } else if (stack.isEmpty()) {
         return false;
      } else if (kit.id != null && !kit.id.isEmpty()) {
         Identifier identifier = Identifier.tryParse(kit.id);
         if (identifier == null) {
            return false;
         } else {
            Item expected = (Item)BuiltInRegistries.ITEM.getValue(identifier);
            return expected != null && stack.getItem() == expected;
         }
      } else {
         return false;
      }
   }

   private int findEmptySlot(AbstractContainerMenu handler) {
      RekitModule rekit = Night.MODULE_MANAGER.getModule(RekitModule.class);

      for (int i = 0; i < 36; i++) {
         int slotId;
         if ((!this.ignoreHotbar.getValue() || i > 8)
            && handler.getSlot(slotId = this.getHandlerSlot(i)).getItem().isEmpty()
            && rekit.getActiveKit().get(i) == null) {
            return slotId;
         }
      }

      for (int var6 = 0; var6 < 36; var6++) {
         int slotId;
         if ((!this.ignoreHotbar.getValue() || var6 > 8) && handler.getSlot(slotId = this.getHandlerSlot(var6)).getItem().isEmpty()) {
            return slotId;
         }
      }

      return -1;
   }

   private int getHandlerSlot(int invSlot) {
      if (invSlot >= 0 && invSlot <= 8) {
         return 36 + invSlot;
      } else {
         return invSlot >= 9 && invSlot <= 35 ? invSlot : -1;
      }
   }

   private boolean isShulkerBox(ItemStack stack) {
      BlockItem blockItem;
      Item item;
      return !stack.isEmpty() && (item = stack.getItem()) instanceof BlockItem && (blockItem = (BlockItem)item).getBlock() instanceof ShulkerBoxBlock;
   }

   private boolean deferTotemKitSlot(ItemStack current, RekitModule.KitItem wanted) {
      MainhandModule mainhand = Night.MODULE_MANAGER.getModule(MainhandModule.class);
      int supply = 0;

      for (int i = 0; i < 9; i++) {
         if (mc.player.getInventory().getItem(i).is(Items.TOTEM_OF_UNDYING)) {
            supply++;
         }
      }

      return TotemRefillPolicy.defer(
         mainhand != null && mainhand.isToggled(), current.isEmpty(), wanted != null && "minecraft:totem_of_undying".equals(wanted.id), supply
      );
   }

   private boolean fillKitCounts(AbstractContainerMenu handler, RekitModule rekit) {
      for (int target = 0; target < 36; target++) {
         if (target < 9) {
            ReplenishModule refill = Night.MODULE_MANAGER.getModule(ReplenishModule.class);
            int missing;
            ItemStack current;
            RekitModule.KitItem desired;
            if (!this.refillOwnsKitSlot(target, rekit.getActiveKit().get(target))
               && (!this.ignoreHotbar.getValue() || target > 8)
               && (desired = rekit.getActiveKit().get(target)) != null
               && desired.id != null
               && ((current = handler.getSlot(this.getHandlerSlot(target)).getItem()).isEmpty() || this.isCorrectItem(current, desired))
               && (missing = desired.desiredCount() - current.getCount()) > 0
               && !this.deferTotemKitSlot(current, desired)
               && !TotemSlotOwnership.protectedSlot(target, current)) {
               for (int source = 35; source >= 0; source--) {
                  ItemStack donor;
                  if (source != target
                     && (!this.ignoreHotbar.getValue() || source > 8)
                     && !(donor = handler.getSlot(this.getHandlerSlot(source)).getItem()).isEmpty()
                     && !this.isShulkerBox(donor)
                     && BuiltInRegistries.ITEM.getKey(donor.getItem()).toString().equals(desired.id)
                     && (current.isEmpty() || ItemStack.isSameItemSameComponents(current, donor))
                     && !TotemSlotOwnership.protectedSlot(source, donor)) {
                     RekitModule.KitItem sourceKit = rekit.getActiveKit().get(source);
                     int reserve = sourceKit != null && desired.id.equals(sourceKit.id) ? sourceKit.desiredCount() : 0;
                     int transfer = Math.min(missing, Math.max(0, donor.getCount() - reserve));
                     if (transfer > 0) {
                        if (this.planning) {
                           int strategy = GrimV3Policy.transferStrategy(
                              donor.getCount(), current.getCount(), desired.desiredCount(), donor.getMaxStackSize(), reserve
                           );
                           if (strategy == 1) {
                              this.click(this.getHandlerSlot(source), 0, ContainerInput.PICKUP);
                              this.click(this.getHandlerSlot(target), 0, ContainerInput.PICKUP);
                              if (transfer != donor.getCount()) {
                                 this.click(this.getHandlerSlot(source), 0, ContainerInput.PICKUP);
                              }

                              return true;
                           }

                           if (strategy == 2) {
                              this.click(this.getHandlerSlot(source), 1, ContainerInput.PICKUP);
                              this.click(this.getHandlerSlot(target), 0, ContainerInput.PICKUP);
                              return true;
                           }

                           transfer = Math.min(transfer, 1);
                        }

                        boolean wholeDonor = transfer == donor.getCount();
                        this.click(this.getHandlerSlot(source), 0, ContainerInput.PICKUP);
                        if (wholeDonor) {
                           this.click(this.getHandlerSlot(target), 0, ContainerInput.PICKUP);
                        } else {
                           for (int n = 0; n < transfer; n++) {
                              this.click(this.getHandlerSlot(target), 1, ContainerInput.PICKUP);
                           }

                           this.click(this.getHandlerSlot(source), 0, ContainerInput.PICKUP);
                        }

                        return true;
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   public InventorySorterModule() {
      this.delay = new NumberSetting("Delay", "Tick delay.", 1, 0, 10);
      this.actionsPerTick = new NumberSetting("ActionsPerTick", "Max actions per tick.", 1, 1, 5);
      this.ignoreHotbar = new BooleanSetting("IgnoreHotbar", "Skip hotbar slots (0-8) when sorting.", false);
      this.planned = new ArrayList<>();
      this.ticks = 0;
      this.cursorWaitTicks = 0;
      this.actionsPerTick.getVisibility().setVisible(false);
   }

   @SubscribeEvent
   public void onTick(TickEvent var1) {
      long var2 = this.sortDelayMs.getValue().longValue();
      if (System.currentTimeMillis() - lastContainerActionMs < var2) {
         this.settled = false;
      } else if (!GrimV3Inventory.enabled()) {
         if (!GrimV3Inventory.routineBlocked()) {
            this.legacyTick(var1);
         }
      } else if (!GrimV3Inventory.canPlan()) {
         this.settled = false;
      } else {
         ReplenishModule var4 = Night.MODULE_MANAGER.getModule(ReplenishModule.class);
         if (var4 != null && var4.hasReadyRefill()) {
            this.settled = false;
         } else {
            RekitModule var5 = Night.MODULE_MANAGER.getModule(RekitModule.class);
            if (var5 != null && !var5.getActiveKit().isEmpty()) {
               if (this.ticks++ >= this.delay.getValue().intValue()) {
                  this.ticks = 0;
                  this.settled = false;
                  this.planned.clear();
                  this.planning = true;

                  try {
                     this.sortTick(var5);
                  } finally {
                     this.planning = false;
                  }

                  if (!this.planned.isEmpty()) {
                     GrimV3Inventory.submit(this, this.planned);
                  }
               }
            } else {
               this.settled = true;
            }
         }
      }
   }

   private boolean sortTick(RekitModule var1) {
      AbstractContainerMenu var2 = mc.player.containerMenu;
      if (!var2.getCarried().isEmpty()) {
         this.cursorWaitTicks++;
         if (this.cursorWaitTicks >= 20) {
            this.cursorWaitTicks = 0;
            int var13 = this.findEmptySlot(var2);
            if (var13 != -1) {
               this.click(var13, 0, ContainerInput.PICKUP);
            }
         }

         return false;
      } else {
         this.cursorWaitTicks = 0;
         if (this.planning && this.repairHotbar(var2, var1, true)) {
            return true;
         } else {
            AutoShopModule var3 = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
            HashMap var4 = new HashMap();

            for (int var5 = 0; var5 < 36; var5++) {
               int var7;
               ItemStack var8;
               if ((!this.ignoreHotbar.getValue() || var5 > 8)
                  && !(var8 = var2.getSlot(var7 = this.getHandlerSlot(var5)).getItem()).isEmpty()
                  && !this.isShulkerBox(var8)
                  && var8.getCount() < var8.getItem().getDefaultMaxStackSize()
                  && !this.isCorrectItem(var8, var1.getActiveKit().get(var5))) {
                  String var9 = BuiltInRegistries.ITEM.getKey(var8.getItem()).toString();
                  var4.computeIfAbsent(var9, var0 -> new ArrayList<>()).add(var7);
               }
            }

            for (List var6 : var4.values()) {
               if (var6.size() > 1) {
                  for (int var17 = 0; var17 < var6.size(); var17++) {
                     int var19 = (Integer)var6.get(var17);
                     ItemStack var21 = var2.getSlot(var19).getItem();

                     for (int var10 = var17 + 1; var10 < var6.size(); var10++) {
                        int var11 = (Integer)var6.get(var10);
                        ItemStack var12 = var2.getSlot(var11).getItem();
                        if (ItemStack.isSameItemSameComponents(var21, var12)) {
                           this.atomicSwap(var11, var19);
                           return true;
                        }
                     }
                  }
               }
            }

            for (int var15 = 0; var15 < 36; var15++) {
               int var16;
               RekitModule.KitItem var18;
               int var20;
               ItemStack var22;
               if ((!this.ignoreHotbar.getValue() || var15 > 8)
                  && !this.isShulkerBox(var22 = var2.getSlot(var20 = this.getHandlerSlot(var15)).getItem())
                  && !this.isCorrectItem(var22, var18 = var1.getActiveKit().get(var15))
                  && !TotemSlotOwnership.protectedSlot(var15, var22)
                  && (var16 = this.findItemForKit(var2, var1, var18)) != -1
                  && (var15 > 8 || !this.deferTotemKitSlot(var22, var18))
                  && (var15 > 8 || !var22.isEmpty() || !this.refillOwnsKitSlot(var15, var18))) {
                  int var23 = this.getHandlerSlot(var16);
                  if (var15 <= 8 && var16 >= 9) {
                     this.click(var23, var15, ContainerInput.SWAP);
                     return true;
                  }

                  if (var16 <= 8 && var15 >= 9) {
                     this.click(var20, var16, ContainerInput.SWAP);
                     return true;
                  }

                  this.atomicSwap(var23, var20);
                  return true;
               }
            }

            this.settled = true;
            return false;
         }
      }
   }

   private boolean repairHotbar(AbstractContainerMenu var1, RekitModule var2, boolean var3) {
      if (this.ignoreHotbar.getValue()) {
         return false;
      } else {
         for (int var4 = 0; var4 < 9; var4++) {
            RekitModule.KitItem var5 = var2.getActiveKit().get(var4);
            ItemStack var6 = var1.getSlot(this.getHandlerSlot(var4)).getItem();
            if (var5 != null
               && var5.id != null
               && var5.desiredCount() > 0
               && !this.isShulkerBox(var6)
               && !this.isCorrectItem(var6, var5)
               && !TotemSlotOwnership.protectedSlot(var4, var6)) {
               ReplenishModule var7 = Night.MODULE_MANAGER.getModule(ReplenishModule.class);
               if (!this.deferTotemKitSlot(var6, var5) && (!var6.isEmpty() || !this.refillOwnsKitSlot(var4, var5))) {
                  int var8 = this.findItemForKit(var1, var2, var5);
                  if (var8 >= 0) {
                     if (var3) {
                        if (var8 >= 9) {
                           this.click(this.getHandlerSlot(var8), var4, ContainerInput.SWAP);
                        } else {
                           this.atomicSwap(this.getHandlerSlot(var8), this.getHandlerSlot(var4));
                        }
                     }

                     return true;
                  }

                  if (!var6.isEmpty() && this.returnWrongHotbar(var1, var2, var4, var6, var3)) {
                     return true;
                  }
               }
            }
         }

         return false;
      }
   }

   private boolean returnWrongHotbar(AbstractContainerMenu var1, RekitModule var2, int var3, ItemStack var4, boolean var5) {
      for (int var6 = 0; var6 < 2; var6++) {
         for (int var7 = 0; var7 < 36; var7++) {
            if (var7 != var3 && (!this.ignoreHotbar.getValue() || var7 >= 9)) {
               RekitModule.KitItem var8 = var2.getActiveKit().get(var7);
               if ((var6 == 0 ? var8 != null && this.isCorrectItem(var4, var8) : var8 == null) && (!var4.is(Items.TOTEM_OF_UNDYING) || var8 != null)) {
                  ItemStack var9 = var1.getSlot(this.getHandlerSlot(var7)).getItem();
                  if (var9.isEmpty() && !TotemSlotOwnership.protectedSlot(var7, var9)) {
                     if (var5) {
                        this.click(this.getHandlerSlot(var3), 0, ContainerInput.PICKUP);
                        this.click(this.getHandlerSlot(var7), 0, ContainerInput.PICKUP);
                     }

                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   private int findItemForKit(AbstractContainerMenu var1, RekitModule var2, RekitModule.KitItem var3) {
      if (var3 != null && var3.id != null && !var3.id.isEmpty()) {
         Identifier var4 = Identifier.tryParse(var3.id);
         if (var4 == null) {
            return -1;
         } else {
            Item var5 = (Item)BuiltInRegistries.ITEM.getValue(var4);
            if (var5 == null) {
               return -1;
            } else {
               for (int var6 = 0; var6 < 36; var6++) {
                  RekitModule.KitItem var10 = var2.getActiveKit().get(var6);
                  AutoShopModule var11 = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
                  boolean var9 = var10 == null;
                  ItemStack var8;
                  if ((!this.ignoreHotbar.getValue() || var6 > 8)
                     && !(var8 = var1.getSlot(this.getHandlerSlot(var6)).getItem()).isEmpty()
                     && !this.isShulkerBox(var8)
                     && var8.getItem() == var5
                     && (var9 || !this.isCorrectItem(var8, var10))
                     && !TotemSlotOwnership.protectedSlot(var6, var8)) {
                     return var6;
                  }
               }

               return -1;
            }
         }
      } else {
         return -1;
      }
   }
}
