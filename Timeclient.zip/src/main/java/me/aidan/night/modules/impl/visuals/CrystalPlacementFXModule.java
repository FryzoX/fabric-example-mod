package night.modules.impl.visuals;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.ClientDisconnectEvent;
import night.events.impl.EntitySpawnEvent;
import night.events.impl.PacketSendEvent;
import night.events.impl.RenderWorldEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.graphics.CrystalPlacementMath;
import night.utils.graphics.Renderer3D;
import org.joml.Matrix4f;

@RegisterModule(
   name = "CrystalPlacementFX",
   description = "Smooth rings and ground glow for your own crystal placements.",
   category = Module.Category.VISUALS
)
public class CrystalPlacementFXModule extends Module {
   public ModeSetting style = new ModeSetting(
      "Style", "Placement effect preset.", "Pulse", new String[]{"Pulse", "Double", "Segmented", "Hexagon", "Rune", "GroundGlow", "Petal", "Orbit"}
   );
   public ColorSetting color = new ColorSetting("Color", "Primary effect color.", new ColorSetting.Color(new Color(30, 240, 205, 210), false, false));
   public ColorSetting secondaryColor = new ColorSetting(
      "SecondaryColor", "Secondary effect color.", new ColorSetting.Color(new Color(115, 140, 255, 180), false, false)
   );
   public BooleanSetting dualColor = new BooleanSetting("DualColor", "Blend both colors around the effect.", true);
   public NumberSetting duration = new NumberSetting("Duration", "Effect lifetime in milliseconds.", 300, 100, 1500);
   public NumberSetting radius = new NumberSetting("Radius", "Starting ring radius in blocks.", 0.55F, 0.15F, 2.0F);
   public NumberSetting expansion = new NumberSetting("Expansion", "Additional radial expansion in blocks.", 0.25F, 0.0F, 2.0F);
   public NumberSetting thickness = new NumberSetting("Thickness", "Ring band width in blocks.", 0.035F, 0.01F, 0.2F);
   public NumberSetting rotationSpeed = new NumberSetting("RotationSpeed", "Effect rotation in degrees per second.", 90.0F, -360.0F, 360.0F);
   public NumberSetting heightOffset = new NumberSetting("HeightOffset", "Height above the crystal base to avoid surface flicker.", 0.025F, 0.005F, 0.5F);
   public BooleanSetting glow = new BooleanSetting("Glow", "Add soft additive glow; no post-processing shader.", true);
   public NumberSetting glowStrength = new NumberSetting("GlowStrength", "Soft glow intensity.", 0.5F, 0.0F, 1.0F);
   public NumberSetting quality = new NumberSetting("Quality", "Segments per circular ring.", 48, 24, 96);
   public NumberSetting range = new NumberSetting("Range", "Maximum distance for placement effects.", 32, 4, 96);
   public NumberSetting maxEffects = new NumberSetting("MaxEffects", "Maximum simultaneous effects; oldest expire first.", 16, 1, 48);
   public BooleanSetting risingRing = new BooleanSetting("RisingRing", "An extra luminous ring rises from your crystal placement.", true);
   public NumberSetting riseHeight = new NumberSetting("RiseHeight", "Maximum rising ring height in blocks.", 1.2F, 0.1F, 3.0F);
   public NumberSetting riseSpeed = new NumberSetting("RiseSpeed", "Rising animation speed multiplier.", 1.0F, 0.25F, 3.0F);
   private final ArrayDeque<CrystalPlacementFXModule.Pending> placements = new ArrayDeque<>();
   private final Map<UUID, CrystalPlacementFXModule.Burst> bursts = new LinkedHashMap<>();
   private ClientLevel effectLevel;

   @Override
   public void onEnable() {
      this.clear();
      this.effectLevel = mc.level;
   }

   @Override
   public void onDisable() {
      this.clear();
   }

   private void clear() {
      this.bursts.clear();
      this.placements.clear();
      this.effectLevel = null;
   }

   @SubscribeEvent
   public void onDisconnect(ClientDisconnectEvent event) {
      mc.execute(this::clear);
   }

   @SubscribeEvent
   public void onPlaced(PacketSendEvent.Post event) {
      if (this.isToggled() && mc.player != null && mc.level != null && event.getPacket() instanceof ServerboundUseItemOnPacket packet) {
         boolean crystal = packet.getHand() == InteractionHand.OFF_HAND
            ? mc.player.getOffhandItem().is(Items.END_CRYSTAL)
            : mc.player.getInventory().getItem(Night.POSITION_MANAGER.getServerSlot()).is(Items.END_CRYSTAL);
         if (crystal) {
            Vec3 expected = Vec3.atBottomCenterOf(packet.getHitResult().getBlockPos().above());
            ClientLevel level = mc.level;
            long now = System.nanoTime();
            mc.execute(() -> {
               if (this.isToggled() && mc.level == level) {
                  if (this.effectLevel != level) {
                     this.clear();
                     this.effectLevel = level;
                  }

                  this.placements.removeIf(p -> now - p.start > 2000000000L);

                  while (this.placements.size() >= 128) {
                     this.placements.removeFirst();
                  }

                  this.placements.addLast(new CrystalPlacementFXModule.Pending(expected, now));
               }
            });
         }
      }
   }

   @SubscribeEvent
   public void onSpawn(EntitySpawnEvent event) {
      if (this.isToggled() && event.getEntity() instanceof EndCrystal crystal && mc.player != null && mc.level != null) {
         Vec3 center = crystal.position();
         UUID id = crystal.getUUID();
         ClientLevel level = mc.level;
         long now = System.nanoTime();
         mc.execute(() -> {
            if (this.isToggled() && mc.level == level && mc.player != null) {
               if (this.effectLevel != level) {
                  this.clear();
                  this.effectLevel = level;
               }

               this.placements.removeIf(p -> now - p.start > 2000000000L);
               CrystalPlacementFXModule.Pending matched = null;

               for (CrystalPlacementFXModule.Pending pending : this.placements) {
                  if (pending.center.distanceToSqr(center) < 0.04) {
                     matched = pending;
                     break;
                  }
               }

               if (matched != null) {
                  this.placements.remove(matched);
                  double reach = this.range.getValue().doubleValue();
                  if (!(mc.player.position().distanceToSqr(center) > reach * reach) && !this.bursts.containsKey(id)) {
                     while (this.bursts.size() >= this.maxEffects.getValue().intValue()) {
                        this.bursts.remove(this.bursts.keySet().iterator().next());
                     }

                     this.bursts.put(id, new CrystalPlacementFXModule.Burst(center, now));
                  }
               }
            }
         });
      }
   }

   @SubscribeEvent
   public void onRender(RenderWorldEvent event) {
      if (this.isToggled()) {
         if (mc.level != null && mc.player != null && this.effectLevel == mc.level) {
            long now = System.nanoTime();
            int lifetime = this.duration.getValue().intValue();
            this.bursts.values().removeIf(b -> CrystalPlacementMath.progress(now - b.start, lifetime) >= 1.0);

            while (this.bursts.size() > this.maxEffects.getValue().intValue()) {
               this.bursts.remove(this.bursts.keySet().iterator().next());
            }

            if (Renderer3D.RENDERING) {
               double reach = this.range.getValue().doubleValue();

               for (CrystalPlacementFXModule.Burst burst : this.bursts.values()) {
                  if (!(mc.player.position().distanceToSqr(burst.center) > reach * reach)) {
                     double extent = this.radius.getValue().doubleValue() + this.expansion.getValue().doubleValue() + 0.8;
                     if (Renderer3D.isFrustumVisible(
                        new AABB(
                           burst.center.x - extent,
                           burst.center.y,
                           burst.center.z - extent,
                           burst.center.x + extent,
                           burst.center.y + this.riseHeight.getValue().doubleValue() + 1.0,
                           burst.center.z + extent
                        )
                     )) {
                        double p = CrystalPlacementMath.progress(now - burst.start, lifetime);
                        double alpha = CrystalPlacementMath.opacity(p);
                        if (!(alpha < 0.001)) {
                           double r = CrystalPlacementMath.radius(this.radius.getValue().doubleValue(), this.expansion.getValue().doubleValue(), p);
                           double angle = (now - burst.start) / 1.0E9 * Math.toRadians(this.rotationSpeed.getValue().doubleValue());
                           Matrix4f matrix = event.getMatrices().last().pose();
                           Vec3 origin = burst.center
                              .add(0.0, this.heightOffset.getValue().doubleValue(), 0.0)
                              .subtract(mc.gameRenderer.mainCamera().position());
                           if (this.risingRing.getValue()) {
                              double rise = CrystalPlacementMath.ease(Math.min(1.0, p * this.riseSpeed.getValue().doubleValue()));
                              this.ring(matrix, origin.add(0.0, this.riseHeight.getValue().doubleValue() * rise, 0.0), r * 0.9, angle, alpha, "Pulse");
                           }

                           String preset = this.style.getValue();
                           if (preset.equals("GroundGlow")) {
                              this.disk(matrix, origin, r, alpha);
                           } else {
                              this.ring(matrix, origin, r, angle, alpha, preset);
                              if (preset.equals("Double")) {
                                 double delayed = Math.max(0.0, (p - 0.12) / 0.88);
                                 if (p > 0.12) {
                                    this.ring(matrix, origin, r * 0.72, -angle, CrystalPlacementMath.opacity(delayed), "Pulse");
                                 }
                              } else if (preset.equals("Rune")) {
                                 this.ring(matrix, origin, r * 0.72, -angle, alpha * 0.7, "Segmented");

                                 for (int i = 0; i < 12; i++) {
                                    double a = angle + i * Math.PI / 6.0;
                                    this.stroke(matrix, origin, r * 1.08, r * 1.2, a, a + 0.035, alpha);
                                 }
                              } else if (preset.equals("Orbit")) {
                                 for (int i = 0; i < 3; i++) {
                                    this.arc(matrix, origin, r * 1.2, angle * 1.8 + i * Math.PI * 2.0 / 3.0, 0.42, alpha);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         } else {
            this.clear();
         }
      }
   }

   private Color tint(double angle, double alpha) {
      Color a = this.color.getColor();
      Color b = this.dualColor.getValue() ? this.secondaryColor.getColor() : a;
      double mix = (Math.sin(angle) + 1.0) / 2.0;
      int opacity = (int)Math.max(0.0, Math.min(255.0, (a.getAlpha() * (1.0 - mix) + b.getAlpha() * mix) * alpha));
      return new Color(
         (int)(a.getRed() * (1.0 - mix) + b.getRed() * mix),
         (int)(a.getGreen() * (1.0 - mix) + b.getGreen() * mix),
         (int)(a.getBlue() * (1.0 - mix) + b.getBlue() * mix),
         opacity
      );
   }

   private void ring(Matrix4f m, Vec3 c, double r, double phase, double alpha, String preset) {
      int count = preset.equals("Hexagon") ? 6 : this.quality.getValue().intValue();
      double width = this.thickness.getValue().doubleValue();

      for (int i = 0; i < count; i++) {
         if (!preset.equals("Segmented") || i % 6 < 4) {
            double a = phase + i * Math.PI * 2.0 / count;
            double b = phase + (i + 1) * Math.PI * 2.0 / count;
            double ra = r * (preset.equals("Petal") ? CrystalPlacementMath.petal(a - phase) : 1.0);
            double rb = r * (preset.equals("Petal") ? CrystalPlacementMath.petal(b - phase) : 1.0);
            this.band(m, c, ra - width / 2.0, rb - width / 2.0, ra + width / 2.0, rb + width / 2.0, a, b, alpha, alpha, false);
            if (this.glow.getValue()) {
               double strength = alpha * this.glowStrength.getValue().doubleValue() * 0.45;
               this.band(m, c, ra - width * 3.0, rb - width * 3.0, ra - width / 2.0, rb - width / 2.0, a, b, 0.0, strength, true);
               this.band(m, c, ra + width / 2.0, rb + width / 2.0, ra + width * 3.0, rb + width * 3.0, a, b, strength, 0.0, true);
            }
         }
      }
   }

   private void arc(Matrix4f m, Vec3 c, double r, double angle, double span, double alpha) {
      for (int i = 0; i < 8; i++) {
         this.stroke(m, c, r - 0.025, r + 0.025, angle + span * i / 8.0, angle + span * (i + 1) / 8.0, alpha * (0.35 + 0.65 * i / 8.0));
      }
   }

   private void stroke(Matrix4f m, Vec3 c, double inner, double outer, double a, double b, double alpha) {
      this.band(m, c, inner, inner, outer, outer, a, b, alpha, alpha, false);
   }

   private void disk(Matrix4f m, Vec3 c, double r, double alpha) {
      int count = this.quality.getValue().intValue();

      for (int i = 0; i < count; i++) {
         double a = i * Math.PI * 2.0 / count;
         double b = (i + 1) * Math.PI * 2.0 / count;
         this.band(m, c, 0.0, 0.0, r, r, a, b, alpha * 0.65, 0.0, this.glow.getValue());
      }
   }

   private Renderer3D.Vertex vertex(Matrix4f m, Vec3 c, double r, double a, double alpha) {
      return new Renderer3D.Vertex(
         m, (float)(c.x + Math.cos(a) * Math.max(0.0, r)), (float)c.y, (float)(c.z + Math.sin(a) * Math.max(0.0, r)), this.tint(a, alpha).getRGB()
      );
   }

   private void band(
      Matrix4f m,
      Vec3 c,
      double innerA,
      double innerB,
      double outerA,
      double outerB,
      double a,
      double b,
      double innerAlpha,
      double outerAlpha,
      boolean additive
   ) {
      List<Renderer3D.VertexCollection> list = additive ? Renderer3D.SHINE_QUADS : Renderer3D.QUADS;
      list.add(
         new Renderer3D.VertexCollection(
            this.vertex(m, c, innerA, a, innerAlpha),
            this.vertex(m, c, innerB, b, innerAlpha),
            this.vertex(m, c, outerB, b, outerAlpha),
            this.vertex(m, c, outerA, a, outerAlpha)
         )
      );
   }

   private record Burst(Vec3 center, long start) {
   }

   private record Pending(Vec3 center, long start) {
   }
}
