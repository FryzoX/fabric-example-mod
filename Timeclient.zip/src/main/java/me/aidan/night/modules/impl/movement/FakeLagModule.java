package night.modules.impl.movement;

import java.util.ArrayList;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ClientboundSetHealthPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.PosRot;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import night.events.SubscribeEvent;
import night.events.impl.PacketReceiveEvent;
import night.events.impl.PacketSendEvent;
import night.events.impl.RenderWorldEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.Setting;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.color.ColorUtils;
import night.utils.graphics.Renderer3D;
import night.utils.minecraft.EntityUtils;
import night.utils.system.Timer;

@RegisterModule(
   name = "FakeLag",
   description = "Chokes sent packets to look like you are lagging.",
   category = Module.Category.MOVEMENT
)
public class FakeLagModule extends Module {
   public NumberSetting choke = new NumberSetting("Choke", "The delay to choke packets for.", 2, 1, 5);
   public BooleanSetting onlyOnHoleLeave = new BooleanSetting("OnlyOnHoleLeave", "Only choke packets when leaving a hole.", false);
   public NumberSetting autoDisable = new NumberSetting(
      "AutoDisable", "AutoDisable", "Delay (ms) after FakeLag is enabled before it disables itself. 0 = off.", new Setting.Visibility(), 0, 0, 1000, 100
   );
   public ModeSetting mode = new ModeSetting(
      "RenderMode", "The rendering that will be applied to the target entity.", "Both", new String[]{"None", "Fill", "Outline", "Both"}
   );
   public ColorSetting fillColor = new ColorSetting(
      "FillColor",
      "The color that will be used for the fill rendering.",
      new ModeSetting.Visibility(this.mode, "Fill", "Both"),
      ColorUtils.getDefaultFillColor()
   );
   public ColorSetting outlineColor = new ColorSetting(
      "OutlineColor",
      "The color that will be used for the outline rendering.",
      new ModeSetting.Visibility(this.mode, "Outline", "Both"),
      ColorUtils.getDefaultOutlineColor()
   );
   private final ArrayList<ServerboundMovePlayerPacket> packets = new ArrayList<>();
   private final Timer timer = new Timer();
   private final Timer safety = new Timer();
   private final Timer chokeTimer = new Timer();
   private final Timer autoDisableTimer = new Timer();
   private boolean pendingAutoDisable = false;
   private boolean sending = false;
   private Vec3 serverPosition = null;
   private boolean isChoking = false;
   private BlockPos currentPos = null;

   @SubscribeEvent
   public void onPacketReceive(PacketReceiveEvent event) {
      if (!this.getNull()) {
         if (event.getPacket() instanceof ClientboundPlayerPositionPacket posPacket) {
            this.serverPosition = new Vec3(posPacket.change().position().x(), posPacket.change().position().y(), posPacket.change().position().z());
            this.sendPackets();
            this.safety.reset();
         } else {
            ClientboundSetHealthPacket packet;
            Packet var5;
            if (event.getPacket() instanceof ClientboundDisconnectPacket
               || (var5 = event.getPacket()) instanceof ClientboundSetHealthPacket && (packet = (ClientboundSetHealthPacket)var5).getHealth() <= 0.0F) {
               this.sendPackets();
               this.safety.reset();
            }
         }
      }
   }

   @SubscribeEvent
   public void onPacketSend(PacketSendEvent event) {
      ServerboundMovePlayerPacket packet;
      Object object;
      if (!this.getNull()
         && !this.sending
         && (object = event.getPacket()) instanceof ServerboundMovePlayerPacket
         && this.hasPositionChange(packet = (ServerboundMovePlayerPacket)object)) {
         if (!this.shouldChoke()) {
            this.serverPosition = mc.player.position();
         } else {
            object = this.packets;
            synchronized (object) {
               event.setCancelled(true);
               this.packets.add(packet);
            }
         }
      }
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldEvent event) {
      if (!this.getNull() && this.serverPosition != null && !this.mode.getValue().equalsIgnoreCase("None")) {
         AABB box = new AABB(
            this.serverPosition.x - mc.player.getBoundingBox().getXsize() / 2.0,
            this.serverPosition.y,
            this.serverPosition.z - mc.player.getBoundingBox().getZsize() / 2.0,
            this.serverPosition.x + mc.player.getBoundingBox().getXsize() / 2.0,
            this.serverPosition.y + mc.player.getBoundingBox().getYsize(),
            this.serverPosition.z + mc.player.getBoundingBox().getZsize() / 2.0
         );
         if (this.mode.getValue().equalsIgnoreCase("Fill") || this.mode.getValue().equalsIgnoreCase("Both")) {
            Renderer3D.renderBox(event.getMatrices(), box, this.fillColor.getColor());
         }

         if (this.mode.getValue().equalsIgnoreCase("Outline") || this.mode.getValue().equalsIgnoreCase("Both")) {
            Renderer3D.renderBoxOutline(event.getMatrices(), box, this.outlineColor.getColor());
         }
      }
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (!this.getNull()) {
         if (this.onlyOnHoleLeave.getValue()) {
            BlockPos prev = this.currentPos;
            this.currentPos = BlockPos.containing(mc.player.position());
            BlockPos prevPos = prev == null ? this.currentPos : prev;
            if (!this.currentPos.equals(prevPos)) {
               boolean currentInHole = HoleSnapModule.isInHole(this.currentPos);
               boolean prevInHole = HoleSnapModule.isInHole(prevPos);
               if (!currentInHole && prevInHole) {
                  this.isChoking = true;
                  this.chokeTimer.reset();
               }
            }

            if (this.isChoking && this.chokeTimer.hasTimeElapsed((int)(this.choke.getValue().floatValue() * 100.0F))) {
               this.sendPackets();
               this.isChoking = false;
            }
         } else if (!this.packets.isEmpty() && this.timer.hasTimeElapsed((int)(this.choke.getValue().floatValue() * 100.0F))) {
            this.sendPackets();
            this.timer.reset();
         }

         if (this.pendingAutoDisable && this.autoDisableTimer.hasTimeElapsed(this.autoDisable.getValue().intValue())) {
            this.pendingAutoDisable = false;
            this.setToggled(false);
         }
      }
   }

   private void startAutoDisable() {
      this.pendingAutoDisable = true;
      this.autoDisableTimer.reset();
   }

   @Override
   public void onEnable() {
      this.timer.reset();
      this.isChoking = false;
      if (this.autoDisable.getValue().intValue() > 0) {
         this.startAutoDisable();
      } else {
         this.pendingAutoDisable = false;
      }

      this.currentPos = null;
      this.serverPosition = mc.player != null ? mc.player.position() : null;
   }

   @Override
   public void onDisable() {
      if (!this.getNull()) {
         this.sendPackets();
         this.isChoking = false;
         this.currentPos = null;
      }
   }

   private void sendPackets() {
      ArrayList<ServerboundMovePlayerPacket> arrayList = this.packets;
      synchronized (arrayList) {
         this.sending = true;

         for (ServerboundMovePlayerPacket packet : this.packets) {
            mc.player.connection.send(packet);
         }

         if (!this.packets.isEmpty()) {
            this.serverPosition = mc.player.position();
         }

         this.packets.clear();
         this.sending = false;
      }
   }

   private boolean shouldChoke() {
      return this.onlyOnHoleLeave.getValue()
         ? this.isChoking
         : (EntityUtils.getSpeed(mc.player, EntityUtils.SpeedUnit.KILOMETERS) >= 5.0 || mc.player.fallDistance > 0.0) && this.safety.hasTimeElapsed(1000);
   }

   private boolean hasPositionChange(ServerboundMovePlayerPacket packet) {
      return packet instanceof Pos || packet instanceof PosRot;
   }

   @Override
   public String getMetaData() {
      return (this.shouldChoke() ? ChatFormatting.GREEN : ChatFormatting.RED) + "Choke";
   }
}
