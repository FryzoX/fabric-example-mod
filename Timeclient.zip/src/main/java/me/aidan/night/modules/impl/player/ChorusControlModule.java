package night.modules.impl.player;

import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ServerboundAcceptTeleportationPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import night.events.SubscribeEvent;
import night.events.impl.KeyInputEvent;
import night.events.impl.PacketReceiveEvent;
import night.events.impl.PacketSendEvent;
import night.events.impl.RenderWorldEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.settings.impl.BindSetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.ModeSetting;
import night.utils.color.ColorUtils;
import night.utils.graphics.Renderer3D;

public class ChorusControlModule extends Module {
   public BindSetting confirm = new BindSetting("Confirm", "The key that will be used to confirm the teleportation.", 340).disableHoldModes();
   public ModeSetting mode = new ModeSetting(
      "Mode", "The rendering that will be applied to the target block.", "Both", new String[]{"None", "Fill", "Outline", "Both"}
   );
   public ColorSetting fillColor = new ColorSetting(
      "FillColor",
      "The color that will be used for the fill rendering.",
      new ModeSetting.Visibility(this.mode, "Fill", "Both"),
      ColorUtils.getDefaultFillColor()
   );
   public ColorSetting outlineColor = new ColorSetting(
      "OutlineColor",
      "The color that will be used for the outline rendering.",
      new ModeSetting.Visibility(this.mode, "Outline", "Both"),
      ColorUtils.getDefaultOutlineColor()
   );
   private ClientboundPlayerPositionPacket packet;
   private boolean cancel = false;

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (mc.player != null && mc.level != null) {
         ItemStack stack;
         if (!this.cancel
            && mc.player.isUsingItem()
            && (stack = mc.player.getItemInHand(mc.player.getUsedItemHand())).getItem() == Items.CHORUS_FRUIT
            && stack.getUseDuration(mc.player) - mc.player.getTicksUsingItem() <= 1) {
            this.cancel = true;
         }
      }
   }

   @SubscribeEvent
   public void onKeyInput(KeyInputEvent event) {
      if (mc.player != null && mc.level != null && (mc.gui == null || mc.gui.screen() == null)) {
         if (this.packet != null) {
            if (event.getKey() == this.confirm.getValue()) {
               this.packet.handle(mc.getConnection());
               this.packet = null;
               this.cancel = false;
            }
         }
      }
   }

   @SubscribeEvent
   public void onPacketSend(PacketSendEvent event) {
      if (mc.player != null && mc.level != null) {
         if (this.cancel) {
            Packet<?> packet2 = event.getPacket();
            ServerboundMovePlayerPacket packet;
            if (packet2 instanceof ServerboundMovePlayerPacket && (packet = (ServerboundMovePlayerPacket)packet2).hasPosition()) {
               event.setCancelled(true);
            }

            if (event.getPacket() instanceof ServerboundAcceptTeleportationPacket) {
               event.setCancelled(true);
            }
         }
      }
   }

   @SubscribeEvent
   public void onPacketReceive(PacketReceiveEvent event) {
      if (mc.player != null && mc.level != null) {
         if (event.getPacket() instanceof ClientboundPlayerPositionPacket packet2 && this.cancel) {
            event.setCancelled(true);
            this.packet = packet2;
         }
      }
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldEvent event) {
      if (mc.player != null && mc.level != null && (mc.gui == null || mc.gui.screen() == null)) {
         if (this.packet != null) {
            Vec3 vec3d = new Vec3(this.packet.change().position().x(), this.packet.change().position().y(), this.packet.change().position().z());
            AABB box = EntityTypes.PLAYER.getDimensions().makeBoundingBox(vec3d);
            if (this.mode.getValue().equalsIgnoreCase("Fill") || this.mode.getValue().equalsIgnoreCase("Both")) {
               Renderer3D.renderBox(event.getMatrices(), box, this.fillColor.getColor());
            }

            if (this.mode.getValue().equalsIgnoreCase("Outline") || this.mode.getValue().equalsIgnoreCase("Both")) {
               Renderer3D.renderBoxOutline(event.getMatrices(), box, this.outlineColor.getColor());
            }
         }
      }
   }

   @Override
   public void onDisable() {
      if (mc.getConnection() != null && this.packet != null) {
         this.packet.handle(mc.getConnection());
         this.packet = null;
         this.cancel = false;
      }
   }
}
