package night.modules.impl.player;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.ShulkerBoxMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import night.events.SubscribeEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.settings.impl.WhitelistSetting;

@RegisterModule(
   name = "ChestStealer",
   description = "Automatically steals, dumps, or drops items to and from an open container.",
   category = Module.Category.PLAYER
)
public class ChestStealerModule extends Module {
   public BooleanSetting steal = new BooleanSetting("Steal", "Move matching items FROM the open container INTO your inventory.", true);
   public ModeSetting stealMode = new ModeSetting(
      "Mode",
      "WhiteList = steal items IN the list. BlackList = steal items NOT in the list. All = steal everything.",
      new BooleanSetting.Visibility(this.steal, true),
      "All",
      new String[]{"WhiteList", "BlackList", "All"}
   );
   public WhitelistSetting stealWhitelist = new WhitelistSetting(
      "List", "Items to compare against.", new BooleanSetting.Visibility(this.steal, true), WhitelistSetting.Type.ITEMS
   );
   public BooleanSetting dump = new BooleanSetting("Dump", "Move matching items FROM your inventory INTO the open container.", false);
   public ModeSetting dumpMode = new ModeSetting(
      "Mode",
      "WhiteList = dump items IN the list. BlackList = dump items NOT in the list. All = dump everything.",
      new BooleanSetting.Visibility(this.dump, true),
      "WhiteList",
      new String[]{"WhiteList", "BlackList", "All"}
   );
   public WhitelistSetting dumpWhitelist = new WhitelistSetting(
      "List", "Items to compare against.", new BooleanSetting.Visibility(this.dump, true), WhitelistSetting.Type.ITEMS
   );
   public BooleanSetting drop = new BooleanSetting("Drop", "Throw matching items OUT (Q / THROW).", false);
   public ModeSetting dropMode = new ModeSetting(
      "DropMode",
      "Mode",
      "WhiteList = drop items IN the list. BlackList = drop items NOT in the list. All = drop everything.",
      new BooleanSetting.Visibility(this.drop, true),
      "All",
      new String[]{"WhiteList", "BlackList", "All"}
   );
   public WhitelistSetting dropWhitelist = new WhitelistSetting(
      "DropList", "List", "Items to compare against for drop.", new BooleanSetting.Visibility(this.drop, true), WhitelistSetting.Type.ITEMS
   );
   public ModeSetting interact = new ModeSetting(
      "Interact", "Which of YOUR slots Dump/Drop act on: Hotbar (0-8), Inventory (9-35), or Both.", "Both", new String[]{"Hotbar", "Inventory", "Both"}
   );
   public NumberSetting delay = new NumberSetting("Delay", "Tick delay between action passes.", 1, 0, 20);
   public NumberSetting actionsPerTick = new NumberSetting("ActionsPerTick", "Max slot actions per pass.", 5, 1, 36);
   public BooleanSetting buttonMode = new BooleanSetting(
      "ButtonMode", "Adds vanilla Steal/Dump/Drop buttons at the top-right of the container/inventory GUI.", false
   );
   public BooleanSetting ignoreCustomName = new BooleanSetting(
      "IgnoreCustomName", "Skip any container with a custom (non-vanilla) title such as a shop GUI, except shulker boxes.", false
   );
   private int ticks = 0;
   public static volatile long lastContainerActionMs = 0L;
   private ChestStealerModule.Task activeTask = ChestStealerModule.Task.NONE;
   private int taskStep = 0;
   private int lastContainerId = -1;
   private int autoStealStep = 0;
   private int autoDumpStep = 0;
   private int autoDropStep = 0;

   @Override
   public void onDisable() {
      this.activeTask = ChestStealerModule.Task.NONE;
      this.taskStep = 0;
      this.autoStealStep = 0;
      this.autoDumpStep = 0;
      this.autoDropStep = 0;
      this.lastContainerId = -1;
      this.ticks = 0;
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (mc.player != null && mc.level != null && mc.gameMode != null) {
         if (!mc.player.isCreative()) {
            if (mc.player.containerMenu != null) {
               if (mc.player.containerMenu.getCarried().isEmpty()) {
                  int currentContainerId = mc.player.containerMenu.containerId;
                  if (currentContainerId != this.lastContainerId) {
                     this.lastContainerId = currentContainerId;
                     this.taskStep = 0;
                     this.autoStealStep = 0;
                     this.autoDumpStep = 0;
                     this.autoDropStep = 0;
                     this.activeTask = ChestStealerModule.Task.NONE;
                  }

                  long now;
                  if ((now = System.currentTimeMillis()) - RekitModule.lastContainerActionMs >= 200L
                     && now - InventorySorterModule.lastContainerActionMs >= 200L) {
                     if (this.ticks < this.delay.getValue().intValue()) {
                        this.ticks++;
                     } else {
                        this.ticks = 0;
                        int budget = this.actionsPerTick.getValue().intValue();
                        if (this.activeTask != ChestStealerModule.Task.NONE) {
                           boolean isContainer = mc.gui.screen() instanceof AbstractContainerScreen && !(mc.gui.screen() instanceof InventoryScreen);
                           boolean isInventory = mc.gui.screen() instanceof InventoryScreen;
                           if (!isContainer && !isInventory) {
                              this.activeTask = ChestStealerModule.Task.NONE;
                              this.taskStep = 0;
                           } else {
                              switch (this.activeTask) {
                                 case STEAL:
                                    if (isContainer) {
                                       int containerSlotCount2 = mc.player.containerMenu.slots.size() - 36;
                                       this.taskStep = this.taskStep
                                          + this.processStealStep(this.stealMode.getValue(), this.stealWhitelist, budget, this.taskStep);
                                       if (this.taskStep >= containerSlotCount2) {
                                          this.activeTask = ChestStealerModule.Task.NONE;
                                          this.taskStep = 0;
                                       }
                                    } else {
                                       this.activeTask = ChestStealerModule.Task.NONE;
                                       this.taskStep = 0;
                                    }
                                    break;
                                 case DUMP:
                                    if (isContainer) {
                                       this.taskStep = this.taskStep
                                          + this.processDumpStep(this.dumpMode.getValue(), this.dumpWhitelist, budget, this.taskStep);
                                       if (this.taskStep >= 36) {
                                          this.activeTask = ChestStealerModule.Task.NONE;
                                          this.taskStep = 0;
                                       }
                                    } else {
                                       this.activeTask = ChestStealerModule.Task.NONE;
                                       this.taskStep = 0;
                                    }
                                    break;
                                 case DROP:
                                    int containerSlotCount3 = isContainer ? mc.player.containerMenu.slots.size() - 36 : 0;
                                    int totalSlots = containerSlotCount3 + 36;
                                    this.taskStep = this.taskStep + this.processDropStep(this.dropMode.getValue(), this.dropWhitelist, budget, this.taskStep);
                                    if (this.taskStep >= totalSlots) {
                                       this.activeTask = ChestStealerModule.Task.NONE;
                                       this.taskStep = 0;
                                    }
                              }
                           }
                        } else if (!this.buttonMode.getValue()) {
                           boolean externalGui = mc.gui.screen() instanceof AbstractContainerScreen && !(mc.gui.screen() instanceof InventoryScreen);
                           if (!externalGui
                              || !this.ignoreCustomName.getValue()
                              || !this.hasCustomContainerTitle()
                              || mc.player.containerMenu instanceof ShulkerBoxMenu) {
                              if (this.steal.getValue() && externalGui && budget > 0) {
                                 int containerSlotCount = mc.player.containerMenu.slots.size() - 36;
                                 int scanned = this.processStealStep(this.stealMode.getValue(), this.stealWhitelist, budget, this.autoStealStep);
                                 this.autoStealStep += scanned;
                                 if (this.autoStealStep >= containerSlotCount) {
                                    this.autoStealStep = 0;
                                 }
                              }

                              if (this.dump.getValue() && externalGui && budget > 0) {
                                 int scanned = this.processDumpStep(this.dumpMode.getValue(), this.dumpWhitelist, budget, this.autoDumpStep);
                                 this.autoDumpStep += scanned;
                                 if (this.autoDumpStep >= 36) {
                                    this.autoDumpStep = 0;
                                 }
                              }

                              if (this.drop.getValue() && budget > 0) {
                                 int containerSlotCount = externalGui ? mc.player.containerMenu.slots.size() - 36 : 0;
                                 int totalSlotsx = containerSlotCount + 36;
                                 int scanned = this.processDropStep(this.dropMode.getValue(), this.dropWhitelist, budget, this.autoDropStep);
                                 this.autoDropStep += scanned;
                                 if (this.autoDropStep >= totalSlotsx) {
                                    this.autoDropStep = 0;
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public void triggerSteal() {
      if (this.canAct(true)) {
         this.activeTask = ChestStealerModule.Task.STEAL;
         this.taskStep = 0;
         this.ticks = this.delay.getValue().intValue();
      }
   }

   public void triggerDump() {
      if (this.canAct(true)) {
         this.activeTask = ChestStealerModule.Task.DUMP;
         this.taskStep = 0;
         this.ticks = this.delay.getValue().intValue();
      }
   }

   public void triggerDrop() {
      if (this.canAct(false)) {
         this.activeTask = ChestStealerModule.Task.DROP;
         this.taskStep = 0;
         this.ticks = this.delay.getValue().intValue();
      }
   }

   private boolean hasCustomContainerTitle() {
      if (!(mc.gui.screen() instanceof AbstractContainerScreen screen2)) {
         return false;
      } else {
         Component title = screen2.getTitle();
         return title == null ? false : !(title.getContents() instanceof TranslatableContents);
      }
   }

   private boolean canAct(boolean requireContainer) {
      if (mc.player == null || mc.level == null || mc.gameMode == null) {
         return false;
      } else if (mc.player.isCreative()) {
         return false;
      } else if (mc.player.containerMenu == null) {
         return false;
      } else if (!mc.player.containerMenu.getCarried().isEmpty()) {
         return false;
      } else {
         if (requireContainer) {
            boolean isContainer = mc.gui.screen() instanceof AbstractContainerScreen && !(mc.gui.screen() instanceof InventoryScreen);
            boolean isInventory = mc.gui.screen() instanceof InventoryScreen;
            if (!isContainer && !isInventory) {
               return false;
            }
         }

         return true;
      }
   }

   private int processStealStep(String modeVal, WhitelistSetting wl, int budget, int startStep) {
      if (mc.gui.screen() instanceof InventoryScreen) {
         return 0;
      } else {
         int containerId = mc.player.containerMenu.containerId;
         int containerSlotCount = mc.player.containerMenu.slots.size() - 36;
         int actions = 0;

         int step;
         for (step = startStep; step < containerSlotCount && actions < budget; step++) {
            ItemStack stack = ((Slot)mc.player.containerMenu.slots.get(step)).getItem();
            if (!stack.isEmpty() && this.matches(stack, modeVal, wl)) {
               this.quickMove(containerId, step);
               actions++;
            }
         }

         return Math.max(1, step - startStep);
      }
   }

   private int processDumpStep(String modeVal, WhitelistSetting wl, int budget, int startStep) {
      if (mc.gui.screen() instanceof InventoryScreen) {
         return 0;
      } else {
         int containerId = mc.player.containerMenu.containerId;
         int actions = 0;

         int step;
         for (step = startStep; step < 36 && actions < budget; step++) {
            int handlerSlot;
            ItemStack stack;
            if (this.inInteractRange(step)
               && !(stack = mc.player.getInventory().getItem(step)).isEmpty()
               && this.matches(stack, modeVal, wl)
               && (handlerSlot = this.invToHandlerSlot(step)) >= 0) {
               this.quickMove(containerId, handlerSlot);
               actions++;
            }
         }

         return Math.max(1, step - startStep);
      }
   }

   private int processDropStep(String modeVal, WhitelistSetting wl, int budget, int startStep) {
      int containerId = mc.player.containerMenu.containerId;
      boolean externalGui = mc.gui.screen() instanceof AbstractContainerScreen && !(mc.gui.screen() instanceof InventoryScreen);
      int containerSlotCount = externalGui ? mc.player.containerMenu.slots.size() - 36 : 0;
      int totalSlots = containerSlotCount + 36;
      int actions = 0;

      int step;
      for (step = startStep; step < totalSlots && actions < budget; step++) {
         if (step < containerSlotCount) {
            ItemStack stack2 = ((Slot)mc.player.containerMenu.slots.get(step)).getItem();
            if (!stack2.isEmpty() && this.matches(stack2, modeVal, wl)) {
               this.throwSlot(containerId, step);
               actions++;
            }
         } else {
            int invSlot = step - containerSlotCount;
            int handlerSlot;
            ItemStack stack;
            if (this.inInteractRange(invSlot)
               && !(stack = mc.player.getInventory().getItem(invSlot)).isEmpty()
               && this.matches(stack, modeVal, wl)
               && (handlerSlot = this.invToHandlerSlot(invSlot)) >= 0) {
               this.throwSlot(containerId, handlerSlot);
               actions++;
            }
         }
      }

      return Math.max(1, step - startStep);
   }

   private void quickMove(int containerId, int slot) {
      mc.gameMode.handleContainerInput(containerId, slot, 0, ContainerInput.QUICK_MOVE, mc.player);
      lastContainerActionMs = System.currentTimeMillis();
   }

   private void throwSlot(int containerId, int slot) {
      mc.gameMode.handleContainerInput(containerId, slot, 1, ContainerInput.THROW, mc.player);
      lastContainerActionMs = System.currentTimeMillis();
   }

   private boolean matches(ItemStack stack, String modeVal, WhitelistSetting wl) {
      if (stack != null && !stack.isEmpty()) {
         boolean listed = wl != null && wl.isWhitelistContains(stack.getItem());

         return switch (modeVal) {
            case "All" -> true;
            case "BlackList" -> !listed;
            default -> listed;
         };
      } else {
         return false;
      }
   }

   private boolean inInteractRange(int invSlot) {
      String var2 = this.interact.getValue();

      return switch (var2) {
         case "Hotbar" -> invSlot <= 8;
         case "Inventory" -> invSlot >= 9;
         default -> true;
      };
   }

   private int invToHandlerSlot(int invSlot) {
      Inventory playerInv = mc.player.getInventory();

      for (Slot slot : mc.player.containerMenu.slots) {
         if (slot.container == playerInv && slot.getContainerSlot() == invSlot) {
            return slot.index;
         }
      }

      return -1;
   }

   @Override
   public String getMetaData() {
      StringBuilder sb = new StringBuilder();
      if (this.steal.getValue()) {
         sb.append("Steal");
      }

      if (this.dump.getValue()) {
         sb.append(sb.length() > 0 ? "/Dump" : "Dump");
      }

      if (this.drop.getValue()) {
         sb.append(sb.length() > 0 ? "/Drop" : "Drop");
      }

      return sb.toString();
   }

   private static enum Task {
      NONE,
      STEAL,
      DUMP,
      DROP;
   }
}
