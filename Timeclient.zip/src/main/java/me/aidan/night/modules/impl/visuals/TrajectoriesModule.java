package night.modules.impl.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.arrow.Arrow;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ExperienceBottleItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.LingeringPotionItem;
import net.minecraft.world.item.SplashPotionItem;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import night.events.SubscribeEvent;
import night.events.impl.RenderWorldEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.CategorySetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.ModeSetting;
import night.utils.color.ColorUtils;
import night.utils.graphics.Renderer3D;
import night.utils.minecraft.EntityUtils;
import org.joml.Matrix4f;

@RegisterModule(
   name = "Trajectories",
   description = "Draws a predicted trajectory of where throwables will end up when you throw them.",
   category = Module.Category.VISUALS
)
public class TrajectoriesModule extends Module {
   public ColorSetting lineColor = new ColorSetting("LineColor", "The color of the trajectory line.", ColorUtils.getDefaultOutlineColor());
   public CategorySetting entitiesCategory = new CategorySetting("Entities", "The rendering that will be applied to entities hit by the trajectory.");
   public ModeSetting entitiesMode = new ModeSetting(
      "EntitiesMode",
      "Mode",
      "The rendering that will be applied to the target entity.",
      new CategorySetting.Visibility(this.entitiesCategory),
      "Both",
      new String[]{"None", "Fill", "Outline", "Both"}
   );
   public ColorSetting entitiesFillColor = new ColorSetting(
      "EntitiesFillColor",
      "FillColor",
      "The color that will be used for the fill rendering.",
      new ModeSetting.Visibility(this.entitiesMode, "Fill", "Both"),
      ColorUtils.getDefaultFillColor()
   );
   public ColorSetting entitiesOutlineColor = new ColorSetting(
      "EntitiesOutlineColor",
      "OutlineColor",
      "The color that will be used for the outline rendering.",
      new ModeSetting.Visibility(this.entitiesMode, "Outline", "Both"),
      ColorUtils.getDefaultOutlineColor()
   );
   public CategorySetting blocksCategory = new CategorySetting("Blocks", "The rendering that will be applied to blocks hit by the trajectory.");
   public ModeSetting blocksMode = new ModeSetting(
      "BlocksMode",
      "Mode",
      "The rendering that will be applied to the target block.",
      new CategorySetting.Visibility(this.blocksCategory),
      "Both",
      new String[]{"None", "Fill", "Outline", "Both"}
   );
   public ColorSetting blocksFillColor = new ColorSetting(
      "BlocksFillColor",
      "FillColor",
      "The color that will be used for the fill rendering.",
      new ModeSetting.Visibility(this.blocksMode, "Fill", "Both"),
      ColorUtils.getDefaultFillColor()
   );
   public ColorSetting blocksOutlineColor = new ColorSetting(
      "BlocksOutlineColor",
      "OutlineColor",
      "The color that will be used for the outline rendering.",
      new ModeSetting.Visibility(this.blocksMode, "Outline", "Both"),
      ColorUtils.getDefaultOutlineColor()
   );
   private List<Entity> hitEntities = new ArrayList<>();

   @SubscribeEvent
   public void onRenderWorld(RenderWorldEvent event) {
      if (mc.player != null && mc.level != null) {
         if (!mc.gui.hud.isHidden() && mc.options.getCameraType().isFirstPerson()) {
            InteractionHand activeHand;
            if (!(mc.player.getMainHandItem().getItem() instanceof BowItem)
               && !(mc.player.getMainHandItem().getItem() instanceof CrossbowItem)
               && !EntityUtils.isThrowable(mc.player.getMainHandItem().getItem())) {
               if (!(mc.player.getOffhandItem().getItem() instanceof BowItem)
                  && !(mc.player.getOffhandItem().getItem() instanceof CrossbowItem)
                  && !EntityUtils.isThrowable(mc.player.getOffhandItem().getItem())) {
                  return;
               }

               activeHand = InteractionHand.OFF_HAND;
            } else {
               activeHand = InteractionHand.MAIN_HAND;
            }

            this.hitEntities.clear();
            float yaw = Mth.lerp(event.getTickDelta(), mc.player.yRotO, mc.player.getYRot());
            if (mc.player.getOffhandItem().getItem() instanceof CrossbowItem
                  && EnchantmentHelper.getItemEnchantmentLevel(
                        mc.level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.MULTISHOT), mc.player.getOffhandItem()
                     )
                     != 0
               || mc.player.getMainHandItem().getItem() instanceof CrossbowItem
                  && EnchantmentHelper.getItemEnchantmentLevel(
                        mc.level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.MULTISHOT), mc.player.getMainHandItem()
                     )
                     != 0) {
               this.project(
                  event.getMatrices(),
                  activeHand == InteractionHand.OFF_HAND ? mc.player.getOffhandItem().getItem() : mc.player.getMainHandItem().getItem(),
                  yaw - 10.0F,
                  event.getTickDelta()
               );
               this.project(
                  event.getMatrices(),
                  activeHand == InteractionHand.OFF_HAND ? mc.player.getOffhandItem().getItem() : mc.player.getMainHandItem().getItem(),
                  yaw,
                  event.getTickDelta()
               );
               this.project(
                  event.getMatrices(),
                  activeHand == InteractionHand.OFF_HAND ? mc.player.getOffhandItem().getItem() : mc.player.getMainHandItem().getItem(),
                  yaw + 10.0F,
                  event.getTickDelta()
               );
            } else {
               this.project(
                  event.getMatrices(),
                  activeHand == InteractionHand.OFF_HAND ? mc.player.getOffhandItem().getItem() : mc.player.getMainHandItem().getItem(),
                  yaw,
                  event.getTickDelta()
               );
            }
         }
      }
   }

   private void project(PoseStack matrices, Item item, float yaw, float tickDelta) {
      double x = Mth.lerp(tickDelta, mc.player.xo, mc.player.getX());
      double y = Mth.lerp(tickDelta, mc.player.yo, mc.player.getY());
      double z = Mth.lerp(tickDelta, mc.player.zo, mc.player.getZ());
      y = y + mc.player.getEyeHeight(mc.player.getPose()) - 0.1000000014901161;
      float maxDistance = item instanceof BowItem ? 1.0F : 0.4F;
      float pitch = Mth.lerp(tickDelta, mc.player.xRotO, mc.player.getXRot());
      double motionX = -Mth.sin(yaw / 180.0F * (float) Math.PI) * Mth.cos(pitch / 180.0F * (float) Math.PI) * maxDistance;
      double motionY = -Mth.sin((pitch - this.getThrowPitch(item)) / 180.0F * 3.141593F) * maxDistance;
      double motionZ = Mth.cos(yaw / 180.0F * (float) Math.PI) * Mth.cos(pitch / 180.0F * (float) Math.PI) * maxDistance;
      float power = mc.player.getTicksUsingItem() / 20.0F;
      if ((power = (power * power + power * 2.0F) / 3.0F) > 1.0F || power == 0.0F) {
         power = 1.0F;
      }

      float distance = Mth.sqrt((float)(motionX * motionX + motionY * motionY + motionZ * motionZ));
      motionX /= distance;
      motionY /= distance;
      motionZ /= distance;
      float pow = (item instanceof BowItem ? power * 2.0F : (item instanceof CrossbowItem ? 2.2F : 1.0F)) * this.getThrowVelocity(item);
      motionX *= pow;
      motionY *= pow;
      motionZ *= pow;
      if (!mc.player.onGround()) {
         motionY += mc.player.getDeltaMovement().y;
      }

      Matrix4f matrix4f = matrices.last().pose();
      boolean landed = false;
      BlockHitResult result = null;
      Entity entity = null;

      while (!landed && y > -65.0) {
         Vec3 lastPosition = new Vec3(x, y, z);
         if (mc.level.getBlockState(new BlockPos((int)(x += motionX), (int)(y += motionY), (int)(z += motionZ))).getBlock() == Blocks.WATER) {
            motionX *= 0.8;
            motionY *= 0.8;
            motionZ *= 0.8;
         } else {
            motionX *= 0.99;
            motionY *= 0.99;
            motionZ *= 0.99;
         }

         double var36;
         double var37;
         double var38;
         motionY = item instanceof BowItem
            ? (var36 = motionY - 0.05F)
            : (mc.player.getMainHandItem().getItem() instanceof CrossbowItem ? (var37 = motionY - 0.05F) : (var38 = motionY - 0.03F));
         Vec3 position = new Vec3(x, y, z);
         Entity hitEntity = this.getHitEntity(new AABB(x - 1.0, y - 1.0, z - 1.0, x + 1.0, y + 1.0, z + 1.0));
         BlockHitResult possibleResult = mc.level.clip(new ClipContext(lastPosition, position, Block.OUTLINE, Fluid.NONE, mc.player));
         if (hitEntity != null) {
            entity = hitEntity;
            landed = true;
         } else if (possibleResult != null && possibleResult.getType() != Type.MISS) {
            result = possibleResult;
            landed = true;
         }

         Renderer3D.DEBUG_LINES
            .add(
               new Renderer3D.VertexCollection(
                  new Renderer3D.Vertex(
                     matrix4f,
                     (float)(lastPosition.x - mc.gameRenderer.mainCamera().position().x),
                     (float)(lastPosition.y - mc.gameRenderer.mainCamera().position().y),
                     (float)(lastPosition.z - mc.gameRenderer.mainCamera().position().z),
                     this.lineColor.getColor().getRGB()
                  ),
                  new Renderer3D.Vertex(
                     matrix4f,
                     (float)(position.x - mc.gameRenderer.mainCamera().position().x),
                     (float)(position.y - mc.gameRenderer.mainCamera().position().y),
                     (float)(position.z - mc.gameRenderer.mainCamera().position().z),
                     this.lineColor.getColor().getRGB()
                  )
               )
            );
      }

      if (result != null && result.getType() == Type.BLOCK) {
         AABB box = new AABB(
            result.getLocation().x - 0.15,
            result.getLocation().y - 0.15,
            result.getLocation().z - 0.15,
            result.getLocation().x + 0.15,
            result.getLocation().y + 0.15,
            result.getLocation().z + 0.15
         );
         if (this.blocksMode.getValue().equalsIgnoreCase("Fill") || this.blocksMode.getValue().equalsIgnoreCase("Both")) {
            Renderer3D.renderBox(matrices, box, this.blocksFillColor.getColor());
         }

         if (this.blocksMode.getValue().equalsIgnoreCase("Outline") || this.blocksMode.getValue().equalsIgnoreCase("Both")) {
            Renderer3D.renderBoxOutline(matrices, box, this.blocksOutlineColor.getColor());
         }
      }

      if (entity != null && !this.hitEntities.contains(entity)) {
         if (this.entitiesMode.getValue().equalsIgnoreCase("Fill") || this.entitiesMode.getValue().equalsIgnoreCase("Both")) {
            Renderer3D.renderBox(matrices, entity.getBoundingBox(), this.entitiesFillColor.getColor());
         }

         if (this.entitiesMode.getValue().equalsIgnoreCase("Outline") || this.entitiesMode.getValue().equalsIgnoreCase("Both")) {
            Renderer3D.renderBoxOutline(matrices, entity.getBoundingBox(), this.entitiesOutlineColor.getColor());
         }

         this.hitEntities.add(entity);
      }
   }

   private Entity getHitEntity(AABB box) {
      for (Entity entity : mc.level.entitiesForRendering()) {
         if (entity != mc.player && !(entity instanceof Arrow) && entity.getBoundingBox().intersects(box)) {
            return entity;
         }
      }

      return null;
   }

   private float getThrowVelocity(Item item) {
      if (item instanceof SplashPotionItem || item instanceof LingeringPotionItem) {
         return 0.5F;
      } else if (item instanceof ExperienceBottleItem) {
         return 0.59F;
      } else {
         return item instanceof TridentItem ? 2.0F : 1.5F;
      }
   }

   private int getThrowPitch(Item item) {
      return !(item instanceof SplashPotionItem) && !(item instanceof LingeringPotionItem) && !(item instanceof ExperienceBottleItem) ? 0 : 20;
   }
}
