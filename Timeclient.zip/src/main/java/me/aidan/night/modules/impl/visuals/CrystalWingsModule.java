package night.modules.impl.visuals;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.ClientDisconnectEvent;
import night.events.impl.EntitySpawnEvent;
import night.events.impl.PacketSendEvent;
import night.events.impl.RenderWorldEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.impl.combat.AutoCrystalModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.graphics.CrystalWingsMath;
import night.utils.graphics.CrystalWingsState;
import night.utils.graphics.Renderer3D;
import org.joml.Matrix4f;

@RegisterModule(
   name = "CrystalWings",
   description = "One animated wing pair after repeated own crystal placements on one block in combat.",
   category = Module.Category.VISUALS
)
public class CrystalWingsModule extends Module {
   public ModeSetting style = new ModeSetting("Style", "Simple wing silhouette.", "Curl", CrystalWingsMath.STYLES);
   public NumberSetting crystalCount = new NumberSetting("CrystalCount", "Successful own placements on the same block before wings appear.", 50, 1, 500);
   public NumberSetting resetDelay = new NumberSetting("ResetDelay", "Idle milliseconds before the block counter resets.", 3000, 500, 15000);
   public NumberSetting holdTime = new NumberSetting("HoldTime", "Keep wings after the last placement, in milliseconds.", 1000, 100, 5000);
   public NumberSetting targetGrace = new NumberSetting("TargetGrace", "Grace for brief AutoCrystal target flicker, in milliseconds.", 350, 0, 1500);
   public NumberSetting scale = new NumberSetting("Scale", "Overall wing size.", 0.75F, 0.15F, 2.0F);
   public NumberSetting width = new NumberSetting("Width", "Horizontal size multiplier.", 1.0F, 0.4F, 2.0F);
   public NumberSetting height = new NumberSetting("Height", "Vertical size multiplier.", 1.0F, 0.4F, 2.0F);
   public NumberSetting gap = new NumberSetting("Gap", "Distance between the two wing roots, in blocks.", 0.35F, 0.0F, 1.5F);
   public NumberSetting heightOffset = new NumberSetting("HeightOffset", "Attachment height above the crystal base.", 1.1F, 0.1F, 2.5F);
   public NumberSetting backOffset = new NumberSetting("BackOffset", "Move wings behind the crystal relative to the camera.", 0.16F, 0.0F, 0.75F);
   public NumberSetting opacity = new NumberSetting("Opacity", "Wing opacity percent; 0 hides wings.", 55, 0, 100);
   public ColorSetting color = new ColorSetting("Color", "Wing color.", new ColorSetting.Color(Color.WHITE, false, false));
   public BooleanSetting animate = new BooleanSetting("Animate", "Gently flap the wings.", true);
   public NumberSetting flapSpeed = new NumberSetting("FlapSpeed", "Flaps per second.", 0.65F, 0.0F, 3.0F);
   public NumberSetting flapAngle = new NumberSetting("FlapAngle", "Maximum flap angle in degrees.", 12.0F, 0.0F, 40.0F);
   public BooleanSetting glow = new BooleanSetting("Glow", "One soft edge layer; no postprocessing shader.", false);
   public NumberSetting glowStrength = new NumberSetting("GlowStrength", "Edge glow intensity.", 0.2F, 0.0F, 0.6F);
   public NumberSetting lineWidth = new NumberSetting("LineWidth", "Contour thickness in local wing units.", 0.018F, 0.005F, 0.06F);
   public ModeSetting appearStyle = new ModeSetting(
      "AppearStyle", "Appearance runs once when the block reaches CrystalCount.", "Grow", new String[]{"Grow", "Fade", "Unfold", "Pop", "None"}
   );
   public NumberSetting appearDuration = new NumberSetting("AppearDuration", "Appearance duration in milliseconds.", 250, 50, 1500);
   public NumberSetting startScale = new NumberSetting("StartScale", "Initial size for Grow and Pop.", 0.2F, 0.05F, 1.0F);
   public NumberSetting overshoot = new NumberSetting("Overshoot", "Small size bounce for Pop.", 0.08F, 0.0F, 0.15F);
   public NumberSetting range = new NumberSetting("Range", "Maximum visible distance in blocks.", 32, 4, 96);
   private final ArrayDeque<CrystalWingsModule.Pending> pending = new ArrayDeque<>();
   private final LinkedHashMap<UUID, Long> seen = new LinkedHashMap<>();
   private final CrystalWingsState state = new CrystalWingsState();
   private ClientLevel world;
   private Object player;
   private Vec3 anchor;
   private long targetSeen;
   private long animationOrigin;
   private String cachedStyle;
   private CrystalWingsMath.Mesh mesh;

   private void clear() {
      this.pending.clear();
      this.seen.clear();
      this.state.clear();
      this.anchor = null;
      this.targetSeen = 0L;
      this.animationOrigin = System.nanoTime();
   }

   @Override
   public void onEnable() {
      this.clear();
      this.world = mc.level;
      this.player = mc.player;
   }

   @Override
   public void onDisable() {
      this.clear();
      this.world = null;
      this.player = null;
   }

   @SubscribeEvent
   public void onDisconnect(ClientDisconnectEvent e) {
      ClientLevel oldWorld = mc.level;
      Object oldPlayer = mc.player;
      mc.execute(() -> {
         if (mc.level == oldWorld && mc.player == oldPlayer) {
            this.onDisable();
         }
      });
   }

   private void context() {
      if (this.world != mc.level || this.player != mc.player) {
         this.clear();
         this.world = mc.level;
         this.player = mc.player;
      }
   }

   private boolean combat(long now) {
      AutoCrystalModule ac = Night.MODULE_MANAGER.getModule(AutoCrystalModule.class);
      if (ac != null && ac.isToggled() && ac.getTarget() != null && ac.getTarget().isAlive()) {
         this.targetSeen = now;
      }

      return this.targetSeen != 0L && now - this.targetSeen <= this.targetGrace.getValue().longValue() * 1000000L;
   }

   private void expire(long now) {
      this.pending.removeIf(p -> now - p.time > 2000000000L);
      this.seen.entrySet().removeIf(e -> now - e.getValue() > 3000000000L);
      this.state.expire(now, this.resetDelay.getValue().intValue());
   }

   @SubscribeEvent
   public void onTick(TickEvent e) {
      if (this.isToggled()) {
         this.context();
         if (mc.player != null && mc.level != null) {
            long now = System.nanoTime();
            this.combat(now);
            this.expire(now);
         }
      }
   }

   @SubscribeEvent
   public void onUse(PacketSendEvent.Post e) {
      if (this.isToggled() && mc.player != null && mc.level != null && e.getPacket() instanceof ServerboundUseItemOnPacket packet) {
         int var8 = Night.POSITION_MANAGER.getServerSlot();
         boolean own = packet.getHand() == InteractionHand.OFF_HAND
            ? mc.player.getOffhandItem().is(Items.END_CRYSTAL)
            : var8 >= 0 && var8 < 9 && mc.player.getInventory().getItem(var8).is(Items.END_CRYSTAL);
         if (own) {
            Vec3 expected = Vec3.atBottomCenterOf(packet.getHitResult().getBlockPos().above());
            ClientLevel level = mc.level;
            Object who = mc.player;
            mc.execute(() -> {
               if (this.isToggled() && mc.level == level && mc.player == who) {
                  this.context();
                  long now = System.nanoTime();
                  if (this.combat(now)) {
                     this.expire(now);

                     while (this.pending.size() >= 64) {
                        this.pending.removeFirst();
                     }

                     this.pending.addLast(new CrystalWingsModule.Pending(expected, now));
                  }
               }
            });
         }
      }
   }

   @SubscribeEvent
   public void onSpawn(EntitySpawnEvent e) {
      if (this.isToggled() && mc.player != null && mc.level != null && e.getEntity() instanceof EndCrystal crystal) {
         Vec3 var7 = crystal.position();
         UUID id = crystal.getUUID();
         ClientLevel level = mc.level;
         LocalPlayer who = mc.player;
         mc.execute(
            () -> {
               if (this.isToggled() && mc.level == level && mc.player == who) {
                  this.context();
                  long now = System.nanoTime();
                  this.expire(now);
                  if (!this.seen.containsKey(id) && this.combat(now)) {
                     CrystalWingsModule.Pending match = null;

                     for (CrystalWingsModule.Pending p : this.pending) {
                        if (p.position.distanceToSqr(var7) < 0.04) {
                           match = p;
                           break;
                        }
                     }

                     if (match != null) {
                        this.pending.remove(match);
                        if (!(mc.player.position().distanceToSqr(var7) > Math.pow(this.range.getValue().doubleValue(), 2.0))) {
                           while (this.seen.size() >= 128) {
                              this.seen.remove(this.seen.keySet().iterator().next());
                           }

                           this.seen.put(id, now);
                           this.state
                              .record(BlockPos.containing(var7).asLong(), now, this.crystalCount.getValue().intValue(), this.resetDelay.getValue().intValue());
                           this.anchor = var7;
                        }
                     }
                  }
               }
            }
         );
      }
   }

   @SubscribeEvent
   public void onRender(RenderWorldEvent e) {
      if (this.isToggled()) {
         this.context();
         if (mc.player != null && mc.level != null && Renderer3D.RENDERING) {
            long now = System.nanoTime();
            this.combat(now);
            this.state.expire(now, this.resetDelay.getValue().intValue());
            if (this.anchor != null
               && this.state.visible(now, this.holdTime.getValue().intValue(), this.targetSeen, this.targetGrace.getValue().intValue())
               && this.opacity.getValue().intValue() != 0) {
               double size = this.scale.getValue().doubleValue();
               double extent = size
                     * (1.0 + this.overshoot.getValue().doubleValue())
                     * (Math.max(this.width.getValue().doubleValue() * 2.0, this.height.getValue().doubleValue() * 1.5) + this.gap.getValue().doubleValue())
                  + this.heightOffset.getValue().doubleValue()
                  + this.backOffset.getValue().doubleValue()
                  + 1.0;
               if (!(mc.player.position().distanceToSqr(this.anchor) > Math.pow(this.range.getValue().doubleValue(), 2.0))
                  && Renderer3D.isFrustumVisible(
                     new AABB(
                        this.anchor.x - extent,
                        this.anchor.y - extent,
                        this.anchor.z - extent,
                        this.anchor.x + extent,
                        this.anchor.y + extent + 3.0,
                        this.anchor.z + extent
                     )
                  )) {
                  String selected = this.style.getValue();
                  if (this.mesh == null || !selected.equals(this.cachedStyle)) {
                     this.mesh = CrystalWingsMath.model(selected);
                     this.cachedStyle = selected;
                  }

                  double p = CrystalWingsMath.progress(now - this.state.appearedAt(), this.appearDuration.getValue().intValue());
                  String appearance = this.appearStyle.getValue();
                  double alpha = this.opacity.getValue().doubleValue() / 100.0 * (appearance.equals("None") ? 1.0 : CrystalWingsMath.ease(p));
                  if (!(alpha < 0.001)) {
                     size *= CrystalWingsMath.appearScale(appearance, p, this.startScale.getValue().doubleValue(), this.overshoot.getValue().doubleValue());
                     double flap = this.animate.getValue()
                        ? CrystalWingsMath.flap(
                           (now - this.animationOrigin) / 1.0E9, this.flapSpeed.getValue().doubleValue(), this.flapAngle.getValue().doubleValue()
                        )
                        : 0.0;
                     if (appearance.equals("Unfold")) {
                        flap += Math.toRadians(65.0) * (1.0 - CrystalWingsMath.ease(p));
                     }

                     Vec3 camera = mc.gameRenderer.mainCamera().position();
                     Vec3 away = this.anchor.subtract(camera).multiply(1.0, 0.0, 1.0);
                     if (away.lengthSqr() < 1.0E-8) {
                        away = new Vec3(0.0, 0.0, 1.0);
                     } else {
                        away = away.normalize();
                     }

                     Vec3 right = new Vec3(away.z, 0.0, -away.x);
                     Vec3 origin = this.anchor
                        .add(0.0, this.heightOffset.getValue().doubleValue(), 0.0)
                        .add(away.scale(this.backOffset.getValue().doubleValue()))
                        .subtract(camera);
                     Matrix4f matrix = e.getMatrices().last().pose();
                     Color tint = this.color.getColor();

                     for (int side : new int[]{-1, 1}) {
                        if (!selected.equals("Outline")) {
                           for (double[][] triangle : this.mesh.triangles()) {
                              Renderer3D.Vertex a = this.vertex(matrix, origin, right, away, triangle[0], side, size, flap, tint, alpha);
                              Renderer3D.Vertex b = this.vertex(matrix, origin, right, away, triangle[1], side, size, flap, tint, alpha);
                              Renderer3D.Vertex c = this.vertex(matrix, origin, right, away, triangle[2], side, size, flap, tint, alpha);
                              Renderer3D.QUADS.add(new Renderer3D.VertexCollection(a, b, c, c));
                           }
                        }

                        this.lines(matrix, origin, right, away, this.mesh.outline(), true, side, size, flap, tint, alpha);
                        if (!selected.equals("Outline")) {
                           for (List<double[]> seam : this.mesh.seams()) {
                              this.lines(
                                 matrix,
                                 origin,
                                 right,
                                 away,
                                 seam,
                                 false,
                                 side,
                                 size,
                                 flap,
                                 new Color(tint.getRed() / 4, tint.getGreen() / 4, tint.getBlue() / 4, tint.getAlpha()),
                                 alpha * 0.8
                              );
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private Renderer3D.Vertex vertex(
      Matrix4f m, Vec3 origin, Vec3 right, Vec3 away, double[] point, int side, double size, double flap, Color color, double alpha
   ) {
      double x = side * (this.gap.getValue().doubleValue() / 2.0 + point[0] * Math.cos(flap)) * size * this.width.getValue().doubleValue();
      double y = point[1] * size * this.height.getValue().doubleValue();
      double z = point[0] * Math.sin(flap) * size * this.width.getValue().doubleValue();
      Vec3 position = origin.add(right.scale(x)).add(0.0, y, 0.0).add(away.scale(z));
      int argb = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)Math.clamp(color.getAlpha() * alpha, 0.0, 255.0)).getRGB();
      return new Renderer3D.Vertex(m, (float)position.x, (float)position.y, (float)position.z, argb);
   }

   private void lines(
      Matrix4f m, Vec3 origin, Vec3 right, Vec3 away, List<double[]> points, boolean closed, int side, double size, double flap, Color color, double alpha
   ) {
      for (int i = 0; i < (closed ? points.size() : points.size() - 1); i++) {
         double[] a = points.get(i);
         double[] b = points.get((i + 1) % points.size());
         double dx = b[0] - a[0];
         double dy = b[1] - a[1];
         double length = Math.hypot(dx, dy);
         if (!(length < 1.0E-8)) {
            double thickness = this.lineWidth.getValue().doubleValue() / 2.0;
            this.band(m, origin, right, away, a, b, -dy / length * thickness, dx / length * thickness, side, size, flap, color, alpha, false);
            if (this.glow.getValue() && closed) {
               this.band(
                  m,
                  origin,
                  right,
                  away,
                  a,
                  b,
                  -dy / length * thickness * 3.0,
                  dx / length * thickness * 3.0,
                  side,
                  size,
                  flap,
                  color,
                  alpha * this.glowStrength.getValue().doubleValue(),
                  true
               );
            }
         }
      }
   }

   private void band(
      Matrix4f m,
      Vec3 origin,
      Vec3 right,
      Vec3 away,
      double[] a,
      double[] b,
      double ox,
      double oy,
      int side,
      double size,
      double flap,
      Color color,
      double alpha,
      boolean glow
   ) {
      List<Renderer3D.VertexCollection> list = glow ? Renderer3D.SHINE_QUADS : Renderer3D.QUADS;
      list.add(
         new Renderer3D.VertexCollection(
            this.vertex(m, origin, right, away, new double[]{a[0] - ox, a[1] - oy}, side, size, flap, color, alpha),
            this.vertex(m, origin, right, away, new double[]{b[0] - ox, b[1] - oy}, side, size, flap, color, alpha),
            this.vertex(m, origin, right, away, new double[]{b[0] + ox, b[1] + oy}, side, size, flap, color, alpha),
            this.vertex(m, origin, right, away, new double[]{a[0] + ox, a[1] + oy}, side, size, flap, color, alpha)
         )
      );
   }

   @Override
   public String getMetaData() {
      return this.state.count() + "/" + this.crystalCount.getValue().intValue();
   }

   private record Pending(Vec3 position, long time) {
   }
}
