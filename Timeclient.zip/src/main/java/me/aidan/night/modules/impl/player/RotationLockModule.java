package night.modules.impl.player;

import net.minecraft.util.Mth;
import night.events.SubscribeEvent;
import night.events.impl.PlayerUpdateEvent;
import night.mixins.accessors.EntityAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;

@RegisterModule(
   name = "RotationLock",
   description = "Locks your rotation to a certain yaw and pitch.",
   category = Module.Category.PLAYER
)
public class RotationLockModule extends Module {
   public ModeSetting mode = new ModeSetting("Mode", "Whether the pitch or yaw will be locked.", "Both", new String[]{"Yaw", "Pitch", "Both"});
   public BooleanSetting custom = new BooleanSetting(
      "Custom",
      "Holds your locked angle steady (camera free to turn) and only re-locks, snapping straight to the next 45deg, once you've turned far enough past it -- instead of an always-fixed value.",
      new ModeSetting.Visibility(this.mode, "Yaw", "Pitch", "Both"),
      false
   );
   public NumberSetting pitch = new NumberSetting(
      "Pitch", "Pitch", "The fixed degrees pitch locks to when Custom is off.", new ModeSetting.Visibility(this.mode, "Pitch", "Both"), 0.0F, -90.0F, 90.0F, 1
   );
   private boolean lockInitialized = false;
   private float lockedYaw = 0.0F;
   private float lockedPitch = 0.0F;
   private static final long SHAKE_DURATION_MS = 180L;
   private static final float SHAKE_AMPLITUDE_DEG = 3.0F;
   private long yawSnapAtMs = -1L;
   private long pitchSnapAtMs = -1L;

   @Override
   public void onEnable() {
      this.lockInitialized = false;
   }

   private float shakeOffset(long snapAtMs) {
      if (snapAtMs < 0L) {
         return 0.0F;
      } else {
         long elapsed = System.currentTimeMillis() - snapAtMs;
         if (elapsed >= 180L) {
            return 0.0F;
         } else {
            float progress = (float)elapsed / 180.0F;
            return (float)(Math.sin(progress * Math.PI * 5.0) * 3.0 * (1.0F - progress));
         }
      }
   }

   public float getShakeYawOffset() {
      return this.custom.getValue() ? this.shakeOffset(this.yawSnapAtMs) : 0.0F;
   }

   public float getShakePitchOffset() {
      return this.custom.getValue() ? this.shakeOffset(this.pitchSnapAtMs) : 0.0F;
   }

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (mc.player != null && this.custom.getValue()) {
         float realYaw = ((EntityAccessor)mc.player).getRawYRot();
         float realPitch = ((EntityAccessor)mc.player).getRawXRot();
         if (!this.lockInitialized) {
            this.lockedYaw = nearest45(realYaw);
            this.lockedPitch = nearest45(realPitch);
            this.lockInitialized = true;
         } else {
            if (Math.abs(Mth.wrapDegrees(realYaw - this.lockedYaw)) >= 45.0F) {
               float newYaw = nearest45(realYaw);
               if (newYaw != this.lockedYaw) {
                  this.yawSnapAtMs = System.currentTimeMillis();
               }

               this.lockedYaw = newYaw;
            }

            if (Math.abs(Mth.wrapDegrees(realPitch - this.lockedPitch)) >= 45.0F) {
               float newPitch = nearest45(realPitch);
               if (newPitch != this.lockedPitch) {
                  this.pitchSnapAtMs = System.currentTimeMillis();
               }

               this.lockedPitch = newPitch;
            }
         }
      } else {
         this.lockInitialized = false;
      }
   }

   private static float nearest45(float degrees) {
      return Mth.wrapDegrees(Math.round(degrees / 45.0F) * 45.0F);
   }

   public float getYawValue(float realYaw) {
      return this.custom.getValue() ? this.lockedYaw : nearest45(realYaw);
   }

   public float getPitchValue(float realPitch) {
      return this.custom.getValue() ? this.lockedPitch : this.pitch.getValue().floatValue();
   }

   @Override
   public String getMetaData() {
      String yawText = this.custom.getValue() ? String.valueOf(this.lockedYaw) : "Auto";
      String pitchText = this.custom.getValue() ? String.valueOf(this.lockedPitch) : String.valueOf(this.pitch.getValue().floatValue());
      return yawText + ", " + pitchText;
   }
}
