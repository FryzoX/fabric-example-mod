package night.modules.impl.combat;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PacketReceiveEvent;
import night.events.impl.PlayerUpdateEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.impl.visuals.LogoutSpotModule;
import night.modules.impl.visuals.PopChamsModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.EntityUtils;
import night.utils.minecraft.HoleUtils;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.WorldUtils;
import night.utils.rotations.RotationUtils;
import night.utils.system.ThreadExecutor;

@RegisterModule(
   name = "AutoTrap",
   description = "Automatically places blocks around you to prevent other people from getting inside your hole.",
   category = Module.Category.COMBAT
)
public class AutoTrapModule extends Module {
   public ModeSetting autoSwitch = new ModeSetting(
      "Switch", "The mode that will be used for automatically switching to necessary items.", "Silent", InventoryUtils.SWITCH_MODES
   );
   public ModeSetting mode = new ModeSetting("Mode", "The offsets that will be used when trapping.", "Full", new String[]{"Partial", "Full"});
   public BooleanSetting head = new BooleanSetting(
      "Head", "Whether or not to cover the block on the players head.", new ModeSetting.Visibility(this.mode, "Full"), true
   );
   public BooleanSetting noFeet = new BooleanSetting(
      "NoFeet", "Skips the new floor-level ring around the target's feet entirely -- walls and head (if enabled) still trap as before.", false
   );
   public BooleanSetting disableAfterFeet = new BooleanSetting(
      "DisableAfterFeet",
      "Stops re-trapping the floor-level feet ring once it has successfully placed there at least once since the module was enabled -- walls/head keep trapping normally.",
      new BooleanSetting.Visibility(this.noFeet, false),
      false
   );
   public BooleanSetting asynchronous = new BooleanSetting("Asynchronous", "Performs calculations on separate threads.", true);
   public NumberSetting bpt = new NumberSetting("BPT", "The maximum number of blocks to place per tick.", 4, 1, 8);
   public NumberSetting range = new NumberSetting("Range", "The maximum range at which the blocks will be placed at.", 5.0, 0.0, 12.0);
   public NumberSetting enemyRange = new NumberSetting("EnemyRange", "The maximum distance at which the target should be at.", 8.0F, 0.0F, 16.0F);
   public BooleanSetting await = new BooleanSetting("Await", "Waits for blocks to be registered by the client before placing on them.", false);
   public ModeSetting rotate = new ModeSetting("Rotate", "The rotation mode when placing blocks.", "Grim", new String[]{"None", "Normal", "Grim"});
   public BooleanSetting strictDirection = new BooleanSetting("StrictDirection", "Only places using directions that face you.", false);
   public BooleanSetting airPlace = new BooleanSetting(
      "AirPlace",
      "Places blocks directly in the air with no real neighbor needed, skipping the support-scaffold bootstrap entirely instead of only using it as a last resort.",
      false
   );
   public BooleanSetting attack = new BooleanSetting("Attack", "Attacks any crystal that interferes with your trap.", false);
   public BooleanSetting attackRotate = new BooleanSetting(
      "AttackRotate", "Rotate", "Rotates toward the crystal before attacking it.", new BooleanSetting.Visibility(this.attack, true), true
   );
   public NumberSetting attackRange = new NumberSetting(
      "AttackRange", "Range", "The maximum range at which crystals will be attacked.", new BooleanSetting.Visibility(this.attack, true), 3.0F, 1.0F, 6.0F
   );
   public NumberSetting attackAge = new NumberSetting(
      "AttackAge", "Age", "The minimum age (in ticks) a crystal must reach before being attacked.", new BooleanSetting.Visibility(this.attack, true), 5, 0, 20
   );
   public BooleanSetting attackMultiTask = new BooleanSetting(
      "AttackMultiTask", "Multitask", "Allows attacking while an item is already in use.", new BooleanSetting.Visibility(this.attack, true), true
   );
   public BooleanSetting attackSwing = new BooleanSetting(
      "AttackSwing", "Swing", "Sends a swing packet whenever attacking a crystal.", new BooleanSetting.Visibility(this.attack, true), true
   );
   public BooleanSetting holeCheck = new BooleanSetting("HoleCheck", "Checks if the target is in a hole or not before placing.", true);
   public BooleanSetting antiStep = new BooleanSetting("AntiStep", "Adds additional blocks that prevent the player from stepping out of the hole.", false);
   public BooleanSetting whileEating = new BooleanSetting("WhileEating", "Places blocks normally while eating.", true);
   public BooleanSetting ignoreNaked = new BooleanSetting("IgnoreNaked", "Ignore Naked, even that player wears elytra only", false);
   public BooleanSetting selfDisable = new BooleanSetting("SelfDisable", "Toggles off the module once it is finished with placing.", false);
   public BooleanSetting itemDisable = new BooleanSetting("ItemDisable", "Toggles off the module whenever you run out of items to place with.", true);
   public BooleanSetting render = new BooleanSetting("Render", "Whether or not to render the place position.", true);
   private List<BlockPos> positions = new ArrayList<>();
   private int blocksPlaced = 0;
   private boolean feetTrappedOnce = false;

   @Override
   public void onEnable() {
      if (mc.player == null || mc.level == null) {
         this.setToggled(false);
      }

      this.feetTrappedOnce = false;
   }

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (this.whileEating.getValue() || !EntityUtils.isEating()) {
         List players = mc.level.players();
         Runnable runnable = () -> {
            this.blocksPlaced = 0;
            if (this.autoSwitch.getValue().equalsIgnoreCase("None") && !(mc.player.getMainHandItem().getItem() instanceof BlockItem)) {
               if (this.itemDisable.getValue()) {
                  Night.CHAT_MANAGER.tagged("You are currently not holding any blocks.", this.getName());
                  this.setToggled(false);
               }

               this.positions = new ArrayList<>();
            } else {
               int slot = InventoryUtils.findHardestBlock(
                  0, !this.autoSwitch.getValue().equalsIgnoreCase("AltSwap") && !this.autoSwitch.getValue().equalsIgnoreCase("AltPickup") ? 8 : 35
               );
               int previousSlot = mc.player.getInventory().getSelectedSlot();
               if (slot == -1) {
                  if (this.itemDisable.getValue()) {
                     Night.CHAT_MANAGER.tagged("No blocks could be found in your hotbar.", this.getName());
                     this.setToggled(false);
                  }

                  this.positions = new ArrayList<>();
               } else {
                  AutoTrapModule.Target target = this.getTarget(players);
                  if (target == null) {
                     if (this.selfDisable.getValue()) {
                        this.setToggled(false);
                     }

                     this.positions = new ArrayList<>();
                  } else {
                     this.positions = target.positions();
                     if (this.attack.getValue()) {
                        this.attackTrapCrystals();
                     }

                     int feetY = target.player().getBlockY();
                     Night.ROTATION_MANAGER.beginBatchRotation();

                     try {
                        InventoryUtils.switchSlot(this.autoSwitch.getValue(), slot, previousSlot);
                        AutoCrystalModule autoCrystal = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(AutoCrystalModule.class) : null;
                        int headY = Mth.floor(target.player().getY()) + 2;
                        ArrayList<BlockPos> placedPositions = new ArrayList<>();

                        for (BlockPos position : this.positions) {
                           if (this.blocksPlaced >= this.bpt.getValue().intValue()) {
                              break;
                           }

                           if (position.getY() != headY || autoCrystal == null || !autoCrystal.isToggled() || !autoCrystal.hasLiveCrystalNear(position.above())
                              )
                            {
                              if (this.attack.getValue()) {
                                 for (EndCrystal crystal : mc.level.getEntitiesOfClass(EndCrystal.class, new AABB(position).inflate(0.5))) {
                                    if (crystal.isAlive()) {
                                       mc.getConnection().send(new ServerboundAttackPacket(crystal.getId()));
                                       if (this.attackSwing.getValue()) {
                                          mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
                                       }
                                    }
                                 }
                              }

                              Direction direction;
                              if ((direction = WorldUtils.getDirection(position, placedPositions, this.strictDirection.getValue())) == null) {
                                 if (this.airPlace.getValue()) {
                                    WorldUtils.airPlaceBlock(position, InteractionHand.MAIN_HAND, this.rotate.getValue(), this.render.getValue());
                                    placedPositions.add(position);
                                    this.blocksPlaced++;
                                    if (position.getY() == feetY) {
                                       this.feetTrappedOnce = true;
                                    }
                                 } else {
                                    BlockPos support = WorldUtils.findSupportBlock(position, placedPositions, this.strictDirection.getValue(), 2);
                                    Direction supportDir;
                                    if (support != null
                                       && (supportDir = WorldUtils.getDirection(support, placedPositions, this.strictDirection.getValue())) != null
                                       && WorldUtils.placeBlock(
                                          support, supportDir, InteractionHand.MAIN_HAND, this.rotate.getValue(), true, this.render.getValue()
                                       )) {
                                       placedPositions.add(support);
                                       this.blocksPlaced++;
                                    }
                                 }
                              } else {
                                 WorldUtils.placeBlock(position, direction, InteractionHand.MAIN_HAND, this.rotate.getValue(), true, this.render.getValue());
                                 placedPositions.add(position);
                                 this.blocksPlaced++;
                                 if (position.getY() == feetY) {
                                    this.feetTrappedOnce = true;
                                 }
                              }
                           }
                        }

                        InventoryUtils.switchBack(this.autoSwitch.getValue(), slot, previousSlot);
                     } finally {
                        Night.ROTATION_MANAGER.endBatchRotation();
                     }
                  }
               }
            }
         };
         if (this.asynchronous.getValue()) {
            ThreadExecutor.execute(runnable);
         } else {
            runnable.run();
         }
      }
   }

   @SubscribeEvent
   public void onPacketReceive(PacketReceiveEvent event) {
      if (mc.player != null && mc.level != null) {
         ClientboundAddEntityPacket addPacket;
         Packet<?> packet;
         if (this.attack.getValue()
            && (packet = event.getPacket()) instanceof ClientboundAddEntityPacket
            && (addPacket = (ClientboundAddEntityPacket)packet).getType() == EntityTypes.END_CRYSTAL) {
            Vec3 crystalPos = new Vec3(addPacket.getX(), addPacket.getY(), addPacket.getZ());
            AABB crystalBox = new AABB(crystalPos.x - 1.0, crystalPos.y, crystalPos.z - 1.0, crystalPos.x + 1.0, crystalPos.y + 2.0, crystalPos.z + 1.0);
            boolean nearTrap = false;

            for (BlockPos pos : this.positions) {
               if (crystalBox.intersects(new AABB(pos)) || crystalPos.distanceToSqr(Vec3.atCenterOf(pos)) <= 4.0) {
                  nearTrap = true;
                  break;
               }
            }

            if (nearTrap
               && mc.player.getEyePosition().distanceToSqr(crystalPos) <= Mth.square(this.attackRange.getValue().doubleValue())
               && (this.attackMultiTask.getValue() || !mc.player.isUsingItem())) {
               mc.getConnection().send(new ServerboundAttackPacket(addPacket.getId()));
               if (this.attackSwing.getValue()) {
                  mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
               }
            }
         }
      }
   }

   private void attackTrapCrystals() {
      Night.ROTATION_MANAGER.beginBatchRotation();

      for (EndCrystal crystal : mc.level
         .getEntitiesOfClass(EndCrystal.class, new AABB(mc.player.blockPosition()).inflate(this.attackRange.getValue().doubleValue() + 3.0))) {
         if (crystal.isAlive() && !crystal.isRemoved() && crystal.tickCount >= this.attackAge.getValue().intValue()) {
            AABB crystalBox = crystal.getBoundingBox();
            boolean threatens = false;

            for (BlockPos pos : this.positions) {
               if (mc.level.getBlockState(pos).canBeReplaced() && new AABB(pos).intersects(crystalBox)) {
                  threatens = true;
                  break;
               }
            }

            if (threatens
               && !(
                  crystalBox.distanceToSqr(mc.player.getEyePosition()) > this.attackRange.getValue().doubleValue() * this.attackRange.getValue().doubleValue()
               )
               && (this.attackMultiTask.getValue() || !mc.player.isUsingItem())) {
               if (this.attackRotate.getValue()) {
                  float[] rotations = RotationUtils.getRotations(crystal.getBoundingBox().getCenter());
                  Night.ROTATION_MANAGER.silentRotate(rotations[0], rotations[1]);
                  boolean insideBox = crystalBox.contains(mc.player.getEyePosition());
                  if (!insideBox && !WorldUtils.canSee(crystal.getBoundingBox().getCenter())) {
                     continue;
                  }
               }

               mc.getConnection().send(new ServerboundAttackPacket(crystal.getId()));
               if (this.attackSwing.getValue()) {
                  mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
               }
            }
         }
      }

      Night.ROTATION_MANAGER.endBatchRotation();
   }

   @Override
   public void onDisable() {
      this.positions = new ArrayList<>();
   }

   @Override
   public String getMetaData() {
      return String.valueOf(this.positions.size());
   }

   private AutoTrapModule.Target getTarget(List<AbstractClientPlayer> players) {
      AutoTrapModule.Target optimalTarget = null;
      LogoutSpotModule logoutSpot = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(LogoutSpotModule.class) : null;
      PopChamsModule popChams = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(PopChamsModule.class) : null;
      ArrayList<AbstractClientPlayer> allCandidates = new ArrayList<>(players);
      if (logoutSpot != null && logoutSpot.isToggled()) {
         for (Player player : logoutSpot.getGhosts()) {
            if (player != null && !allCandidates.contains(player)) {
               allCandidates.add((AbstractClientPlayer)player);
            }
         }
      }

      for (Player playerx : allCandidates) {
         LogoutSpotModule.Spot spot;
         boolean ghost;
         if (playerx != mc.player
            && (popChams == null || !popChams.isGhost(playerx))
            && ((ghost = EntityUtils.isGhost(playerx)) || playerx.isAlive() && !(playerx.getHealth() <= 0.0F))
            && !(mc.player.distanceToSqr(playerx) > Mth.square(this.enemyRange.getValue().doubleValue()))
            && (!this.ignoreNaked.getValue() || !EntityUtils.isNaked(playerx))
            && (
               logoutSpot != null && logoutSpot.isGhost(playerx)
                  ? (spot = logoutSpot.getSpot((RemotePlayer)playerx)) == null || !Night.FRIEND_MANAGER.contains(spot.data.name)
                  : !Night.FRIEND_MANAGER.contains(playerx.getName().getString())
            )
            && (!this.holeCheck.getValue() || HoleUtils.isPlayerInHole(playerx))) {
            boolean feet = !this.noFeet.getValue() && (!this.disableAfterFeet.getValue() || !this.feetTrappedOnce);
            List<BlockPos> positions = HoleUtils.getTrapPositions(
                  playerx,
                  this.mode.getValue().equalsIgnoreCase("Partial"),
                  this.head.getValue(),
                  this.antiStep.getValue(),
                  false,
                  this.strictDirection.getValue(),
                  feet,
                  this.airPlace.getValue()
               )
               .stream()
               .filter(position -> mc.player.distanceToSqr(Vec3.atCenterOf(position)) <= Mth.square(this.range.getValue().doubleValue()))
               .filter(WorldUtils::isPlaceable)
               .toList();
            if (!positions.isEmpty()) {
               if (optimalTarget == null) {
                  optimalTarget = new AutoTrapModule.Target(playerx, positions);
               } else {
                  boolean bestIsGhost = EntityUtils.isGhost(optimalTarget.player());
                  if (bestIsGhost != ghost) {
                     if (bestIsGhost) {
                        optimalTarget = new AutoTrapModule.Target(playerx, positions);
                     }
                  } else if (mc.player.distanceToSqr(playerx) < mc.player.distanceToSqr(optimalTarget.player())) {
                     optimalTarget = new AutoTrapModule.Target(playerx, positions);
                  }
               }
            }
         }
      }

      return optimalTarget;
   }

   private record Target(Player player, List<BlockPos> positions) {
   }
}
