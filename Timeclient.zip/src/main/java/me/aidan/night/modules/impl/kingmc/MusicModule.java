package night.modules.impl.kingmc;

import java.awt.Color;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.AudioFormat.Encoding;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.RenderOverlayEvent;
import night.events.impl.TickEvent;
import night.events.impl.UnfilteredMouseInputEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.settings.impl.StringSetting;
import night.utils.graphics.Renderer2D;
import org.lwjgl.glfw.GLFW;

@RegisterModule(
   name = "Music",
   description = "Plays mp3/wav files from the xnhau/Music folder and shows a card with the logo and song name while playing.",
   category = Module.Category.KINGMC
)
public class MusicModule extends Module {
   private static final File DIR = new File("xnhau/Music");
   private static final String NONE = "None";
   public ModeSetting source = new ModeSetting(
      "Source", "Local = files in xnhau/Music, Link = YouTube (or other) link.", "Local", new String[]{"Local", "Link"}
   );
   public StringSetting link = new StringSetting("Link", "Paste the link here (Ctrl+V). If empty, the link in your clipboard is used.", "");
   public ModeSetting track = new ModeSetting("Track", "The song to play (files in xnhau/Music).", firstTrack(), scan());
   public NumberSetting volume = new NumberSetting("Volume", "Playback volume.", 50, 0, 100);
   public BooleanSetting loop = new BooleanSetting("Loop", "Repeats the song. When off, the module turns itself off at the end.", false);
   public NumberSetting maxLength = new NumberSetting("MaxLength", "Maximum characters of the song name on the card.", 22, 8, 60);
   public BooleanSetting clean = new BooleanSetting("CleanName", "Removes (...), [...], hashtags and text after | from song names.", true);
   public BooleanSetting pauseBtn = new BooleanSetting("Pause", "Button: pause / resume the song.", false);
   public BooleanSetting backBtn = new BooleanSetting("Rewind", "Button: go back by SeekSeconds.", false);
   public BooleanSetting fwdBtn = new BooleanSetting("Forward", "Button: skip ahead by SeekSeconds.", false);
   public NumberSetting seekSeconds = new NumberSetting("SeekSeconds", "How many seconds Rewind / Forward jump.", 10, 3, 60);
   public BooleanSetting spinner = new BooleanSetting("Card", "Shows the now playing card (logo + song name) while music is playing.", true);
   public NumberSetting offsetX = new NumberSetting("OffsetX", "Moves the card left (-) or right (+) from the screen center.", 0, -400, 400);
   public NumberSetting offsetY = new NumberSetting("OffsetY", "Distance of the card from the bottom of the screen.", 64, 0, 400);
   public NumberSetting size = new NumberSetting("Size", "Disc size (card height follows).", 32, 12, 48);
   public ColorSetting color = new ColorSetting(
      "Color", "Accent color of the card (border, progress bar, button hover).", new ColorSetting.Color(new Color(170, 120, 255), false, false)
   );
   private volatile int generation = 0;
   private volatile boolean playing = false;
   private volatile boolean ended = false;
   private volatile boolean loading = false;
   private volatile Process process = null;
   private volatile String status = "";
   private boolean linkMode = false;
   private String lastSel = "";
   private volatile String currentName = "";
   private volatile boolean paused = false;
   private final AtomicLong seekDelta = new AtomicLong();
   private volatile long posMs = 0L;
   private volatile long totalMs = 0L;
   private volatile File currentFile = null;
   private static final Map<String, File> FILES = new LinkedHashMap<>();
   private static final File TOOLS = new File(DIR, "tools");
   private static final File DOWNLOADS = new File(DIR, "downloads");
   private static final boolean WINDOWS = System.getProperty("os.name", "").toLowerCase().contains("win");
   private static final boolean MAC = System.getProperty("os.name", "").toLowerCase().contains("mac");
   private static final Identifier[] DISC = new Identifier[48];
   private float spinDeg = 0.0F;
   private long lastSpinMs = 0L;
   private static final Identifier LOGO;
   private volatile boolean cardVisible = false;
   private volatile int zoneY;
   private volatile int zoneH;
   private volatile int zoneW;
   private volatile int rwX;
   private volatile int ppX;
   private volatile int fwX;
   private volatile int barX;
   private volatile int barY;
   private volatile int barW;

   private static boolean isAudio(File var0) {
      String var1 = var0.getName().toLowerCase();
      return var0.isFile() && (var1.endsWith(".mp3") || var1.endsWith(".wav") || var1.endsWith(".aiff") || var1.endsWith(".au"));
   }

   private static String ascii(String var0) {
      return Normalizer.normalize(var0, Form.NFD)
         .replaceAll("\\p{M}+", "")
         .replace('đ', 'd')
         .replace('Đ', 'D')
         .replaceAll("[^\\x20-\\x7E]", "")
         .replaceAll("\\s+", " ")
         .trim();
   }

   private static String plainFull(String var0) {
      return ascii(var0);
   }

   private static String unJson(String var0) {
      if (var0.length() >= 2 && var0.startsWith("\"") && var0.endsWith("\"")) {
         var0 = var0.substring(1, var0.length() - 1);
      }

      StringBuilder var1 = new StringBuilder();

      for (int var2 = 0; var2 < var0.length(); var2++) {
         char var3 = var0.charAt(var2);
         if (var3 == '\\' && var2 + 1 < var0.length()) {
            char var4 = var0.charAt(++var2);
            switch (var4) {
               case 'n':
               case 'r':
               case 't':
                  var1.append(' ');
                  break;
               case 'o':
               case 'p':
               case 'q':
               case 's':
               default:
                  var1.append(var4);
                  break;
               case 'u':
                  if (var2 + 4 < var0.length()) {
                     try {
                        var1.append((char)Integer.parseInt(var0.substring(var2 + 1, var2 + 5), 16));
                        var2 += 4;
                     } catch (NumberFormatException var6) {
                        var1.append('u');
                     }
                  }
            }
         } else {
            var1.append(var3);
         }
      }

      return var1.toString();
   }

   private static String plain(String var0) {
      String var1 = ascii(var0);
      if (var1.length() > 42) {
         var1 = var1.substring(0, 42).trim() + "...";
      }

      return var1;
   }

   private static String cleanName(String var0) {
      String var1 = var0.replaceAll("\\([^)]*\\)|\\[[^\\]]*\\]", " ").replaceAll("#\\S+", " ").replaceAll("\\|.*$", " ").replaceAll("\\s+", " ").trim();
      var1 = var1.replaceAll("[\\s\\-]+$", "").trim();
      return var1.isEmpty() ? var0 : var1;
   }

   private String displayName() {
      String var1 = ascii(stripExt(this.currentName));
      if (this.clean.getValue()) {
         var1 = cleanName(var1);
      }

      if (var1.isEmpty()) {
         var1 = "Music";
      }

      int var2 = Math.max(8, this.maxLength.getValue().intValue());
      if (var1.length() > var2) {
         var1 = var1.substring(0, var2 - 3).trim() + "...";
      }

      return var1;
   }

   private static void saveCustomTitle(File var0, String var1) {
      try {
         String var2 = stripExt(var0.getName());
         File var3 = new File(DOWNLOADS, "titles.txt");
         ArrayList var4 = new ArrayList();
         boolean var5 = false;
         if (var3.isFile()) {
            for (String var7 : Files.readAllLines(var3.toPath(), StandardCharsets.UTF_8)) {
               if (var7.startsWith(var2 + "\t")) {
                  var4.add(var2 + "\t" + var1);
                  var5 = true;
               } else {
                  var4.add(var7);
               }
            }
         }

         if (!var5) {
            var4.add(var2 + "\t" + var1);
         }

         Files.write(var3.toPath(), var4, StandardCharsets.UTF_8);
      } catch (Throwable var8) {
      }
   }

   private static Map<String, String> readTitles() {
      HashMap var0 = new HashMap();

      try {
         File var1 = new File(DOWNLOADS, "titles.txt");
         if (var1.isFile()) {
            for (String var3 : Files.readAllLines(var1.toPath(), StandardCharsets.UTF_8)) {
               int var4 = var3.indexOf(9);
               if (var4 > 0) {
                  var0.put(var3.substring(0, var4), var3.substring(var4 + 1));
               }
            }
         }
      } catch (Throwable var5) {
      }

      return var0;
   }

   private static void saveTitle(File var0, String var1) {
      try {
         String var2 = stripExt(var0.getName());
         Map var3 = readTitles();
         var3.put(var2, var1.replace('\t', ' ').replace('\n', ' '));
         StringBuilder var4 = new StringBuilder();

         for (Entry var6 : var3.entrySet()) {
            var4.append((String)var6.getKey()).append('\t').append((String)var6.getValue()).append('\n');
         }

         Files.writeString(new File(DOWNLOADS, "titles.txt").toPath(), var4.toString(), StandardCharsets.UTF_8);
      } catch (Throwable var7) {
      }
   }

   private static void put(String var0, File var1) {
      String var2 = var0;
      int var3 = 2;

      while (FILES.containsKey(var2)) {
         var2 = var0 + " (" + var3++ + ")";
      }

      FILES.put(var2, var1);
   }

   private static String[] scan() {
      FILES.clear();

      try {
         DIR.mkdirs();
         File[] var0 = DIR.listFiles();
         if (var0 != null) {
            Arrays.sort(var0);

            for (File var4 : var0) {
               if (isAudio(var4)) {
                  put(var4.getName(), var4);
               }
            }
         }

         File[] var10 = DOWNLOADS.listFiles();
         if (var10 != null) {
            Arrays.sort(var10, (var0x, var1) -> Long.compare(var1.lastModified(), var0x.lastModified()));
            Map var11 = readTitles();

            for (File var6 : var10) {
               if (isAudio(var6)) {
                  String var7 = stripExt(var6.getName());
                  String var8 = var11.containsKey(var7) ? plain((String)var11.get(var7)) : "";
                  put(var8.isEmpty() ? var7 : var8, var6);
               }
            }
         }
      } catch (Throwable var9) {
      }

      return FILES.isEmpty() ? new String[]{"None"} : FILES.keySet().toArray(new String[0]);
   }

   private static String firstTrack() {
      return scan()[0];
   }

   private void refreshTracks() {
      try {
         String[] var1 = scan();
         String var2 = this.track.getValue();
         Field var3 = ModeSetting.class.getDeclaredField("modes");
         var3.setAccessible(true);
         var3.set(this.track, new ArrayList<>(Arrays.asList(var1)));
         this.track.setValue(Arrays.asList(var1).contains(var2) ? var2 : var1[0]);
      } catch (Throwable var4) {
         Night.LOGGER.error("Music: could not refresh the track list", var4);
      }
   }

   @Override
   public void onEnable() {
      this.refreshTracks();
      this.lastSel = this.track.getValue();
      this.ended = false;
      this.pauseBtn.setValue(false);
      this.backBtn.setValue(false);
      this.fwdBtn.setValue(false);
      this.linkMode = "Link".equals(this.source.getValue());
      boolean var1 = this.linkMode ? this.startLink() : this.startSelected();
      if (!var1) {
         this.ended = true;
      }
   }

   @Override
   public void onDisable() {
      this.generation++;
      this.playing = false;
      this.loading = false;
      this.ended = false;
      this.paused = false;
      this.seekDelta.set(0L);
      this.killProcess();
   }

   @Override
   public String getMetaData() {
      return this.playing ? stripExt(this.currentName) : "";
   }

   private static String stripExt(String var0) {
      int var1 = var0.lastIndexOf(46);
      return var1 > 0 ? var0.substring(0, var1) : var0;
   }

   private void killProcess() {
      Process var1 = this.process;
      this.process = null;
      if (var1 != null) {
         var1.destroyForcibly();
      }
   }

   private void msg(String var1, boolean var2) {
      mc.execute(() -> {
         if (var2) {
            Night.CHAT_MANAGER.error(var1);
         } else {
            Night.CHAT_MANAGER.info(var1);
         }
      });
   }

   private boolean startSelected() {
      String var1 = this.track.getValue();
      File var2 = FILES.get(var1);
      if (!"None".equals(var1) && var2 != null && var2.isFile()) {
         int var3 = ++this.generation;
         this.currentName = var1;
         this.currentFile = var2;
         this.paused = false;
         this.pauseBtn.setValue(false);
         this.seekDelta.set(0L);
         this.posMs = 0L;
         this.totalMs = 0L;
         Thread var4 = new Thread(() -> this.runPlayer(var2, var3), "Music-Player");
         var4.setDaemon(true);
         var4.start();
         return true;
      } else {
         Night.CHAT_MANAGER.error("No music found. Put .mp3 or .wav files in the 'xnhau/Music' folder.");
         return false;
      }
   }

   private String readLink() {
      String var1 = this.link.getValue() == null ? "" : this.link.getValue().trim();
      if (var1.isEmpty()) {
         try {
            String var2 = mc.keyboardHandler.getClipboard();
            if (var2 != null) {
               var1 = var2.trim();
            }
         } catch (Throwable var3) {
         }
      }

      return var1;
   }

   private boolean startLink() {
      String var1 = this.readLink();
      if (!var1.matches("(?i)^https?://\\S+$")) {
         Night.CHAT_MANAGER.error("Copy a link first (http/https), then turn Music on. You can also paste it into the Link setting.");
         return false;
      } else if (MAC) {
         Night.CHAT_MANAGER.error("Link mode supports Windows and Linux only. Use Local mode.");
         return false;
      } else {
         int var2 = ++this.generation;
         this.loading = true;
         this.paused = false;
         this.pauseBtn.setValue(false);
         this.seekDelta.set(0L);
         this.posMs = 0L;
         this.totalMs = 0L;
         this.currentName = "Loading...";
         Thread var3 = new Thread(() -> {
            try {
               File var3x = this.ensureYtDlp(var2);
               File var4 = this.ensureFfmpeg(var2);
               if (this.cancelled(var2) || var3x == null || var4 == null) {
                  if (!this.cancelled(var2)) {
                     this.loading = false;
                     this.ended = true;
                  }

                  return;
               }

               this.msg("Music: downloading audio...", false);
               File var5 = this.download(var1, var3x, var4, var2);
               if (this.cancelled(var2)) {
                  return;
               }

               if (var5 == null) {
                  this.loading = false;
                  this.ended = true;
                  return;
               }

               this.loading = false;
               this.runPlayer(var5, var2);
            } catch (Throwable var6) {
               Night.LOGGER.error("Music link failed", var6);
               if (!this.cancelled(var2)) {
                  this.msg("Music: failed - " + var6.getMessage(), true);
                  this.loading = false;
                  this.ended = true;
               }
            }
         }, "Music-Link");
         var3.setDaemon(true);
         var3.start();
         return true;
      }
   }

   private File ensureYtDlp(int var1) throws Exception {
      String var2 = WINDOWS ? "yt-dlp.exe" : "yt-dlp_linux";
      File var3 = new File(TOOLS, var2);
      if (var3.isFile() && var3.length() > 1000000L) {
         return var3;
      } else {
         TOOLS.mkdirs();
         this.msg("Music: downloading yt-dlp (first time only)...", false);

         try (
            OutputStream var4 = Files.newOutputStream(new File(TOOLS, var2 + ".part").toPath());
            InputStream var5 = open("https://github.com/yt-dlp/yt-dlp/releases/latest/download/" + var2);
         ) {
            this.copy(var5, var4, var1);
         }

         if (this.cancelled(var1)) {
            return null;
         } else {
            File var12 = new File(TOOLS, var2 + ".part");
            Files.move(var12.toPath(), var3.toPath(), StandardCopyOption.REPLACE_EXISTING);
            var3.setExecutable(true);
            return var3;
         }
      }
   }

   private File ensureFfmpeg(int var1) throws Exception {
      String var2 = WINDOWS ? "ffmpeg.exe" : "ffmpeg";
      File var3 = new File(TOOLS, var2);
      if (var3.isFile() && var3.length() > 1000000L) {
         return var3;
      } else {
         TOOLS.mkdirs();
         this.msg("Music: downloading ffmpeg (first time only, ~100MB, please wait)...", false);
         File var4 = new File(TOOLS, var2 + ".part");
         if (WINDOWS) {
            ZipInputStream var20 = new ZipInputStream(open("https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"));

            Object var22;
            label141: {
               try {
                  boolean var23 = false;

                  ZipEntry var8;
                  while ((var8 = var20.getNextEntry()) != null) {
                     if (this.cancelled(var1)) {
                        var22 = null;
                        break label141;
                     }

                     if (!var8.isDirectory() && var8.getName().endsWith("/bin/ffmpeg.exe")) {
                        try (OutputStream var9 = Files.newOutputStream(var4.toPath())) {
                           this.copy(var20, var9, var1);
                        }

                        var23 = true;
                        break;
                     }
                  }

                  if (!var23) {
                     throw new IllegalStateException("ffmpeg.exe not found in the download");
                  }
               } catch (Throwable var18) {
                  try {
                     var20.close();
                  } catch (Throwable var14) {
                     var18.addSuppressed(var14);
                  }

                  throw var18;
               }

               var20.close();
               if (this.cancelled(var1)) {
                  return null;
               }

               Files.move(var4.toPath(), var3.toPath(), StandardCopyOption.REPLACE_EXISTING);
               var3.setExecutable(true);
               return var3;
            }

            var20.close();
            return (File)var22;
         } else {
            File var5 = new File(TOOLS, "ffmpeg.tar.xz");

            try (
               OutputStream var6 = Files.newOutputStream(var5.toPath());
               InputStream var7 = open("https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-linux64-gpl.tar.xz");
            ) {
               this.copy(var7, var6, var1);
            }

            if (this.cancelled(var1)) {
               return null;
            } else {
               Process var21 = new ProcessBuilder(
                     "tar", "-xJf", var5.getAbsolutePath(), "-C", TOOLS.getAbsolutePath(), "--strip-components=2", "--wildcards", "*/bin/ffmpeg"
                  )
                  .redirectErrorStream(true)
                  .start();
               var21.getInputStream().readAllBytes();
               var21.waitFor();
               var5.delete();
               if (!var3.isFile()) {
                  throw new IllegalStateException("could not extract ffmpeg (is 'tar' with xz installed?)");
               } else {
                  var3.setExecutable(true);
                  return var3;
               }
            }
         }
      }
   }

   private static InputStream open(String var0) throws Exception {
      HttpURLConnection var1 = (HttpURLConnection)new URL(var0).openConnection();
      var1.setInstanceFollowRedirects(true);
      var1.setRequestProperty("User-Agent", "xnhau-music");
      var1.setConnectTimeout(15000);
      var1.setReadTimeout(30000);
      int var2 = var1.getResponseCode();
      if (var2 / 100 != 2) {
         throw new IllegalStateException("HTTP " + var2 + " for " + var0);
      } else {
         return var1.getInputStream();
      }
   }

   private void copy(InputStream var1, OutputStream var2, int var3) throws Exception {
      byte[] var4 = new byte[65536];

      int var5;
      while (!this.cancelled(var3) && (var5 = var1.read(var4)) > 0) {
         var2.write(var4, 0, var5);
      }
   }

   private File download(String var1, File var2, File var3, int var4) throws Exception {
      DOWNLOADS.mkdirs();
      ArrayList var5 = new ArrayList<>(
         Arrays.asList(
            var2.getAbsolutePath(),
            "--no-playlist",
            "--no-warnings",
            "--no-simulate",
            "--socket-timeout",
            "20",
            "-x",
            "--audio-format",
            "mp3",
            "--ffmpeg-location",
            var3.getAbsolutePath(),
            "-o",
            new File(DOWNLOADS, "%(id)s.%(ext)s").getAbsolutePath(),
            "--print",
            "before_dl:TITLE:%(title)j",
            "--print",
            "before_dl:ID:%(id)s",
            "--",
            var1
         )
      );
      String var6 = null;
      String var7 = null;
      int var8 = -1;
      StringBuilder var9 = new StringBuilder();

      for (int var10 = 0; var10 < 2; var10++) {
         var6 = null;
         var7 = null;
         var9.setLength(0);
         ProcessBuilder var11 = new ProcessBuilder(var5).redirectErrorStream(true);
         var11.environment().put("PYTHONUTF8", "1");
         var11.environment().put("PYTHONIOENCODING", "utf-8");
         Process var12 = var11.start();
         this.process = var12;
         BufferedReader var13 = new BufferedReader(new InputStreamReader(var12.getInputStream(), StandardCharsets.UTF_8));

         String var14;
         try {
            while ((var14 = var13.readLine()) != null) {
               if (var14.startsWith("TITLE:")) {
                  var6 = unJson(var14.substring(6).trim());
               } else if (var14.startsWith("ID:")) {
                  var7 = new File(DOWNLOADS, var14.substring(3).trim() + ".mp3").getAbsolutePath();
               } else {
                  var9.append(var14).append('\n');
                  if (var9.length() > 600) {
                     var9.delete(0, var9.length() - 600);
                  }
               }
            }
         } catch (Throwable var19) {
            try {
               var13.close();
            } catch (Throwable var17) {
               var19.addSuppressed(var17);
            }

            throw var19;
         }

         var13.close();
         var8 = var12.waitFor();
         this.process = null;
         if (this.cancelled(var4)) {
            return null;
         }

         boolean var15 = var8 == 0 && var7 != null && new File(var7).isFile();
         if (var15 || var10 == 1) {
            break;
         }

         this.msg("Music: download failed, updating yt-dlp and retrying...", false);

         try {
            Process var16 = new ProcessBuilder(var2.getAbsolutePath(), "-U").redirectErrorStream(true).start();
            this.process = var16;
            var16.getInputStream().readAllBytes();
            var16.waitFor(120L, TimeUnit.SECONDS);
            this.process = null;
         } catch (Throwable var18) {
         }

         if (this.cancelled(var4)) {
            return null;
         }
      }

      File var20 = var7 == null ? null : new File(var7);
      if (var8 == 0 && var20 != null && var20.isFile()) {
         String var22 = var6 != null && !var6.isEmpty() ? var6 : stripExt(var20.getName());
         saveTitle(var20, var22);
         this.currentName = plainFull(var22).isEmpty() ? var20.getName() : plainFull(var22);
         mc.execute(() -> {
            this.refreshTracks();

            for (Entry var3x : FILES.entrySet()) {
               if (((File)var3x.getValue()).equals(var20)) {
                  this.track.setValue((String)var3x.getKey());
                  break;
               }
            }

            this.lastSel = this.track.getValue();
         });
         return var20;
      } else {
         String var21 = var9.toString().trim();
         if (var21.isEmpty()) {
            var21 = "yt-dlp exit code " + var8;
         }

         int var23 = var21.lastIndexOf(10);
         this.msg("Music: download failed - " + (var23 >= 0 ? var21.substring(var23 + 1) : var21), true);
         return null;
      }
   }

   private boolean cancelled(int var1) {
      return var1 != this.generation;
   }

   private void runPlayer(File var1, int var2) {
      this.playing = true;

      try {
         do {
            if (var1.getName().toLowerCase().endsWith(".mp3")) {
               this.playMp3(var1, var2);
            } else {
               this.playAudio(var1, var2);
            }
         } while (this.loop.getValue() && !this.cancelled(var2));
      } catch (Throwable var7) {
         Night.LOGGER.error("Music playback failed", var7);
      } finally {
         if (!this.cancelled(var2)) {
            this.playing = false;
            this.ended = true;
         }
      }
   }

   private float gain() {
      return Math.max(0.0F, Math.min(1.0F, this.volume.getValue().floatValue() / 100.0F));
   }

   private static void closeLine(SourceDataLine var0, boolean var1) {
      if (var0 != null) {
         try {
            if (var1) {
               var0.drain();
            } else {
               var0.flush();
            }
         } catch (Throwable var4) {
         }

         try {
            var0.stop();
            var0.close();
         } catch (Throwable var3) {
         }
      }
   }

   private void playMp3(File var1, int var2) throws Exception {
      SourceDataLine var3 = null;
      BufferedInputStream var4 = null;
      Bitstream var5 = null;

      try {
         var4 = new BufferedInputStream(new FileInputStream(var1));
         var5 = new Bitstream(var4);
         Decoder var6 = new Decoder();
         this.posMs = 0L;
         this.totalMs = 0L;
         boolean var7 = false;

         while (!this.cancelled(var2)) {
            long var8 = this.seekDelta.getAndSet(0L);
            if (var8 != 0L) {
               long var36 = Math.max(0L, this.posMs + var8);
               if (var36 < this.posMs) {
                  try {
                     var5.close();
                  } catch (Throwable var33) {
                  }

                  try {
                     var4.close();
                  } catch (Throwable var32) {
                  }

                  var4 = new BufferedInputStream(new FileInputStream(var1));
                  var5 = new Bitstream(var4);
                  var6 = new Decoder();
                  this.posMs = 0L;
               }

               while (true) {
                  if (this.posMs < var36 && !this.cancelled(var2)) {
                     Header var38 = var5.readFrame();
                     if (var38 != null) {
                        try {
                           var6.decodeFrame(var38, var5);
                        } catch (Throwable var31) {
                        }

                        this.posMs = this.posMs + (long)var38.ms_per_frame();
                        var5.closeFrame();
                        continue;
                     }
                  }

                  if (var3 != null) {
                     var3.flush();
                  }
                  break;
               }
            } else if (this.paused) {
               if (var3 != null && !var7) {
                  var3.stop();
                  var7 = true;
               }

               Thread.sleep(30L);
            } else {
               if (var7 && var3 != null) {
                  var3.start();
                  var7 = false;
               }

               Header var10 = var5.readFrame();
               if (var10 == null) {
                  break;
               }

               if (this.totalMs == 0L) {
                  this.totalMs = (long)var10.total_ms((int)var1.length());
               }

               SampleBuffer var11;
               try {
                  var11 = (SampleBuffer)var6.decodeFrame(var10, var5);
               } catch (Throwable var34) {
                  var5.closeFrame();
                  continue;
               }

               if (var3 == null) {
                  AudioFormat var12 = new AudioFormat(var11.getSampleFrequency(), 16, var11.getChannelCount(), true, false);
                  var3 = AudioSystem.getSourceDataLine(var12);
                  var3.open(var12);
                  var3.start();
               }

               short[] var37 = var11.getBuffer();
               int var13 = var11.getBufferLength();
               byte[] var14 = new byte[var13 * 2];
               float var15 = this.gain();

               for (int var16 = 0; var16 < var13; var16++) {
                  int var17 = (int)(var37[var16] * var15);
                  if (var17 > 32767) {
                     var17 = 32767;
                  }

                  if (var17 < -32768) {
                     var17 = -32768;
                  }

                  var14[2 * var16] = (byte)var17;
                  var14[2 * var16 + 1] = (byte)(var17 >> 8);
               }

               var3.write(var14, 0, var14.length);
               this.posMs = this.posMs + (long)var10.ms_per_frame();
               var5.closeFrame();
            }
         }

         closeLine(var3, !this.cancelled(var2));
         var3 = null;
      } finally {
         closeLine(var3, false);

         try {
            if (var5 != null) {
               var5.close();
            }
         } catch (Throwable var30) {
         }

         try {
            if (var4 != null) {
               var4.close();
            }
         } catch (Throwable var29) {
         }
      }
   }

   private static AudioInputStream openPcm(File var0) throws Exception {
      AudioInputStream var1 = AudioSystem.getAudioInputStream(var0);
      AudioFormat var2 = var1.getFormat();
      AudioFormat var3 = new AudioFormat(Encoding.PCM_SIGNED, var2.getSampleRate(), 16, var2.getChannels(), var2.getChannels() * 2, var2.getSampleRate(), false);
      return AudioSystem.getAudioInputStream(var3, var1);
   }

   private void playAudio(File var1, int var2) throws Exception {
      SourceDataLine var3 = null;
      AudioInputStream var4 = null;

      try {
         var4 = openPcm(var1);
         AudioFormat var5 = var4.getFormat();
         double var6 = var5.getFrameSize() * var5.getFrameRate() / 1000.0;
         long var8 = var4.getFrameLength();
         this.totalMs = var8 > 0L ? (long)((float)var8 / var5.getFrameRate() * 1000.0) : 0L;
         this.posMs = 0L;
         long var10 = 0L;
         var3 = AudioSystem.getSourceDataLine(var5);
         var3.open(var5);
         var3.start();
         boolean var12 = false;
         byte[] var13 = new byte[4096];

         while (!this.cancelled(var2)) {
            long var14 = this.seekDelta.getAndSet(0L);
            if (var14 != 0L) {
               long var31 = Math.max(0L, this.posMs + var14);
               if (var31 < this.posMs) {
                  try {
                     var4.close();
                  } catch (Throwable var28) {
                  }

                  var4 = openPcm(var1);
                  var10 = 0L;
               }

               long var32 = (long)(var31 * var6);
               var32 -= var32 % var5.getFrameSize();

               while (true) {
                  if (var10 < var32 && !this.cancelled(var2)) {
                     int var20 = var4.read(var13, 0, (int)Math.min((long)var13.length, var32 - var10));
                     if (var20 > 0) {
                        var10 += var20;
                        continue;
                     }
                  }

                  this.posMs = (long)(var10 / var6);
                  var3.flush();
                  break;
               }
            } else if (this.paused) {
               if (!var12) {
                  var3.stop();
                  var12 = true;
               }

               Thread.sleep(30L);
            } else {
               if (var12) {
                  var3.start();
                  var12 = false;
               }

               int var16 = var4.read(var13, 0, var13.length);
               if (var16 <= 0) {
                  break;
               }

               float var17 = this.gain();
               var16 -= var16 % 2;

               for (byte var18 = 0; var18 + 1 < var16; var18 = (byte)(var18 + 2)) {
                  int var19 = (short)(var13[var18] & 255 | var13[var18 + 1] << 8);
                  var19 = (int)(var19 * var17);
                  var13[var18] = (byte)var19;
                  var13[var18 + 1] = (byte)(var19 >> 8);
               }

               var3.write(var13, 0, var16);
               var10 += var16;
               this.posMs = (long)(var10 / var6);
            }
         }

         closeLine(var3, !this.cancelled(var2));
         var3 = null;
      } finally {
         closeLine(var3, false);

         try {
            if (var4 != null) {
               var4.close();
            }
         } catch (Throwable var27) {
         }
      }
   }

   @SubscribeEvent
   public void onTick(TickEvent var1) {
      if (this.ended) {
         this.ended = false;
         this.setToggled(false);
      } else {
         if (this.pauseBtn.getValue() != this.paused) {
            this.paused = this.pauseBtn.getValue();
         }

         if (this.backBtn.getValue()) {
            this.backBtn.setValue(false);
            this.seekDelta.addAndGet(-this.seekSeconds.getValue().longValue() * 1000L);
         }

         if (this.fwdBtn.getValue()) {
            this.fwdBtn.setValue(false);
            this.seekDelta.addAndGet(this.seekSeconds.getValue().longValue() * 1000L);
         }

         String var2 = this.track.getValue();
         if (!var2.equals(this.lastSel)) {
            this.lastSel = var2;
            this.linkMode = false;
            this.loading = false;
            this.killProcess();
            if (!this.startSelected()) {
               this.ended = true;
            }
         }
      }
   }

   private static void tri(GuiGraphicsExtractor var0, float var1, float var2, int var3, int var4, boolean var5, Color var6) {
      for (int var7 = 0; var7 < var3; var7++) {
         float var8 = Math.abs(var7 + 0.5F - var3 / 2.0F) / (var3 / 2.0F);
         float var9 = Math.max(0.6F, (1.0F - var8) * var4);
         if (var5) {
            Renderer2D.renderQuad(var0, var1, var2 + var7, var1 + var9, var2 + var7 + 1.0F, var6);
         } else {
            Renderer2D.renderQuad(var0, var1 + var4 - var9, var2 + var7, var1 + var4, var2 + var7 + 1.0F, var6);
         }
      }
   }

   private double[] cursorGui() {
      try {
         long var1 = mc.getWindow().handle();
         if (GLFW.glfwGetInputMode(var1, 208897) == 212995) {
            return null;
         } else {
            double[] var3 = new double[1];
            double[] var4 = new double[1];
            GLFW.glfwGetCursorPos(var1, var3, var4);
            int[] var5 = new int[1];
            int[] var6 = new int[1];
            GLFW.glfwGetWindowSize(var1, var5, var6);
            return var5[0] > 0 && var6[0] > 0
               ? new double[]{var3[0] * mc.getWindow().getGuiScaledWidth() / var5[0], var4[0] * mc.getWindow().getGuiScaledHeight() / var6[0]}
               : null;
         }
      } catch (Throwable var7) {
         return null;
      }
   }

   private static boolean in(double var0, double var2, int var4, int var5, int var6, int var7) {
      return var0 >= var4 && var0 < var4 + var6 && var2 >= var5 && var2 < var5 + var7;
   }

   @SubscribeEvent
   public void onMouse(UnfilteredMouseInputEvent var1) {
      if (var1.getAction() == 1 && var1.getButton() == 0 && this.cardVisible && this.playing) {
         double[] var2 = this.cursorGui();
         if (var2 != null) {
            long var3 = this.seekSeconds.getValue().longValue() * 1000L;
            if (in(var2[0], var2[1], this.rwX, this.zoneY, this.zoneW, this.zoneH)) {
               this.seekDelta.addAndGet(-var3);
            } else if (in(var2[0], var2[1], this.ppX, this.zoneY, this.zoneW, this.zoneH)) {
               this.pauseBtn.setValue(!this.pauseBtn.getValue());
               this.paused = this.pauseBtn.getValue();
            } else if (in(var2[0], var2[1], this.fwX, this.zoneY, this.zoneW, this.zoneH)) {
               this.seekDelta.addAndGet(var3);
            } else if (this.totalMs > 0L && in(var2[0], var2[1], this.barX, this.barY - 4, this.barW, 10)) {
               double var5 = Math.max(0.0, Math.min(1.0, (var2[0] - this.barX) / this.barW));
               this.seekDelta.addAndGet((long)(var5 * this.totalMs) - this.posMs);
            }
         }
      }
   }

   @SubscribeEvent
   public void onRenderOverlay(RenderOverlayEvent var1) {
      if ((this.playing || this.loading) && this.spinner.getValue() && !this.getNull()) {
         GuiGraphicsExtractor var2 = var1.getContext();
         int var3 = this.size.getValue().intValue();
         byte var4 = 4;
         int var5 = var3 + var4 * 2 + 4 + 8;
         String var6 = this.playing ? this.displayName() : "Loading...";
         int var7 = Night.FONT_MANAGER.getWidth(var6);
         int var8 = Math.max(var7, 64);
         byte var9 = 8;
         byte var10 = 7;
         byte var11 = 7;
         int var12 = var4 + var3 + 8 + var8 + 10;
         int var13 = (mc.getWindow().getGuiScaledWidth() - var12) / 2 + this.offsetX.getValue().intValue();
         int var14 = mc.getWindow().getGuiScaledHeight() - var5 - this.offsetY.getValue().intValue();
         Color var15 = this.color.getColor();
         int var16 = var15.getRed();
         int var17 = var15.getGreen();
         int var18 = var15.getBlue();
         Color var19 = new Color(var16, var17, var18, 150);
         Color var20 = new Color(var16, var17, var18, 255);
         roundRect(var2, var13, var14, var12, var5, 7, var19);
         roundRect(var2, var13 + 1, var14 + 1, var12 - 2, var5 - 2, 6, new Color(16, 14, 24, 205));
         long var21 = System.currentTimeMillis();
         long var23 = Math.min(100L, Math.max(0L, var21 - this.lastSpinMs));
         this.lastSpinMs = var21;
         if (this.playing && !this.paused) {
            this.spinDeg = (this.spinDeg + (float)var23 * 0.12F) % 360.0F;
         }

         int var25 = (int)(this.spinDeg / 7.5F) % 48;
         var2.blit(RenderPipelines.GUI_TEXTURED, DISC[var25], var13 + var4, var14 + var4, 0.0F, 0.0F, var3, var3, 128, 128, 128, 128, -1);
         int var26 = var13 + var4 + var3 + 8;
         int var27 = Night.FONT_MANAGER.getHeight();
         int var28 = var14 + var4 + Math.max(0, (var3 - var27 - 6) / 2);
         Night.FONT_MANAGER.drawTextWithShadow(var2, var6, var26, var28, Color.WHITE);
         int var29 = var14 + var4 + var3 - 3;
         Renderer2D.renderQuad(var2, var26, var29, var26 + var8, var29 + 2, new Color(255, 255, 255, 55));
         long var30 = this.totalMs;
         if (this.playing && var30 > 0L) {
            float var32 = Math.max(0.0F, Math.min(1.0F, (float)this.posMs / (float)var30));
            Renderer2D.renderQuad(var2, var26, var29, var26 + var8 * var32, var29 + 2, var20);
         }

         int var42 = var26 + var8 / 2 - (var10 * 3 + var11 * 2) / 2;
         float var33 = var14 + var4 + var3 + 4;
         int var34 = var42 + var10 + var11;
         int var35 = var34 + var10 + var11;
         this.cardVisible = true;
         this.zoneY = (int)var33 - 3;
         this.zoneH = var9 + 6;
         this.zoneW = var10 + var11;
         this.rwX = var42 - 3;
         this.ppX = var34 - 3;
         this.fwX = var35 - 3;
         this.barX = var26;
         this.barY = var29;
         this.barW = var8;
         double[] var36 = this.cursorGui();
         Color var37 = new Color(255, 255, 255, 235);
         Color var39 = var36 != null && in(var36[0], var36[1], this.rwX, this.zoneY, this.zoneW, this.zoneH) ? var20 : var37;
         Color var40 = var36 != null && in(var36[0], var36[1], this.ppX, this.zoneY, this.zoneW, this.zoneH) ? var20 : var37;
         Color var41 = var36 != null && in(var36[0], var36[1], this.fwX, this.zoneY, this.zoneW, this.zoneH) ? var20 : var37;
         Renderer2D.renderQuad(var2, var42, var33, var42 + 1.5F, var33 + var9, var39);
         tri(var2, var42 + 2.0F, var33, var9, 5, false, var39);
         if (this.paused) {
            tri(var2, var34, var33, var9, var10, true, var40);
         } else {
            Renderer2D.renderQuad(var2, var34 + 0.5F, var33, var34 + 2.5F, var33 + var9, var40);
            Renderer2D.renderQuad(var2, var34 + 4.5F, var33, var34 + 6.5F, var33 + var9, var40);
         }

         tri(var2, var35, var33, var9, 5, true, var41);
         Renderer2D.renderQuad(var2, var35 + 5.5F, var33, var35 + 7.0F, var33 + var9, var41);
      } else {
         this.cardVisible = false;
      }
   }

   private static void roundRect(GuiGraphicsExtractor var0, int var1, int var2, int var3, int var4, int var5, Color var6) {
      for (int var7 = 0; var7 < var4; var7++) {
         float var8 = 0.0F;
         int var9 = var7 < var5 ? var5 - var7 : (var7 >= var4 - var5 ? var7 - (var4 - var5 - 1) : 0);
         if (var9 > 0) {
            float var10 = var9 - 0.5F;
            var8 = var5 - (float)Math.sqrt(Math.max(0.0F, (float)var5 * var5 - var10 * var10));
         }

         Renderer2D.renderQuad(var0, var1 + var8, var2 + var7, var1 + var3 - var8, var2 + var7 + 1, var6);
      }
   }

   static {
      for (int var0 = 0; var0 < 48; var0++) {
         DISC[var0] = Identifier.fromNamespaceAndPath("night", "textures/gui/disc/d" + var0 + ".png");
      }

      LOGO = Identifier.fromNamespaceAndPath("night", "textures/gui/logo.png");
   }
}
