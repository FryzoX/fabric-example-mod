package night.modules.impl.visuals.chestscan;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.state.BlockState;

public final class ChestScanChain {
   private ChestScanChain() {
   }

   public static Map<BlockPos, BlockPos> findEdges(Level level, Set<BlockPos> trackedChests, BlockPos center, int radiusBlocks) {
      HashMap<BlockPos, BlockPos> edges = new HashMap<>();
      double radiusSq = (double)radiusBlocks * radiusBlocks;
      ArrayDeque<BlockPos> frontier = new ArrayDeque<>(trackedChests);
      HashSet<BlockPos> visited = new HashSet<>(trackedChests);

      while (!frontier.isEmpty()) {
         BlockPos chestPos = frontier.poll();
         if (!(chestPos.distSqr(center) > radiusSq)) {
            BlockPos belowPos = chestPos.below();
            BlockState belowState = level.getBlockState(belowPos);
            BlockPos dest;
            if (belowState.getBlock() instanceof HopperBlock
               && isChest(level.getBlockState(dest = belowPos.relative((Direction)belowState.getValue(HopperBlock.FACING))))) {
               edges.put(chestPos, dest);
               if (visited.add(dest)) {
                  frontier.add(dest);
               }
            }

            for (Direction dir : Direction.values()) {
               BlockPos hopperPos = chestPos.relative(dir);
               BlockState hopperState = level.getBlockState(hopperPos);
               BlockPos sourcePos;
               if (hopperState.getBlock() instanceof HopperBlock
                  && hopperState.getValue(HopperBlock.FACING) == dir.getOpposite()
                  && isChest(level.getBlockState(sourcePos = hopperPos.above()))) {
                  edges.put(sourcePos, chestPos);
                  if (visited.add(sourcePos)) {
                     frontier.add(sourcePos);
                  }
               }
            }
         }
      }

      return edges;
   }

   private static boolean isChest(BlockState state) {
      return state.getBlock() instanceof ChestBlock;
   }

   public static Set<BlockPos> inferEmpty(Map<BlockPos, BlockPos> edges, Map<BlockPos, ChestScanStore.ChestStatus> realStatuses) {
      Map<BlockPos, List<BlockPos>> reverse = new HashMap<>();

      for (Entry<BlockPos, BlockPos> e : edges.entrySet()) {
         reverse.computeIfAbsent(e.getValue(), k -> new ArrayList<>()).add(e.getKey());
      }

      Set<BlockPos> inferred = new HashSet<>();
      Set<BlockPos> visited = new HashSet<>();

      for (Entry<BlockPos, ChestScanStore.ChestStatus> e : realStatuses.entrySet()) {
         if (e.getValue() != ChestScanStore.ChestStatus.FULL) {
            BlockPos start = e.getKey();
            if (visited.add(start)) {
               Deque<BlockPos> queue = new ArrayDeque<>();
               queue.add(start);

               while (!queue.isEmpty()) {
                  BlockPos cur = queue.poll();

                  for (BlockPos parent : reverse.getOrDefault(cur, List.of())) {
                     if (visited.add(parent)) {
                        if (!realStatuses.containsKey(parent)) {
                           inferred.add(parent);
                        }

                        queue.add(parent);
                     }
                  }
               }
            }
         }
      }

      return inferred;
   }
}
