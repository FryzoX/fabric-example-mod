package night.modules.impl.visuals;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PacketReceiveEvent;
import night.events.impl.RenderWorldEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.impl.miscellaneous.FakePlayerModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.graphics.KillEffectMemeRenderer;
import night.utils.minecraft.EntityUtils;
import org.joml.Vector3f;

@RegisterModule(
   name = "DeathEffects",
   description = "Renders certain effects on players when they die or disconnect.",
   category = Module.Category.VISUALS
)
public class DeathEffectsModule extends Module {
   public ModeSetting mode = new ModeSetting("Mode", "The effect that will be rendered.", "Both", new String[]{"Lightning", "Overlay", "Meme", "Both"});
   public BooleanSetting lightningOnKill = new BooleanSetting(
      "LightningOnKill", "Spawn lightning bolt when a player dies near you.", new ModeSetting.Visibility(this.mode, "Lightning", "Both"), true
   );
   public BooleanSetting lightningOnDisconnect = new BooleanSetting(
      "LightningOnDisconnect", "Spawn lightning bolt when a player disconnects near you.", new ModeSetting.Visibility(this.mode, "Lightning", "Both"), true
   );
   public NumberSetting lightningAmount = new NumberSetting(
      "LightningAmount", "The amount of lightning bolts to spawn.", new ModeSetting.Visibility(this.mode, "Lightning", "Both"), 1, 1, 10
   );
   public NumberSetting disconnectRange = new NumberSetting("DisconnectRange", "Range to detect player disconnects.", 64.0, 1.0, 256.0);
   public BooleanSetting overlayOnKill = new BooleanSetting(
      "OverlayOnKill", "Show freeze overlay when a player dies near you.", new ModeSetting.Visibility(this.mode, "Overlay"), true
   );
   public BooleanSetting overlayOnDisconnect = new BooleanSetting(
      "OverlayOnDisconnect", "Show freeze overlay when a player disconnects near you.", new ModeSetting.Visibility(this.mode, "Overlay"), true
   );
   public NumberSetting overlayDuration = new NumberSetting(
      "OverlayDuration", "Duration of the freeze overlay in milliseconds.", new ModeSetting.Visibility(this.mode, "Overlay"), 3000, 100, 10000
   );
   public NumberSetting overlayFadeDuration = new NumberSetting(
      "OverlayFadeDuration", "Fade duration of the freeze overlay in milliseconds.", new ModeSetting.Visibility(this.mode, "Overlay"), 2000, 100, 5000
   );
   public NumberSetting overlayAlpha = new NumberSetting(
      "OverlayAlpha", "Transparency of the freeze overlay (0-255, higher = more transparent).", new ModeSetting.Visibility(this.mode, "Overlay"), 200, 0, 255
   );
   public BooleanSetting memeOnKill = new BooleanSetting(
      "MemeOnKill", "Show the meme effect when a player dies near you.", new ModeSetting.Visibility(this.mode, "Meme", "Both"), true
   );
   public BooleanSetting memeOnDisconnect = new BooleanSetting(
      "MemeOnDisconnect", "Show the meme effect when a player disconnects near you.", new ModeSetting.Visibility(this.mode, "Meme", "Both"), true
   );
   public NumberSetting memeSize = new NumberSetting(
      "MemeSize", "Half-size of the circle/arrow, in blocks.", new ModeSetting.Visibility(this.mode, "Meme", "Both"), 1.0, 0.3, 3.0
   );
   private static final Identifier VINE_SOUND_ID = Identifier.fromNamespaceAndPath("night", "vine");
   private static final SoundEvent VINE_SOUND = SoundEvent.createVariableRangeEvent(VINE_SOUND_ID);
   private final Map<UUID, Vec3> lastPlayerPositions = new HashMap<>();
   private final Set<UUID> trackedPlayers = new HashSet<>();
   private long freezeEndTime = 0L;
   private boolean frostActive = false;
   private int nextLightningId = -90000;

   @Override
   public void onEnable() {
      this.lastPlayerPositions.clear();
      this.trackedPlayers.clear();
      this.freezeEndTime = 0L;
      this.frostActive = false;
   }

   @Override
   public void onDisable() {
      if (mc.player != null) {
         mc.player.setTicksFrozen(0);
      }

      this.frostActive = false;
      this.freezeEndTime = 0L;
      this.lastPlayerPositions.clear();
      this.trackedPlayers.clear();
   }

   private boolean isInvalidTarget(Player player) {
      if (player == null || player == mc.player) {
         return true;
      } else if (player.getId() < 0) {
         return true;
      } else if (EntityUtils.isGhost(player)) {
         return true;
      } else {
         FakePlayerModule fakePlayer = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(FakePlayerModule.class) : null;
         return fakePlayer != null && fakePlayer.isToggled() && player == fakePlayer.getPlayer();
      }
   }

   @SubscribeEvent
   public void onPacketReceive(PacketReceiveEvent event) {
      if (mc.level != null && mc.player != null) {
         Packet<?> packet2 = event.getPacket();
         ClientboundEntityEventPacket packet;
         if (packet2 instanceof ClientboundEntityEventPacket && (packet = (ClientboundEntityEventPacket)packet2).getEventId() == 3) {
            mc.execute(() -> {
               if (mc.level != null && mc.player != null) {
                  try {
                     Entity entity = packet.getEntity(mc.level);
                     Player player;
                     if (entity instanceof Player && !this.isInvalidTarget(player = (Player)entity) && mc.player.distanceToSqr(player) <= 100.0) {
                        if ((this.mode.getValue().equals("Lightning") || this.mode.getValue().equals("Both")) && this.lightningOnKill.getValue()) {
                           this.spawnLightning(new Vec3(player.getX(), player.getY(), player.getZ()));
                        }

                        if (this.mode.getValue().equals("Overlay") && this.overlayOnKill.getValue()) {
                           this.startOverlay();
                        }

                        if ((this.mode.getValue().equals("Meme") || this.mode.getValue().equals("Both")) && this.memeOnKill.getValue()) {
                           this.spawnMeme(new Vec3(player.getX(), player.getY() + player.getBbHeight() * 0.5, player.getZ()));
                        }
                     }
                  } catch (Exception var6) {
                  }
               }
            });
         }
      }
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (mc.player != null && mc.level != null) {
         this.updateFrostEffect();
         HashSet<UUID> currentPlayerUuids = new HashSet<>();

         for (Player player : mc.level.players()) {
            if (!this.isInvalidTarget(player)) {
               currentPlayerUuids.add(player.getUUID());
               this.lastPlayerPositions.put(player.getUUID(), new Vec3(player.getX(), player.getY(), player.getZ()));
            }
         }

         for (UUID uuid : new HashSet<>(this.trackedPlayers)) {
            if (!currentPlayerUuids.contains(uuid) && this.lastPlayerPositions.containsKey(uuid)) {
               Vec3 lastPos = this.lastPlayerPositions.get(uuid);
               double distance = Math.sqrt(
                  Math.pow(mc.player.getX() - lastPos.x, 2.0) + Math.pow(mc.player.getY() - lastPos.y, 2.0) + Math.pow(mc.player.getZ() - lastPos.z, 2.0)
               );
               if (distance <= this.disconnectRange.getValue().doubleValue()) {
                  if ((this.mode.getValue().equals("Meme") || this.mode.getValue().equals("Both")) && this.memeOnDisconnect.getValue()) {
                     this.spawnMeme(lastPos.add(0.0, 0.9, 0.0));
                  }

                  if ((this.mode.getValue().equals("Lightning") || this.mode.getValue().equals("Both")) && this.lightningOnDisconnect.getValue()) {
                     this.spawnLightning(lastPos);
                  }

                  if (this.mode.getValue().equals("Overlay") && this.overlayOnDisconnect.getValue()) {
                     this.startOverlay();
                  }
               }

               this.lastPlayerPositions.remove(uuid);
            }
         }

         this.trackedPlayers.clear();
         this.trackedPlayers.addAll(currentPlayerUuids);
      }
   }

   private void updateFrostEffect() {
      if (this.frostActive && mc.player != null) {
         long currentTime = System.currentTimeMillis();
         long elapsed = currentTime - (this.freezeEndTime - this.overlayDuration.getValue().longValue() - this.overlayFadeDuration.getValue().longValue());
         long totalDuration = this.overlayDuration.getValue().longValue() + this.overlayFadeDuration.getValue().longValue();
         if (elapsed < this.overlayDuration.getValue().longValue()) {
            int frozenTicks = (int)(140.0 * (this.overlayAlpha.getValue().doubleValue() / 255.0));
            mc.player.setTicksFrozen(frozenTicks);
         } else if (elapsed < totalDuration) {
            long fadeElapsed = elapsed - this.overlayDuration.getValue().longValue();
            double fadeProgress = 1.0 - (double)fadeElapsed / this.overlayFadeDuration.getValue().longValue();
            int frozenTicks = (int)(140.0 * (this.overlayAlpha.getValue().doubleValue() / 255.0) * fadeProgress);
            mc.player.setTicksFrozen(frozenTicks);
         } else {
            this.frostActive = false;
            this.freezeEndTime = 0L;
            mc.player.setTicksFrozen(0);
         }
      } else if (mc.player != null
         && mc.player.getTicksFrozen() > 0
         && mc.level != null
         && !mc.level.getBlockState(mc.player.blockPosition()).is(Blocks.POWDER_SNOW)) {
         mc.player.setTicksFrozen(0);
      }
   }

   private void startOverlay() {
      this.frostActive = true;
      this.freezeEndTime = System.currentTimeMillis();
   }

   private void spawnLightning(Vec3 pos) {
      if (mc.level != null) {
         if (!mc.isSameThread()) {
            mc.execute(() -> this.spawnLightning(pos));
         } else {
            int count = this.lightningAmount.getValue().intValue();

            for (int i = 0; i < count; i++) {
               LightningBolt lightning = new LightningBolt(EntityTypes.LIGHTNING_BOLT, mc.level);
               lightning.setPos(pos.x, pos.y, pos.z);
               lightning.setId(this.nextLightningId--);
               mc.level.addEntity(lightning);
            }
         }
      }
   }

   private void spawnMeme(Vec3 pos) {
      KillEffectMemeRenderer.INSTANCE.spawn(new Vector3f((float)pos.x, (float)pos.y, (float)pos.z), this.memeSize.getValue().floatValue());
      if (mc.getSoundManager() != null) {
         mc.getSoundManager().play(SimpleSoundInstance.forUI(VINE_SOUND, 1.0F, 1.0F));
      }
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldEvent event) {
      if (this.mode.getValue().equals("Meme") || this.mode.getValue().equals("Both")) {
         KillEffectMemeRenderer.INSTANCE.render(event.getMatrices());
      }
   }
}
