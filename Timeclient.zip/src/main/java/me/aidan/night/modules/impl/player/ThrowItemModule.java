package night.modules.impl.player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.GrimV3Inventory;
import night.utils.minecraft.KitRestockMath;
import night.utils.minecraft.R26InventoryMath;
import night.utils.minecraft.TotemSlotOwnership;

@RegisterModule(
   name = "ThrowItem",
   description = "Throw out items that arent belong to your loaded kit. Useful when you need to loot gears during combat",
   category = Module.Category.PLAYER
)
public class ThrowItemModule extends Module {
   public NumberSetting delay;
   public NumberSetting actionsPerTick;
   public BooleanSetting autoDisable;
   public BooleanSetting keepKitItems;
   public BooleanSetting minimumCount;
   public NumberSetting minCount;
   public BooleanSetting ignoreHotbar;
   public BooleanSetting onlyInventory;
   private final List<GrimV3Inventory.Click> planned;
   private boolean planning;
   private int ticks;
   private boolean settled;
   private long lastDiagnosticMs;
   public NumberSetting cleanupDelayMs = new NumberSetting(
      "CleanupDelayMs", "Additional module delay, 0-2000 milliseconds. Existing inventory synchronization still applies.", 200, 0, 2000
   );

   public boolean isSettled() {
      return this.settled;
   }

   public void invalidateCleanup() {
      this.settled = false;
   }

   private void diagnose(String reason) {
      KeyActionModule key = Night.MODULE_MANAGER.getModule(KeyActionModule.class);
      if (key != null && key.botXpDebug.getValue()) {
         long now = System.currentTimeMillis();
         if (now - this.lastDiagnosticMs >= 2000L) {
            this.lastDiagnosticMs = now;
            InventorySorterModule sorter = Night.MODULE_MANAGER.getModule(InventorySorterModule.class);
            Night.LOGGER
               .info(
                  "[ThrowDiag] player={} reason={} sorterOn={} settled={} sortAgeMs={} container={} cursor={} autoDisable={}",
                  new Object[]{
                     mc.player.getName().getString(),
                     reason,
                     sorter != null && sorter.isToggled(),
                     sorter != null && sorter.isSettled(),
                     now - InventorySorterModule.lastContainerActionMs,
                     mc.player.containerMenu.containerId,
                     mc.player.containerMenu.getCarried(),
                     this.autoDisable.getValue()
                  }
               );
         }
      }
   }

   @Override
   public void onEnable() {
      this.ticks = 0;
      this.settled = false;
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (!GrimV3Inventory.enabled()) {
         if (!GrimV3Inventory.routineBlocked()) {
            this.legacyTick(event);
         }
      } else if (GrimV3Inventory.canPlan()) {
         this.planned.clear();
         this.planning = true;

         try {
            this.legacyTick(event);
         } finally {
            this.planning = false;
         }

         if (!this.planned.isEmpty()) {
            GrimV3Inventory.submit(this, this.planned);
         }
      }
   }

   private void throwSlot(int containerId, int slot) {
      this.dropClick(slot, 1);
   }

   private void dropClick(int slot, int button) {
      if (this.planning) {
         this.planned.add(new GrimV3Inventory.Click(slot, button, ContainerInput.THROW));
      } else {
         mc.gameMode.handleContainerInput(mc.player.containerMenu.containerId, slot, button, ContainerInput.THROW, mc.player);
      }
   }

   private int invToHandlerSlot(int invSlot) {
      Inventory playerInv = mc.player.getInventory();

      for (Slot slot : mc.player.containerMenu.slots) {
         if (slot.container == playerInv && slot.getContainerSlot() == invSlot) {
            return slot.index;
         }
      }

      return -1;
   }

   public ThrowItemModule() {
      this.delay = new NumberSetting("Delay", "Tick delay between throw actions.", 1, 0, 20);
      this.actionsPerTick = new NumberSetting("ActionsPerTick", "Maximum items to drop per pass.", 3, 1, 20);
      this.autoDisable = new BooleanSetting("AutoDisable", "Automatically disables the module when no items are left to throw.", false);
      this.keepKitItems = new BooleanSetting("KeepKitItems", "Keep items that belong to the loaded kit even if in a different slot.", true);
      this.minimumCount = new BooleanSetting("MinimumCount", "Keep matching items only if their stack count reaches minimum count.", false);
      this.minCount = new NumberSetting(
         "MinCount", "The minimum stack count to keep an item.", new BooleanSetting.Visibility(this.minimumCount, true), 16, 1, 64
      );
      this.ignoreHotbar = new BooleanSetting("IgnoreHotbar", "Do not throw items from the hotbar (slots 0-8).", false);
      this.onlyInventory = new BooleanSetting("OnlyInventory", "Only throw items when in regular gameplay or InventoryScreen (not in Chests/Shulkers).", true);
      this.planned = new ArrayList<>();
      this.ticks = 0;
      this.minimumCount.getVisibility().setVisible(false);
      this.minCount.getVisibility().setVisible(false);
   }

   private void legacyTick(TickEvent var1) {
      if (mc.player != null && mc.level != null && mc.gameMode != null) {
         if (!mc.player.isCreative() && !mc.player.isSpectator()) {
            AutoShopModule var2 = Night.MODULE_MANAGER.getModule(AutoShopModule.class);
            if ((var2 == null || !var2.isRunning()) && mc.player.containerMenu == mc.player.inventoryMenu) {
               InventorySorterModule var3 = Night.MODULE_MANAGER.getModule(InventorySorterModule.class);
               if (var3 == null
                  || !var3.isToggled()
                  || var3.isSettled() && System.currentTimeMillis() - InventorySorterModule.lastContainerActionMs >= this.cleanupDelayMs.getValue().longValue()
                  )
                {
                  if (!mc.player.containerMenu.getCarried().isEmpty()) {
                     this.diagnose("CURSOR_BUSY");
                  } else {
                     RekitModule var4 = Night.MODULE_MANAGER.getModule(RekitModule.class);
                     if (var4 != null) {
                        Map var5 = var4.getActiveKit();
                        if (var5 != null && !var5.isEmpty()) {
                           if (!var4.isAutoActive() && System.currentTimeMillis() - RekitModule.lastContainerActionMs >= 200L) {
                              if (mc.gui.screen() != null && !(mc.gui.screen() instanceof InventoryScreen)) {
                                 this.diagnose("SCREEN_OPEN");
                              } else {
                                 boolean var6 = mc.gui.screen() instanceof AbstractContainerScreen && !(mc.gui.screen() instanceof InventoryScreen);
                                 if (!this.onlyInventory.getValue() || !var6) {
                                    if (this.keepKitItems.getValue()) {
                                       if (this.ticks < this.delay.getValue().intValue()) {
                                          this.ticks++;
                                       } else {
                                          this.ticks = 0;
                                          this.cleanKitSurplus(var2);
                                       }
                                    } else if (this.ticks < this.delay.getValue().intValue()) {
                                       this.ticks++;
                                    } else {
                                       this.ticks = 0;
                                       int var8 = mc.player.containerMenu.containerId;
                                       int var9 = 0;
                                       int var10 = this.planning
                                          ? Math.min(3, this.actionsPerTick.getValue().intValue())
                                          : this.actionsPerTick.getValue().intValue();
                                       int var11 = 0;
                                       int var12 = 0;

                                       for (int var13 = 0; var13 < 36; var13++) {
                                          ItemStack var15;
                                          if ((!this.ignoreHotbar.getValue() || var13 > 8) && !(var15 = mc.player.getInventory().getItem(var13)).isEmpty()) {
                                             if (TotemSlotOwnership.protectedSlot(var13, var15)) {
                                                var12++;
                                             } else if (var2 != null && var2.protectsAutoPurchasedItem(var15.getItem())) {
                                                var12++;
                                             } else {
                                                RekitModule.KitItem var16 = (RekitModule.KitItem)var5.get(var13);
                                                String var17 = BuiltInRegistries.ITEM.getKey(var15.getItem()).toString();
                                                boolean var18 = false;
                                                if (var16 != null && var16.id != null && var17.equalsIgnoreCase(var16.id)) {
                                                   var18 = true;
                                                } else if (this.keepKitItems.getValue()) {
                                                   for (RekitModule.KitItem var20 : var5.values()) {
                                                      if (var20 != null && var20.id != null && var17.equalsIgnoreCase(var20.id)) {
                                                         var18 = true;
                                                         break;
                                                      }
                                                   }
                                                }

                                                boolean var21 = false;
                                                if (!var18) {
                                                   var21 = true;
                                                }

                                                if (var21) {
                                                   var11++;
                                                   int var14;
                                                   if (var9 < var10 && (var14 = this.invToHandlerSlot(var13)) >= 0) {
                                                      this.throwSlot(var8, var14);
                                                      var9++;
                                                   }
                                                }
                                             }
                                          }
                                       }

                                       this.settled = var11 == 0;
                                       this.diagnose("SCAN eligible=" + var11 + (this.planning ? " planned=" : " dropped=") + var9 + " protected=" + var12);
                                       if (var11 == 0 && this.autoDisable.getValue()) {
                                          this.setToggled(false);
                                       }
                                    }
                                 }
                              }
                           } else {
                              this.diagnose("WAIT_REKIT");
                           }
                        } else {
                           this.settled = true;
                           this.diagnose("NO_ACTIVE_KIT");
                        }
                     }
                  }
               } else {
                  this.diagnose("WAIT_SORTER");
               }
            } else {
               this.diagnose("SHOP_OR_FOREIGN_CONTAINER");
            }
         } else {
            this.diagnose("CREATIVE_OR_SPECTATOR");
         }
      }
   }

   private void cleanKitSurplus(AutoShopModule var1) {
      HashMap var2 = new HashMap();

      for (int var3 = 0; var3 < 36; var3++) {
         ItemStack var4 = mc.player.getInventory().getItem(var3);
         if (!var4.isEmpty()) {
            var2.merge(var4.getItem(), var4.getCount(), Integer::sum);
         }
      }

      int var17 = 0;
      boolean var18 = false;
      int var5 = this.planning ? Math.min(3, this.actionsPerTick.getValue().intValue()) : this.actionsPerTick.getValue().intValue();
      RekitModule var6 = Night.MODULE_MANAGER.getModule(RekitModule.class);

      for (int var7 = 0; var7 < 2; var7++) {
         for (int var8 = 35; var8 >= 0; var8--) {
            ItemStack var12;
            if ((!this.ignoreHotbar.getValue() || var8 > 8)
               && !(var12 = mc.player.getInventory().getItem(var8)).isEmpty()
               && !TotemSlotOwnership.protectedSlot(var8, var12)) {
               RekitModule.KitItem var13 = var6.getActiveKit().get(var8);
               String var14 = BuiltInRegistries.ITEM.getKey(var12.getItem()).toString();
               boolean var15 = var13 != null && var14.equals(var13.id);
               if (var15 == (var7 == 1)
                  && KitRestockMath.surplus(this.kitQuota(var12.getItem()), var2.getOrDefault(var12.getItem(), 0)) > 0
                  && !var15
                  && R26InventoryMath.dropSurplus(var2.getOrDefault(var12.getItem(), 0), this.kitQuota(var12.getItem()), var12.getCount(), var15)) {
                  var18 = true;
                  int var10;
                  if (var17 < var5 && (var10 = this.invToHandlerSlot(var8)) >= 0) {
                     Item var16 = var12.getItem();
                     int var9 = var12.getCount();
                     this.throwSlot(mc.player.containerMenu.containerId, var10);
                     var17++;
                     var2.merge(var16, -var9, Integer::sum);
                  }
               }
            }
         }
      }

      this.settled = !var18;
      this.diagnose("KIT_CLEAN pending=" + var18 + " actions=" + var17);
   }

   private int kitQuota(Item var1) {
      RekitModule var2 = Night.MODULE_MANAGER.getModule(RekitModule.class);
      if (var2 == null) {
         return 0;
      } else {
         String var3 = BuiltInRegistries.ITEM.getKey(var1).toString();
         int var4 = 0;

         for (RekitModule.KitItem var6 : var2.getActiveKit().values()) {
            if (var6 != null && var3.equals(var6.id)) {
               var4 += var6.desiredCount();
            }
         }

         return var4;
      }
   }
}
