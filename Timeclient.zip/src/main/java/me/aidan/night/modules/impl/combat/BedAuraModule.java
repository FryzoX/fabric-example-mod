package night.modules.impl.combat;

import com.mojang.blaze3d.vertex.PoseStack;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Plane;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.protocol.game.ServerboundPlayerInputPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.CraftingMenu;
import net.minecraft.world.item.BedItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.ClientConnectEvent;
import night.events.impl.ClientDisconnectEvent;
import night.events.impl.KeyInputEvent;
import night.events.impl.MouseInputEvent;
import night.events.impl.RenderWorldEvent;
import night.events.impl.TickEvent;
import night.mixins.accessors.ClientPlayerEntityAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BindSetting;
import night.settings.impl.BooleanSetting;
import night.settings.impl.CategorySetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.color.ColorUtils;
import night.utils.graphics.Renderer3D;
import night.utils.minecraft.DamageUtils;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.WorldUtils;
import night.utils.rotations.RotationUtils;

@RegisterModule(
   name = "BedAura",
   description = "Automatically places and detonates beds in the Nether and End.",
   category = Module.Category.COMBAT
)
public class BedAuraModule extends Module {
   public CategorySetting targetingCategory = new CategorySetting("Targeting", "Settings related to target selection.");
   public ModeSetting targetMode = new ModeSetting(
      "Target",
      "Mode",
      "How targets are sorted.",
      new CategorySetting.Visibility(this.targetingCategory),
      "Closest",
      new String[]{"Closest", "Furthest", "Health"}
   );
   public NumberSetting targetRange = new NumberSetting(
      "TargetRange",
      "TargetRange",
      "The range within which players are considered targets.",
      new CategorySetting.Visibility(this.targetingCategory),
      8.0,
      1.0,
      16.0
   );
   public NumberSetting maxTargets = new NumberSetting(
      "MaxTargets",
      "MaxTargets",
      "Maximum number of targets to evaluate simultaneously.",
      new CategorySetting.Visibility(this.targetingCategory),
      3.0,
      1.0,
      8.0
   );
   public NumberSetting bedRange = new NumberSetting(
      "BedRange",
      "BedRange",
      "Search cube radius around the target to look for placement spots.",
      new CategorySetting.Visibility(this.targetingCategory),
      4.0,
      1.0,
      8.0
   );
   public BooleanSetting ignoreFriends = new BooleanSetting(
      "IgnoreFriends", "Ignore friends when targeting.", new CategorySetting.Visibility(this.targetingCategory), true
   );
   public CategorySetting damageCategory = new CategorySetting("Damage", "Damage calculation and safety settings.");
   public NumberSetting minDamage = new NumberSetting(
      "MinDamage", "MinDamage", "Minimum predicted damage to target.", new CategorySetting.Visibility(this.damageCategory), 6.0, 0.0, 36.0
   );
   public NumberSetting maxSelfDamage = new NumberSetting(
      "MaxSelfDamage", "MaxSelfDamage", "Maximum allowed damage to yourself.", new CategorySetting.Visibility(this.damageCategory), 6.0, 0.0, 36.0
   );
   public NumberSetting minHealth = new NumberSetting(
      "MinHealth",
      "MinHealth",
      "Do not act if your health (+absorption) is at or below this.",
      new CategorySetting.Visibility(this.damageCategory),
      4.0,
      0.0,
      36.0
   );
   public BooleanSetting antiSuicide = new BooleanSetting(
      "AntiSuicide", "Cancel if self damage drops health below MinHealth.", new CategorySetting.Visibility(this.damageCategory), true
   );
   public NumberSetting balance = new NumberSetting(
      "Balance", "Balance", "Minimum target to self damage ratio (0 = off).", new CategorySetting.Visibility(this.damageCategory), 0.0, 0.0, 10.0
   );
   public BooleanSetting predict = new BooleanSetting(
      "Predict", "Extrapolate target velocity for damage estimation.", new CategorySetting.Visibility(this.damageCategory), true
   );
   public CategorySetting behaviorCategory = new CategorySetting("Behavior", "Settings for placement and detonation behavior.");
   public NumberSetting delay = new NumberSetting(
      "Delay", "Delay", "Delay in milliseconds between actions.", new CategorySetting.Visibility(this.behaviorCategory), 100, 0, 500
   );
   public NumberSetting range = new NumberSetting(
      "Range", "Range", "Direct reach for placing and detonating beds.", new CategorySetting.Visibility(this.behaviorCategory), 4.5, 1.0, 6.0
   );
   public NumberSetting wallsRange = new NumberSetting(
      "WallsRange", "WallsRange", "Reach through walls / obstacles.", new CategorySetting.Visibility(this.behaviorCategory), 4.0, 0.0, 6.0
   );
   public ModeSetting swapMode = new ModeSetting(
      "SwapMode",
      "SwapMode",
      "How to swap to the bed and non-bed item.",
      new CategorySetting.Visibility(this.behaviorCategory),
      "Silent",
      new String[]{"Silent", "Normal", "Alt"}
   );
   public BooleanSetting rotate = new BooleanSetting(
      "Rotate", "Rotate towards bed before placing and detonating.", new CategorySetting.Visibility(this.behaviorCategory), true
   );
   public BooleanSetting strictDirection = new BooleanSetting(
      "StrictDirection", "Enforce strict raycast line of sight on placement face.", new CategorySetting.Visibility(this.behaviorCategory), false
   );
   public BooleanSetting airPlace = new BooleanSetting(
      "AirPlace", "Allow placing beds without a solid supporting block below.", new CategorySetting.Visibility(this.behaviorCategory), false
   );
   public BooleanSetting placeOnFeet = new BooleanSetting(
      "PlaceOnFeet", "Allow bed head to overlap target entity hitbox for maximum damage.", new CategorySetting.Visibility(this.behaviorCategory), true
   );
   public BooleanSetting pauseOnEat = new BooleanSetting(
      "PauseOnEat", "Pause while eating or consuming items.", new CategorySetting.Visibility(this.behaviorCategory), true
   );
   public CategorySetting autoCraftCategory = new CategorySetting("AutoCraft", "Automated bed crafting from wool and planks.");
   public BooleanSetting autoCraft = new BooleanSetting(
      "AutoCraft", "Enable automated bed crafting.", new CategorySetting.Visibility(this.autoCraftCategory), true
   );
   public BindSetting autoCraftBind = new BindSetting(
         "AutoCraftBind", "Keybind to toggle AutoCraft.", new CategorySetting.Visibility(this.autoCraftCategory), -1
      )
      .disableHoldModes();
   public BooleanSetting autoPlaceTable = new BooleanSetting(
      "AutoPlace", "Place and open a crafting table when out of beds.", new CategorySetting.Visibility(this.autoCraftCategory), true
   );
   public BooleanSetting autoCloseTable = new BooleanSetting(
      "AutoClose", "Close the crafting table GUI automatically when crafting is finished.", new CategorySetting.Visibility(this.autoCraftCategory), true
   );
   public CategorySetting renderCategory = new CategorySetting("Render", "Placement preview rendering.");
   public BooleanSetting renderPreview = new BooleanSetting(
      "Render", "Render preview box at target bed placement.", new CategorySetting.Visibility(this.renderCategory), true
   );
   public BooleanSetting interpolate = new BooleanSetting(
      "Interpolate", "Smooth linear grow-in animation for preview box.", new CategorySetting.Visibility(this.renderCategory), true
   );
   public ModeSetting renderMode = new ModeSetting(
      "RenderMode",
      "Mode",
      "Render mode for preview box.",
      new CategorySetting.Visibility(this.renderCategory),
      "Both",
      new String[]{"Fill", "Outline", "Both"}
   );
   public ColorSetting fillColor = new ColorSetting(
      "FillColor", "FillColor", "Color used for fill rendering.", new CategorySetting.Visibility(this.renderCategory), ColorUtils.getDefaultFillColor()
   );
   public ColorSetting outlineColor = new ColorSetting(
      "OutlineColor",
      "OutlineColor",
      "Color used for outline rendering.",
      new CategorySetting.Visibility(this.renderCategory),
      ColorUtils.getDefaultOutlineColor()
   );
   private static final int RECOMPUTE_INTERVAL_TICKS = 10;
   private int recomputeTicks = 0;
   private BlockPos currentFoot = null;
   private Direction currentDir = null;
   private Player currentTarget = null;
   private float currentEstimatedDamage = 0.0F;
   private BlockPos currentHead = null;
   private boolean currentAdopt = false;
   private long lastActionMs = 0L;
   private boolean bedPlacedThisCycle = false;
   private BlockPos placedBedPos = null;
   private BlockPos placedBedHeadPos = null;
   private BedAuraModule.PlacementCandidate currentPlacement = null;
   private final List<Player> targets = new ArrayList<>();
   private long placementRenderMs = 0L;
   private static final long PLACEMENT_ANIM_MS = 350L;
   private BlockPos lastRenderedPos = null;
   private boolean autoCraftRunning = false;
   private int autoCraftTicks = 0;
   private BlockPos placedTablePos = null;
   private boolean tableOpenSent = false;
   private boolean lastHadBeds = true;
   private static final int CRAFTING_RESULT_SLOT = 0;
   private static final int[] WOOL_GRID_SLOTS = new int[]{1, 2, 3};
   private static final int[] PLANK_GRID_SLOTS = new int[]{4, 5, 6};
   private static final int CRAFTING_CONTAINER_SIZE = 10;

   @Override
   public void onEnable() {
      this.clearSelection();
      this.recomputeTicks = 0;
      this.bedPlacedThisCycle = false;
      this.placedBedPos = null;
      this.placedBedHeadPos = null;
      this.autoCraftRunning = false;
      this.placedTablePos = null;
      this.tableOpenSent = false;
   }

   @Override
   public void onDisable() {
      this.clearSelection();
      this.autoCraftRunning = false;
      this.placedTablePos = null;
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (mc.player != null && mc.level != null) {
         if (this.autoCraft.getValue() && this.autoPlaceTable.getValue()) {
            boolean hasBeds = this.countBeds() > 0;
            if (!hasBeds && this.lastHadBeds) {
               this.startAutoCraft();
            }

            this.lastHadBeds = hasBeds;
         }

         if (this.autoCraftRunning) {
            this.handleAutoCraftTick();
         }

         this.runBedCycle();
      }
   }

   @SubscribeEvent
   public void onKeyInput(KeyInputEvent event) {
      if (mc.gui.screen() == null) {
         if (this.autoCraftBind.getValue() != -1 && event.getKey() == this.autoCraftBind.getValue()) {
            this.startAutoCraft();
            Night.CHAT_MANAGER.tagged("AutoCraft triggered!", "BedAura");
         }
      }
   }

   @SubscribeEvent
   public void onMouseInput(MouseInputEvent event) {
      if (mc.gui.screen() == null) {
         if (this.autoCraftBind.getValue() != -1 && event.getButton() == this.autoCraftBind.getValue()) {
            this.startAutoCraft();
            Night.CHAT_MANAGER.tagged("AutoCraft triggered!", "BedAura");
         }
      }
   }

   private void runBedCycle() {
      ResourceKey dim = mc.player.level().dimension();
      if (dim != Level.NETHER && dim != Level.END) {
         this.clearSelection();
      } else if (!this.pauseOnEat.getValue()
         || !mc.player.isUsingItem()
         || !mc.player.getUseItem().has(DataComponents.FOOD) && !mc.player.getUseItem().has(DataComponents.POTION_CONTENTS)) {
         float totalHealth = mc.player.getHealth() + mc.player.getAbsorptionAmount();
         if (!(totalHealth <= this.minHealth.getValue().floatValue())) {
            long now = System.currentTimeMillis();
            if (now - this.lastActionMs >= this.delay.getValue().longValue()) {
               if (this.bedPlacedThisCycle) {
                  this.submitDetonate();
               } else {
                  boolean hasBed = this.findBedSlot() != -1;
                  if (!hasBed) {
                     if (this.autoCraft.getValue() && this.countBeds() == 0 && !this.autoCraftRunning) {
                        this.startAutoCraft();
                     }

                     this.clearSelection();
                  } else {
                     this.updateTargets();
                     if (this.targets.isEmpty()) {
                        this.clearSelection();
                     } else {
                        if (this.recomputeTicks <= 0) {
                           this.recomputeTicks = 10;
                           BedAuraModule.ExistingBed existing = this.findExistingBed();
                           if (existing != null) {
                              this.currentFoot = existing.pos();
                              this.currentHead = this.findOtherBedHalf(existing.pos());
                              this.currentDir = null;
                              this.currentTarget = existing.target();
                              this.currentAdopt = true;
                              this.currentEstimatedDamage = existing.damage();
                              this.bedPlacedThisCycle = true;
                              this.placedBedPos = this.currentFoot;
                              this.placedBedHeadPos = this.currentHead;
                              this.currentPlacement = null;
                              this.submitDetonate();
                              return;
                           }

                           BedAuraModule.JointPlacement jointPlacement = this.searchPlacement();
                           if (jointPlacement == null) {
                              this.clearSelection();
                              return;
                           }

                           this.currentFoot = jointPlacement.foot();
                           this.currentDir = jointPlacement.dir();
                           this.currentTarget = jointPlacement.target();
                           this.currentEstimatedDamage = jointPlacement.estimatedDamage();
                           this.currentAdopt = false;
                           this.currentHead = this.currentFoot.relative(this.currentDir);
                        } else {
                           this.recomputeTicks--;
                           if (this.currentFoot != null && !this.currentAdopt && !this.currentSelectionStillGood()) {
                              this.recomputeTicks = 0;
                           }
                        }

                        if (this.currentFoot != null && this.currentDir != null && this.currentTarget != null) {
                           this.currentPlacement = new BedAuraModule.PlacementCandidate(this.currentFoot, this.currentDir, this.currentEstimatedDamage);
                           this.submitPlaceBed(this.currentFoot, this.currentDir);
                        } else {
                           this.clearSelection();
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void submitPlaceBed(BlockPos pos, Direction dir) {
      BlockHitResult hit = this.computeBedHit(pos);
      if (hit == null) {
         this.clearSelection();
         this.recomputeTicks = 4;
      } else {
         float yaw = dir.toYRot();
         float[] lookRots = RotationUtils.getRotations(hit.getLocation());
         float pitch = lookRots[1];
         Night.ROTATION_MANAGER.silentRotate(yaw, pitch);
         if (this.executePlaceBed(pos, hit)) {
            this.bedPlacedThisCycle = true;
            this.placedBedPos = pos;
            this.placedBedHeadPos = pos.relative(dir);
            this.lastActionMs = System.currentTimeMillis();
         }
      }
   }

   private void submitDetonate() {
      if (this.placedBedPos == null) {
         this.bedPlacedThisCycle = false;
      } else {
         BlockPos target = this.placedBedPos;
         if (this.placedBedHeadPos != null && this.currentTarget != null) {
            float dAnchor = this.computeDamage(Vec3.atCenterOf(this.placedBedPos), this.currentTarget);
            float dHead = this.computeDamage(Vec3.atCenterOf(this.placedBedHeadPos), this.currentTarget);
            if (dHead > dAnchor) {
               target = this.placedBedHeadPos;
            }
         }

         BlockHitResult hit;
         if ((hit = this.computeBedFace(target)) == null) {
            this.bedPlacedThisCycle = false;
            this.placedBedPos = null;
            this.placedBedHeadPos = null;
            this.currentPlacement = null;
            this.recomputeTicks = 4;
         } else {
            int detonateSlot = this.findDetonateSlot();
            float[] rots = RotationUtils.getRotations(hit.getLocation());
            Night.ROTATION_MANAGER.silentRotate(rots[0], rots[1]);
            int prevSlot = mc.player.getInventory().getSelectedSlot();
            boolean swapped = false;
            String mode = this.swapMode.getValue().equalsIgnoreCase("Alt") ? "AltPickup" : this.swapMode.getValue();
            if (detonateSlot != Integer.MIN_VALUE) {
               swapped = InventoryUtils.switchSlot(mode, detonateSlot, prevSlot);
            }

            try {
               mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, hit);
               mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
            } finally {
               if (swapped) {
                  InventoryUtils.switchBack(mode, detonateSlot, prevSlot);
               }
            }

            this.bedPlacedThisCycle = false;
            this.placedBedPos = null;
            this.placedBedHeadPos = null;
            this.currentPlacement = null;
            this.lastActionMs = System.currentTimeMillis();
         }
      }
   }

   private boolean executePlaceBed(BlockPos pos, BlockHitResult hit) {
      int bedSlot = this.findBedSlot();
      if (bedSlot == -1) {
         return false;
      } else {
         String mode = this.swapMode.getValue().equalsIgnoreCase("Alt") ? "AltPickup" : this.swapMode.getValue();
         int prevSlot;
         boolean swapped = InventoryUtils.switchSlot(mode, bedSlot, prevSlot = mc.player.getInventory().getSelectedSlot());
         if (!swapped && mc.getConnection() != null) {
            mc.getConnection().send(new ServerboundSetCarriedItemPacket(mc.player.getInventory().getSelectedSlot()));
         }

         boolean needSneak = WorldUtils.isInteractable(mc.level.getBlockState(hit.getBlockPos())) && !mc.player.isShiftKeyDown();
         if (needSneak) {
            Input real = mc.player.input != null ? mc.player.input.keyPresses : new Input(false, false, false, false, false, false, false);
            Input sneakInput = new Input(real.forward(), real.backward(), real.left(), real.right(), real.jump(), true, real.sprint());
            mc.getConnection().send(new ServerboundPlayerInputPacket(sneakInput));
            if (mc.player instanceof ClientPlayerEntityAccessor accessor) {
               accessor.setLastSentInput(sneakInput);
            }
         }

         label72: {
            Input real;
            try {
               mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, hit);
               mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
               if (!needSneak) {
                  break label72;
               }

               real = mc.player.input != null ? mc.player.input.keyPresses : new Input(false, false, false, false, false, false, false);
            } catch (Throwable var14) {
               if (needSneak) {
                  Input real2 = mc.player.input != null ? mc.player.input.keyPresses : new Input(false, false, false, false, false, false, false);
                  mc.getConnection().send(new ServerboundPlayerInputPacket(real2));
                  if (mc.player instanceof ClientPlayerEntityAccessor accessor) {
                     accessor.setLastSentInput(real2);
                  }
               }

               if (swapped) {
                  InventoryUtils.switchBack(mode, bedSlot, prevSlot);
               }

               throw var14;
            }

            mc.getConnection().send(new ServerboundPlayerInputPacket(real));
            if (mc.player instanceof ClientPlayerEntityAccessor accessor) {
               accessor.setLastSentInput(real);
            }
         }

         if (swapped) {
            InventoryUtils.switchBack(mode, bedSlot, prevSlot);
         }

         return true;
      }
   }

   private boolean canSeePlacementFace(Vec3 eye, Vec3 hitVec, BlockPos targetBlock) {
      BlockHitResult result = mc.level.clip(new ClipContext(eye, hitVec, Block.COLLIDER, Fluid.NONE, mc.player));
      if (result.getType() == Type.MISS) {
         return true;
      } else {
         return result instanceof BlockHitResult ? result.getBlockPos().equals(targetBlock) : false;
      }
   }

   private BlockHitResult computeBedHit(BlockPos pos) {
      double maxReach = Math.max(this.range.getValue().doubleValue(), this.wallsRange.getValue().doubleValue());
      if (!this.withinReach(pos, maxReach)) {
         return null;
      } else {
         BlockPos support = pos.below();
         boolean hasFloor = !mc.level.getBlockState(support).canBeReplaced();
         Vec3 eye = mc.player.getEyePosition();
         if (hasFloor) {
            Vec3 hitVec = new Vec3(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
            return !this.strictDirection.getValue() || !(eye.y < pos.getY()) && this.canSeePlacementFace(eye, hitVec, support)
               ? new BlockHitResult(hitVec, Direction.UP, support, false)
               : null;
         } else if (!this.airPlace.getValue()) {
            return null;
         } else {
            for (Direction dir : Direction.values()) {
               BlockPos neighbor = pos.relative(dir);
               if (!mc.level.getBlockState(neighbor).canBeReplaced()) {
                  Direction placeDir = dir.getOpposite();
                  Vec3 hitVec = new Vec3(
                     pos.getX() + 0.5 - dir.getStepX() * 0.5, pos.getY() + 0.5 - dir.getStepY() * 0.5, pos.getZ() + 0.5 - dir.getStepZ() * 0.5
                  );
                  if (!this.strictDirection.getValue() || this.canSeePlacementFace(eye, hitVec, neighbor)) {
                     return new BlockHitResult(hitVec, placeDir, neighbor, false);
                  }
               }
            }

            if (this.strictDirection.getValue()) {
               return null;
            } else {
               Vec3 hitVec = new Vec3(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
               return new BlockHitResult(hitVec, Direction.UP, pos, false);
            }
         }
      }
   }

   private BlockHitResult computeBedFace(BlockPos pos) {
      Vec3 eye = mc.player.getEyePosition();
      double reach = Math.max(this.range.getValue().doubleValue(), this.wallsRange.getValue().doubleValue());
      Vec3 center = Vec3.atCenterOf(pos);
      BlockHitResult best = null;
      double bestDist = Double.MAX_VALUE;
      BlockHitResult fallback = null;
      double fallbackDist = Double.MAX_VALUE;

      for (Direction dir : Direction.values()) {
         Vec3 normal = new Vec3(dir.getStepX(), dir.getStepY(), dir.getStepZ());
         Vec3 face = center.add(normal.scale(0.5));
         double dist;
         if (!(eye.subtract(face).dot(normal) <= 0.0) && !((dist = face.distanceTo(eye)) > reach)) {
            if (dist < fallbackDist) {
               fallbackDist = dist;
               fallback = new BlockHitResult(face, dir, pos, false);
            }

            BlockPos hitP;
            BlockHitResult rc;
            if ((
                  (rc = mc.level.clip(new ClipContext(eye, face, Block.COLLIDER, Fluid.NONE, mc.player))).getType() != Type.BLOCK
                     || !(rc instanceof BlockHitResult)
                     || (hitP = rc.getBlockPos()).equals(pos)
                     || this.placedBedPos != null && hitP.equals(this.placedBedPos)
                     || this.placedBedHeadPos != null && hitP.equals(this.placedBedHeadPos)
               )
               && dist < bestDist) {
               bestDist = dist;
               best = new BlockHitResult(face, dir, pos, false);
            }
         }
      }

      return best != null ? best : fallback;
   }

   private BedAuraModule.JointPlacement searchPlacement() {
      int r = (int)Math.ceil(this.bedRange.getValue().doubleValue());
      double minD = this.minDamage.getValue().doubleValue();
      double maxD = this.maxSelfDamage.getValue().doubleValue();
      double exReach = Math.max(this.range.getValue().doubleValue(), this.wallsRange.getValue().doubleValue());
      BedAuraModule.JointPlacement best = null;
      double bestScore = -1.0;
      Vec3 eye = mc.player.getEyePosition();
      double reachEye = exReach + 0.5;

      for (Player targetPlayer : this.targets) {
         BlockPos center = targetPlayer.blockPosition();
         Vec3 targetCenter = targetPlayer.getBoundingBox().getCenter();
         int dzHi;
         int dzLo;
         int dyHi;
         int dyLo;
         int dxHi;
         int dxLo;
         if (!(Vec3.atCenterOf(center).distanceTo(eye) > r * Math.sqrt(3.0) + reachEye)
            && (dxLo = Math.max(-r, (int)Math.floor(eye.x - reachEye - center.getX())))
               <= (dxHi = Math.min(r, (int)Math.ceil(eye.x + reachEye - center.getX())))
            && (dyLo = Math.max(-r, (int)Math.floor(eye.y - reachEye - center.getY())))
               <= (dyHi = Math.min(r, (int)Math.ceil(eye.y + reachEye - center.getY())))
            && (dzLo = Math.max(-r, (int)Math.floor(eye.z - reachEye - center.getZ())))
               <= (dzHi = Math.min(r, (int)Math.ceil(eye.z + reachEye - center.getZ())))) {
            for (int dx = dxLo; dx <= dxHi; dx++) {
               for (int dy = dyLo; dy <= dyHi; dy++) {
                  for (int dz = dzLo; dz <= dzHi; dz++) {
                     BlockPos foot = center.offset(dx, dy, dz);
                     if (!(Vec3.atCenterOf(foot).distanceTo(eye) > reachEye) && this.footPlaceable(foot, exReach)) {
                        for (Direction dir : Plane.HORIZONTAL) {
                           BlockPos head = foot.relative(dir);
                           if (this.headPlaceable(head)) {
                              Vec3 footCenter = Vec3.atCenterOf(foot);
                              Vec3 headCenter = Vec3.atCenterOf(head);
                              float dFootTarget = this.computeDamage(footCenter, targetPlayer);
                              float dHeadTarget = this.computeDamage(headCenter, targetPlayer);
                              boolean useHead = dHeadTarget >= dFootTarget;
                              Vec3 detonateCenter = useHead ? headCenter : footCenter;
                              float dmg = Math.max(dFootTarget, dHeadTarget);
                              float selfDmg;
                              if (!(dmg < minD) && !((selfDmg = this.computeDamage(detonateCenter, mc.player)) > maxD)) {
                                 float myHp = mc.player.getHealth() + mc.player.getAbsorptionAmount();
                                 if ((!this.antiSuicide.getValue() || !(myHp - selfDmg <= this.minHealth.getValue().floatValue()))
                                    && (
                                       !(this.balance.getValue().doubleValue() > 0.0)
                                          || !(selfDmg > 0.0F)
                                          || !(dmg / selfDmg < this.balance.getValue().doubleValue())
                                    )) {
                                    double score = dmg;
                                    if (headCenter.distanceTo(targetCenter) < footCenter.distanceTo(targetCenter)) {
                                       score += 0.01;
                                    }

                                    if (best == null || score > bestScore) {
                                       best = new BedAuraModule.JointPlacement(foot, dir, targetPlayer, dmg);
                                       bestScore = score;
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return best;
   }

   private boolean footPlaceable(BlockPos foot, double reach) {
      if (!this.withinReach(foot, reach)) {
         return false;
      } else if (!mc.level.getBlockState(foot).canBeReplaced()) {
         return false;
      } else {
         return !this.airPlace.getValue() && mc.level.getBlockState(foot.below()).canBeReplaced()
            ? false
            : !this.strictDirection.getValue() || this.computeBedHit(foot) != null;
      }
   }

   private boolean headPlaceable(BlockPos head) {
      if (!mc.level.getBlockState(head).canBeReplaced()) {
         return false;
      } else {
         return this.placeOnFeet.getValue() ? true : !this.entityAt(head);
      }
   }

   private boolean entityAt(BlockPos pos) {
      AABB box = new AABB(pos);

      for (Entity e : mc.level.entitiesForRendering()) {
         if (e != mc.player && !(e instanceof ItemEntity) && e.isAlive() && e.getBoundingBox().intersects(box)) {
            return true;
         }
      }

      return false;
   }

   private boolean currentSelectionStillGood() {
      if (this.currentFoot != null && this.currentDir != null && this.currentTarget != null) {
         if (this.currentTarget.isAlive() && !(this.currentTarget.getHealth() <= 0.0F)) {
            BlockPos head = this.currentFoot.relative(this.currentDir);
            double exReach = Math.max(this.range.getValue().doubleValue(), this.wallsRange.getValue().doubleValue());
            if (!this.withinReach(this.currentFoot, exReach) && !this.withinReach(head, exReach)) {
               return false;
            } else if (this.strictDirection.getValue() && this.computeBedHit(this.currentFoot) == null) {
               return false;
            } else {
               Vec3 footCenter = Vec3.atCenterOf(this.currentFoot);
               Vec3 headCenter = Vec3.atCenterOf(head);
               float dFoot = this.computeDamage(footCenter, this.currentTarget);
               float dHead;
               float dmg = Math.max(dFoot, dHead = this.computeDamage(headCenter, this.currentTarget));
               if (dmg < this.minDamage.getValue().doubleValue()) {
                  return false;
               } else {
                  Vec3 detonateCenter = dHead >= dFoot ? headCenter : footCenter;
                  float selfDmg = this.computeDamage(detonateCenter, mc.player);
                  if (selfDmg > this.maxSelfDamage.getValue().doubleValue()) {
                     return false;
                  } else {
                     this.currentEstimatedDamage = dmg;
                     return true;
                  }
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private BedAuraModule.ExistingBed findExistingBed() {
      double exReach = Math.max(this.range.getValue().doubleValue(), this.wallsRange.getValue().doubleValue());
      int r = (int)Math.ceil(this.bedRange.getValue().doubleValue());
      BedAuraModule.ExistingBed best = null;

      for (Player targetPlayer : this.targets) {
         BlockPos center = targetPlayer.blockPosition();
         Vec3 targetCenter = targetPlayer.getBoundingBox().getCenter();

         for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
               for (int dz = -r; dz <= r; dz++) {
                  BlockPos pos = center.offset(dx, dy, dz);
                  float dmg;
                  if (mc.level.getBlockState(pos).getBlock() instanceof BedBlock
                     && !(Vec3.atCenterOf(pos).distanceTo(targetCenter) > 6.0)
                     && this.withinReach(pos, exReach)
                     && !(this.computeDamage(Vec3.atCenterOf(pos), mc.player) > this.maxSelfDamage.getValue().doubleValue())
                     && !((dmg = this.computeDamage(Vec3.atCenterOf(pos), targetPlayer)) < this.minDamage.getValue().doubleValue())
                     && (best == null || dmg > best.damage())) {
                     best = new BedAuraModule.ExistingBed(pos, targetPlayer, dmg);
                  }
               }
            }
         }
      }

      return best;
   }

   private float computeDamage(Vec3 explosionCenter, Player target) {
      if (this.predict.getValue()) {
         Vec3 predictedPos = target.position().add(target.getDeltaMovement());
         AABB predictedBox = target.getBoundingBox().move(predictedPos.subtract(target.position()));
         return DamageUtils.getDamage(target, predictedBox, explosionCenter, 5.0F, null, false);
      } else {
         return DamageUtils.getDamage(target, target.getBoundingBox(), explosionCenter, 5.0F, null, false);
      }
   }

   private boolean withinReach(BlockPos pos, double reach) {
      return Vec3.atCenterOf(pos).distanceTo(mc.player.getEyePosition()) <= reach + 0.5;
   }

   private void updateTargets() {
      this.targets.clear();
      Vec3 eye = mc.player.getEyePosition();
      List<Player> found = new ArrayList<>();

      for (Entity entity : mc.level.entitiesForRendering()) {
         if (entity instanceof Player p
            && p != mc.player
            && p.isAlive()
            && !(p.getHealth() <= 0.0F)
            && (!this.ignoreFriends.getValue() || !Night.FRIEND_MANAGER.contains(p.getName().getString()))
            && (
               !(Vec3.atCenterOf(p.blockPosition()).distanceTo(eye) > this.targetRange.getValue().doubleValue())
                  || !(p.distanceTo(mc.player) > this.targetRange.getValue().doubleValue())
            )) {
            found.add(p);
         }
      }

      String var8 = this.targetMode.getValue();

      Comparator<Player> comparator = switch (var8) {
         case "Furthest" -> Comparator.<Player>comparingDouble(px -> px.distanceTo(mc.player)).reversed();
         case "Health" -> Comparator.comparingDouble(LivingEntity::getHealth);
         default -> Comparator.comparingDouble(px -> px.distanceTo(mc.player));
      };
      found.sort(comparator);
      int max = this.maxTargets.getValue().intValue();

      for (Player p : found) {
         if (this.targets.size() >= max) {
            break;
         }

         this.targets.add(p);
      }
   }

   private BlockPos findOtherBedHalf(BlockPos foot) {
      for (Direction d : Plane.HORIZONTAL) {
         BlockPos neighbour = foot.relative(d);
         if (mc.level.getBlockState(neighbour).getBlock() instanceof BedBlock) {
            return neighbour;
         }
      }

      return null;
   }

   private int findBedSlot() {
      boolean wholeInv = this.swapMode.getValue().equalsIgnoreCase("Alt");
      Predicate<ItemStack> isBed = s -> !s.isEmpty() && s.getItem() instanceof BedItem;
      if (wholeInv) {
         for (int i = 0; i < 36; i++) {
            if (isBed.test(mc.player.getInventory().getItem(i))) {
               return i;
            }
         }

         return -1;
      } else {
         for (int ix = 0; ix < 9; ix++) {
            if (isBed.test(mc.player.getInventory().getItem(ix))) {
               return ix;
            }
         }

         return -1;
      }
   }

   private int findDetonateSlot() {
      boolean wholeInv = this.swapMode.getValue().equalsIgnoreCase("Alt");
      Predicate<ItemStack> safeItem = s -> !s.isEmpty() && !(s.getItem() instanceof BedItem) && !(s.getItem() instanceof BlockItem);
      if (wholeInv) {
         for (int i = 0; i < 36; i++) {
            if (safeItem.test(mc.player.getInventory().getItem(i))) {
               return i;
            }
         }
      } else {
         for (int ix = 0; ix < 9; ix++) {
            if (safeItem.test(mc.player.getInventory().getItem(ix))) {
               return ix;
            }
         }
      }

      for (int var5 = 0; var5 < 9; var5++) {
         if (mc.player.getInventory().getItem(var5).isEmpty()) {
            return var5;
         }
      }

      for (int var6 = 0; var6 < 9; var6++) {
         if (!(mc.player.getInventory().getItem(var6).getItem() instanceof BedItem)) {
            return var6;
         }
      }

      return Integer.MIN_VALUE;
   }

   private void clearSelection() {
      this.currentFoot = null;
      this.currentDir = null;
      this.currentTarget = null;
      this.currentEstimatedDamage = 0.0F;
      this.currentHead = null;
      this.currentAdopt = false;
      this.currentPlacement = null;
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldEvent event) {
      if (this.renderPreview.getValue() && mc.level != null && mc.player != null) {
         BlockPos head;
         BlockPos pos;
         if (this.bedPlacedThisCycle && this.placedBedPos != null) {
            pos = this.placedBedPos;
            head = this.placedBedHeadPos != null ? this.placedBedHeadPos : this.findOtherBedHalf(pos);
            if (head != null) {
               this.placedBedHeadPos = head;
            }
         } else if (this.currentPlacement != null) {
            pos = this.currentPlacement.pos();
            head = pos.relative(this.currentPlacement.dir());
         } else {
            if (this.currentFoot == null) {
               this.lastRenderedPos = null;
               return;
            }

            pos = this.currentFoot;
            head = this.currentHead != null
               ? this.currentHead
               : (this.currentDir != null ? this.currentFoot.relative(this.currentDir) : this.findOtherBedHalf(pos));
         }

         if (!pos.equals(this.lastRenderedPos)) {
            this.lastRenderedPos = pos;
            this.placementRenderMs = System.currentTimeMillis();
         }

         float scale = 1.0F;
         if (this.interpolate.getValue()) {
            long elapsed = System.currentTimeMillis() - this.placementRenderMs;
            float t = Math.min(1.0F, (float)elapsed / 350.0F);
            scale = 0.15F + 0.85F * t;
         }

         double bedHeight = 0.5625;
         PoseStack matrices = event.getMatrices();
         double minX = pos.getX();
         double minY = pos.getY();
         double minZ = pos.getZ();
         double maxX = pos.getX() + 1.0;
         double maxY = pos.getY() + 0.5625;
         double maxZ = pos.getZ() + 1.0;
         if (head != null) {
            minX = Math.min(pos.getX(), head.getX());
            minY = Math.min(pos.getY(), head.getY());
            minZ = Math.min(pos.getZ(), head.getZ());
            maxX = Math.max(pos.getX(), head.getX()) + 1.0;
            maxY = Math.max(pos.getY(), head.getY()) + 0.5625;
            maxZ = Math.max(pos.getZ(), head.getZ()) + 1.0;
         }

         double cx = (minX + maxX) * 0.5;
         double cy = (minY + maxY) * 0.5;
         double cz = (minZ + maxZ) * 0.5;
         double halfX = (maxX - minX) * 0.5 * scale;
         double halfY = (maxY - minY) * 0.5 * scale;
         double halfZ = (maxZ - minZ) * 0.5 * scale;
         AABB box = new AABB(cx - halfX, cy - halfY, cz - halfZ, cx + halfX, cy + halfY, cz + halfZ);
         Color fill = this.fillColor.getColor();
         Color outline = this.outlineColor.getColor();
         boolean doFill = this.renderMode.getValue().equalsIgnoreCase("Fill") || this.renderMode.getValue().equalsIgnoreCase("Both");
         boolean doOutline = this.renderMode.getValue().equalsIgnoreCase("Outline") || this.renderMode.getValue().equalsIgnoreCase("Both");
         if (doFill) {
            Renderer3D.renderBox(matrices, box, fill);
         }

         if (doOutline) {
            Renderer3D.renderBoxOutline(matrices, box, outline);
         }
      }
   }

   private void startAutoCraft() {
      if (!this.autoCraftRunning) {
         this.autoCraftRunning = true;
         this.autoCraftTicks = 0;
         this.placedTablePos = null;
         this.tableOpenSent = false;
      }
   }

   private void handleAutoCraftTick() {
      this.autoCraftTicks++;
      if (this.autoCraftTicks > 200) {
         this.autoCraftRunning = false;
      } else {
         boolean craftingOpen = mc.player.containerMenu instanceof CraftingMenu;
         if (!craftingOpen) {
            if (!this.autoPlaceTable.getValue()) {
               this.autoCraftRunning = false;
            } else if (this.placedTablePos == null) {
               this.placedTablePos = this.tryPlaceCraftingTable();
               if (this.placedTablePos == null) {
                  this.autoCraftRunning = false;
               } else {
                  this.tableOpenSent = false;
                  this.autoCraftTicks = 0;
               }
            } else {
               boolean tableThere = mc.level.getBlockState(this.placedTablePos).getBlock() == Blocks.CRAFTING_TABLE;
               if (tableThere && !this.tableOpenSent) {
                  if (this.rotate.getValue()) {
                     float[] rots = RotationUtils.getRotations(Vec3.atCenterOf(this.placedTablePos));
                     Night.ROTATION_MANAGER.silentRotate(rots[0], rots[1]);
                  }

                  mc.gameMode
                     .useItemOn(
                        mc.player,
                        InteractionHand.MAIN_HAND,
                        new BlockHitResult(Vec3.atCenterOf(this.placedTablePos), Direction.UP, this.placedTablePos, false)
                     );
                  this.tableOpenSent = true;
                  this.autoCraftTicks = 0;
               } else {
                  if (this.autoCraftTicks > 40) {
                     this.autoCraftRunning = false;
                     this.placedTablePos = null;
                     this.tableOpenSent = false;
                  }
               }
            }
         } else {
            this.placedTablePos = null;
            this.tableOpenSent = false;
            AbstractContainerMenu handler = mc.player.containerMenu;
            if (!this.gridHasMaterials(handler) && !this.fillCraftingGrid(handler)) {
               if (this.autoCloseTable.getValue()) {
                  mc.player.closeContainer();
               }

               this.autoCraftRunning = false;
            } else {
               mc.gameMode.handleContainerInput(handler.containerId, 0, 0, ContainerInput.QUICK_MOVE, mc.player);
               if (this.isInventoryFull()) {
                  if (this.autoCloseTable.getValue()) {
                     mc.player.closeContainer();
                  }

                  this.autoCraftRunning = false;
               }
            }
         }
      }
   }

   private int countBeds() {
      int count = 0;

      for (int i = 0; i < 36; i++) {
         ItemStack stack = mc.player.getInventory().getItem(i);
         if (stack.getItem() instanceof BedItem) {
            count += stack.getCount();
         }
      }

      return count;
   }

   private boolean isInventoryFull() {
      for (int i = 0; i < 36; i++) {
         if (mc.player.getInventory().getItem(i).isEmpty()) {
            return false;
         }
      }

      return true;
   }

   private boolean gridHasMaterials(AbstractContainerMenu handler) {
      for (int slot : WOOL_GRID_SLOTS) {
         if (!this.isWool(handler.getSlot(slot).getItem())) {
            return false;
         }
      }

      for (int slotx : PLANK_GRID_SLOTS) {
         if (!this.isPlanks(handler.getSlot(slotx).getItem())) {
            return false;
         }
      }

      return true;
   }

   private boolean isWool(ItemStack stack) {
      return !stack.isEmpty() && stack.is(ItemTags.WOOL);
   }

   private boolean isPlanks(ItemStack stack) {
      return !stack.isEmpty() && stack.is(ItemTags.PLANKS);
   }

   private boolean fillCraftingGrid(AbstractContainerMenu handler) {
      int woolSlot = this.findMenuSlot(handler, this::isWool);
      int plankSlot = this.findMenuSlot(handler, this::isPlanks);
      if (woolSlot != -1 && plankSlot != -1) {
         for (int gridSlot : WOOL_GRID_SLOTS) {
            if (!this.isWool(handler.getSlot(gridSlot).getItem())) {
               int slot = this.findMenuSlot(handler, this::isWool);
               if (slot == -1) {
                  return false;
               }

               this.placeOneItem(handler, slot, gridSlot);
            }
         }

         for (int gridSlotx : PLANK_GRID_SLOTS) {
            if (!this.isPlanks(handler.getSlot(gridSlotx).getItem())) {
               int slot = this.findMenuSlot(handler, this::isPlanks);
               if (slot == -1) {
                  return false;
               }

               this.placeOneItem(handler, slot, gridSlotx);
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private void placeOneItem(AbstractContainerMenu handler, int source, int dest) {
      mc.gameMode.handleContainerInput(handler.containerId, source, 1, ContainerInput.PICKUP, mc.player);
      mc.gameMode.handleContainerInput(handler.containerId, dest, 1, ContainerInput.PICKUP, mc.player);
      mc.gameMode.handleContainerInput(handler.containerId, source, 0, ContainerInput.PICKUP, mc.player);
   }

   private int findMenuSlot(AbstractContainerMenu handler, Predicate<ItemStack> test) {
      for (int i = 10; i < handler.slots.size(); i++) {
         if (test.test(handler.getSlot(i).getItem())) {
            return i;
         }
      }

      return -1;
   }

   private BlockPos tryPlaceCraftingTable() {
      int tableSlot = -1;

      for (int i = 0; i < 9; i++) {
         if (mc.player.getInventory().getItem(i).getItem() == Blocks.CRAFTING_TABLE.asItem()) {
            tableSlot = i;
            break;
         }
      }

      if (tableSlot == -1) {
         return null;
      } else {
         BlockPos base = mc.player.blockPosition();
         BlockPos best = null;
         double bestDistSq = Double.MAX_VALUE;
         int r = (int)Math.ceil(this.range.getValue().doubleValue());

         for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
               for (int dz = -r; dz <= r; dz++) {
                  BlockPos candidate = base.offset(dx, dy, dz);
                  double distSq = mc.player.distanceToSqr(candidate.getX() + 0.5, candidate.getY() + 0.5, candidate.getZ() + 0.5);
                  if (!(distSq > this.range.getValue().doubleValue() * this.range.getValue().doubleValue())
                     && mc.level.getBlockState(candidate).canBeReplaced()
                     && !mc.level.getBlockState(candidate.below()).canBeReplaced()
                     && !new AABB(candidate).intersects(mc.player.getBoundingBox())
                     && distSq < bestDistSq) {
                     bestDistSq = distSq;
                     best = candidate;
                  }
               }
            }
         }

         if (best == null) {
            return null;
         } else {
            BlockPos support = best.below();
            BlockHitResult hit = new BlockHitResult(new Vec3(best.getX() + 0.5, best.getY(), best.getZ() + 0.5), Direction.UP, support, false);
            int prevSlot = mc.player.getInventory().getSelectedSlot();
            InventoryUtils.switchSlot("Normal", tableSlot, prevSlot);
            mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, hit);
            InventoryUtils.switchBack("Normal", tableSlot, prevSlot);
            return best;
         }
      }
   }

   @SubscribeEvent
   public void onDisconnect(ClientDisconnectEvent event) {
      this.clearSelection();
      this.autoCraftRunning = false;
   }

   @SubscribeEvent
   public void onConnect(ClientConnectEvent event) {
      this.clearSelection();
      this.autoCraftRunning = false;
   }

   private record ExistingBed(BlockPos pos, Player target, float damage) {
   }

   public record JointPlacement(BlockPos foot, Direction dir, Player target, float estimatedDamage) {
   }

   public record PlacementCandidate(BlockPos pos, Direction dir, float estimatedDamage) {
   }
}
