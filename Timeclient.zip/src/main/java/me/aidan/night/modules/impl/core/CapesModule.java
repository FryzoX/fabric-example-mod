package night.modules.impl.core;

import lombok.Generated;
import net.minecraft.resources.Identifier;
import night.modules.Module;
import night.modules.RegisterModule;

@RegisterModule(
   name = "Capes",
   description = "Applies the xnhau cape to yourself and to other users.",
   category = Module.Category.CORE,
   toggled = true,
   drawn = false
)
public class CapesModule extends Module {
   private final Identifier capeTexture = Identifier.fromNamespaceAndPath("night", "cape");

   @Generated
   public Identifier getCapeTexture() {
      return this.capeTexture;
   }
}
