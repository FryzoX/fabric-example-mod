package night.modules.impl.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.ChatFormatting;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.phys.Vec3;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.RenderWorldEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.modules.api.IFreecamModule;
import night.modules.impl.miscellaneous.FakePlayerModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ColorSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.color.ColorUtils;
import night.utils.graphics.Renderer3D;
import night.utils.minecraft.EntityUtils;

@RegisterModule(
   name = "NameTags",
   description = "Replaces the default Minecraft NameTag with a more visible and customizable one.",
   category = Module.Category.VISUALS
)
public class NameTagsModule extends Module {
   private static final Identifier LOGO_ID = Identifier.fromNamespaceAndPath("night", "textures/gui/logo.png");
   public BooleanSetting gameMode = new BooleanSetting("GameMode", "Renders the player's gamemode.", false);
   public BooleanSetting ping = new BooleanSetting("Ping", "Renders the player's latency to the server.", true);
   public BooleanSetting entityId = new BooleanSetting("EntityID", "Renders the player's entity ID.", false);
   public BooleanSetting health = new BooleanSetting("Health", "Renders the player's health and absorption.", true);
   public BooleanSetting totemPops = new BooleanSetting("TotemPops", "Renders the amount of totems that the player has popped.", true);
   public BooleanSetting antiBot = new BooleanSetting("AntiBot", "Prevents bots from having nametags rendered for them.", false);
   public BooleanSetting nightCheck = new BooleanSetting("xnhauCheck", "Adds an indicator next to the name of other xnhau users.", true);
   public BooleanSetting self = new BooleanSetting("Self", "Also renders a nametag above your own player.", false);
   public BooleanSetting items = new BooleanSetting("Items", "Renders the items that the player is wearing or holding.", true);
   public BooleanSetting enchantments = new BooleanSetting("Enchantments", "Renders the enchantments of the player's items.", false);
   public BooleanSetting durability = new BooleanSetting("Durability", "Renders the durability of the player's items.", true);
   public BooleanSetting itemName = new BooleanSetting("ItemName", "Renders the name of the item that the player is currently holding.", true);
   public BooleanSetting glow = new BooleanSetting("Glow", "Renders a glow shader effect around nametag text.", false);
   public NumberSetting scale = new NumberSetting("Scale", "The scaling that will be applied to the nametag rendering.", 30, 10, 100);
   public ModeSetting border = new ModeSetting("Border", "The border that will surround the text.", "Both", new String[]{"None", "Fill", "Outline", "Both"});
   public ColorSetting fillColor = new ColorSetting(
      "FillColor",
      "The color that will be used for the fill rendering.",
      new ModeSetting.Visibility(this.border, "Fill", "Both"),
      new ColorSetting.Color(new Color(0, 0, 0, 100), false, false)
   );
   public ColorSetting outlineColor = new ColorSetting(
      "OutlineColor",
      "The color that will be used for the outline rendering.",
      new ModeSetting.Visibility(this.border, "Outline", "Both"),
      new ColorSetting.Color(new Color(0, 0, 0, 100), false, false)
   );
   private static final Map<ItemEnchantments, List<String>> ENCHANT_CACHE = new ConcurrentHashMap<>();
   private static final Map<Holder<Enchantment>, String> NAME_CACHE = new ConcurrentHashMap<>();

   @SubscribeEvent
   public void onRenderWorld(RenderWorldEvent.Post event) {
      if (mc.level != null && mc.player != null) {
         PoseStack matrices = event.getMatrices();

         for (Player player : mc.level.players().stream().sorted(Comparator.comparing(p -> -mc.player.distanceTo(p))).toList()) {
            boolean freecam = ((IFreecamModule)Night.MODULE_MANAGER.getModule("Freecam")).isToggled();
            if ((player != mc.player || this.self.getValue() && (!mc.options.getCameraType().isFirstPerson() || freecam))
               && (!this.antiBot.getValue() || !EntityUtils.isBot(player))
               && (
                  !(player instanceof RemotePlayer ghost)
                     || (Night.MODULE_MANAGER.getModule(PopChamsModule.class) == null || !Night.MODULE_MANAGER.getModule(PopChamsModule.class).isGhost(ghost))
                        && (
                           Night.MODULE_MANAGER.getModule(LogoutSpotModule.class) == null
                              || !Night.MODULE_MANAGER.getModule(LogoutSpotModule.class).isGhost(ghost)
                        )
               )
               && Renderer3D.isFrustumVisible(player.getBoundingBox())) {
               double x = Mth.lerp(event.getTickDelta(), player.xo, player.getX());
               double y = Mth.lerp(event.getTickDelta(), player.yo, player.getY()) + (player.isShiftKeyDown() ? 1.9F : 2.1F);
               double z = Mth.lerp(event.getTickDelta(), player.zo, player.getZ());
               Vec3 vec3d = new Vec3(
                  x - mc.gameRenderer.mainCamera().position().x, y - mc.gameRenderer.mainCamera().position().y, z - mc.gameRenderer.mainCamera().position().z
               );
               float distance = (float)Math.sqrt(mc.gameRenderer.mainCamera().position().distanceToSqr(x, y, z));
               float scaling = 0.0018F + this.scale.getValue().intValue() / 10000.0F * distance;
               if (distance <= 8.0) {
                  scaling = 0.0245F;
               }

               matrices.pushPose();
               matrices.translate(vec3d.x, vec3d.y, vec3d.z);
               matrices.mulPose(mc.gameRenderer.mainCamera().rotation());
               matrices.scale(scaling, -scaling, scaling);
               boolean isNight = this.nightCheck.getValue() && Night.NIGHT_USER_MANAGER != null && Night.NIGHT_USER_MANAGER.isNightUser(player);
               Object text = player.getName().getString();
               if (this.gameMode.getValue()) {
                  text = (String)text + " [" + EntityUtils.getGameModeName(EntityUtils.getGameMode(player)) + "]";
               }

               if (this.ping.getValue()) {
                  text = (String)text + " " + EntityUtils.getLatency(player) + "ms";
               }

               if (this.entityId.getValue()) {
                  text = (String)text + " " + player.getId();
               }

               if (this.health.getValue()) {
                  int hp = Math.round(player.getHealth() + player.getAbsorptionAmount());
                  text = (String)text + " " + ColorUtils.getHealthColor(player.getHealth() + player.getAbsorptionAmount()) + hp + ChatFormatting.RESET;
               }

               int pops = Night.WORLD_MANAGER.getPoppedTotems().getOrDefault(player.getUUID(), 0);
               if (this.totemPops.getValue() && pops > 0) {
                  text = (String)text + " " + ColorUtils.getTotemColor(pops) + "-" + pops;
               }

               int textWidth = Night.FONT_MANAGER.getWidth((String)text);
               int fontHeight = Night.FONT_MANAGER.getHeight();
               int logoSize = isNight ? fontHeight - 1 : 0;
               int logoSpacing = isNight ? 3 : 0;
               int totalWidth = textWidth + logoSize + logoSpacing;
               if (this.border.getValue().equalsIgnoreCase("Fill") || this.border.getValue().equalsIgnoreCase("Both")) {
                  Renderer3D.renderQuad(matrices, -totalWidth / 2.0F - 2.0F, -fontHeight - 1, totalWidth / 2.0F + 2.0F, 1.0F, this.fillColor.getColor());
               }

               if (this.border.getValue().equalsIgnoreCase("Outline") || this.border.getValue().equalsIgnoreCase("Both")) {
                  Renderer3D.renderOutline(matrices, -totalWidth / 2.0F - 2.0F, -fontHeight - 1, totalWidth / 2.0F + 2.0F, 1.0F, this.outlineColor.getColor());
               }

               float startX = -totalWidth / 2.0F;
               if (isNight) {
                  Renderer3D.renderTexture(matrices, LOGO_ID, startX, -fontHeight + 0.5F, startX + logoSize, 0.5F, -1);
                  startX += logoSize + logoSpacing;
               }

               Color nameColor = Night.MODULE_MANAGER.getModule(FakePlayerModule.class).isToggled()
                     && Night.MODULE_MANAGER.getModule(FakePlayerModule.class).getPlayer() == player
                  ? new Color(225, 0, 70)
                  : (
                     player.isShiftKeyDown()
                        ? new Color(255, 170, 0)
                        : (Night.FRIEND_MANAGER.contains(player.getName().getString()) ? Night.FRIEND_MANAGER.getDefaultFriendColor() : Color.WHITE)
                  );
               this.drawText(matrices, (String)text, (int)startX, -fontHeight, nameColor);
               float highestY = -fontHeight - 2;
               if (this.items.getValue()) {
                  ItemStack[] playerItems = new ItemStack[6];
                  List[] itemEnchants = new List[6];
                  int maxEnchantsCount = 0;
                  boolean hasAnyItem = false;

                  for (int i = 0; i < 6; i++) {
                     ItemStack stack;
                     playerItems[i] = stack = this.getItem(player, i);
                     if (!stack.isEmpty()) {
                        hasAnyItem = true;
                        if (this.enchantments.getValue()) {
                           List<String> enchList;
                           itemEnchants[i] = enchList = this.getCachedEnchantments(stack);
                           if (enchList.size() > maxEnchantsCount) {
                              maxEnchantsCount = enchList.size();
                           }
                        }
                     }
                  }

                  if (hasAnyItem) {
                     float maxEnchantsHeight = maxEnchantsCount * 4.2F;
                     float itemContentHeight = Math.max(16.0F, maxEnchantsHeight);
                     float itemRowY;
                     highestY = itemRowY = -fontHeight - 4.0F - itemContentHeight;

                     for (int ix = 0; ix < 6; ix++) {
                        ItemStack stack = playerItems[ix];
                        if (stack != null && !stack.isEmpty()) {
                           int stackX = -54 + ix * 18 + 1;
                           matrices.pushPose();
                           matrices.translate(stackX + 8, itemRowY + 8.0F, -0.5F);
                           matrices.scale(16.0F, -16.0F, 1.0E-4F);
                           Renderer3D.renderItem(matrices, stack, player);
                           matrices.popPose();
                        }
                     }

                     for (int var51 = 0; var51 < 6; var51++) {
                        ItemStack stack = playerItems[var51];
                        if (stack != null && !stack.isEmpty()) {
                           int stackX = -54 + var51 * 18 + 1;
                           if (this.durability.getValue() && stack.isDamageableItem()) {
                              float green = (float)(stack.getMaxDamage() - stack.getDamageValue()) / stack.getMaxDamage();
                              float red = 1.0F - green;
                              String durText = Math.round((stack.getMaxDamage() - stack.getDamageValue()) * 100.0F / stack.getMaxDamage()) + "%";
                              float durWidth = Night.FONT_MANAGER.getWidth(durText) * 0.5F;
                              matrices.pushPose();
                              matrices.translate(stackX + 8 - durWidth / 2.0F, itemRowY - 5.5F, 1.0F);
                              matrices.scale(0.5F, 0.5F, 1.0F);
                              this.drawText(matrices, durText, 0.0F, 0.0F, new Color(red, green, 0.0F));
                              matrices.popPose();
                           }

                           if (stack.getItem().equals(Items.ENCHANTED_GOLDEN_APPLE)) {
                              matrices.pushPose();
                              matrices.translate(stackX + 1, itemRowY + 1.0F, 1.0F);
                              matrices.scale(0.5F, 0.5F, 1.0F);
                              this.drawText(matrices, "God", 0.0F, 0.0F, new Color(255, 125, 255));
                              matrices.popPose();
                           }

                           if (stack.getCount() != 1) {
                              String count = String.valueOf(stack.getCount());
                              float countWidth = Night.FONT_MANAGER.getWidth(count);
                              matrices.pushPose();
                              matrices.translate(stackX + 16 - countWidth, itemRowY + 7.0F, 1.0F);
                              matrices.scale(1.0F, 1.0F, 1.0F);
                              this.drawText(matrices, count, 0.0F, 0.0F, Color.WHITE);
                              matrices.popPose();
                           }

                           if (this.enchantments.getValue() && itemEnchants[var51] != null && !itemEnchants[var51].isEmpty()) {
                              List enchList = itemEnchants[var51];
                              float enchLineStep = 4.2F;

                              for (int enchIndex = 0; enchIndex < enchList.size(); enchIndex++) {
                                 String str = (String)enchList.get(enchIndex);
                                 float enchY = itemRowY + 8.0F + enchIndex * enchLineStep;
                                 matrices.pushPose();
                                 matrices.translate(stackX + 1, enchY, 1.0F);
                                 matrices.scale(0.5F, 0.5F, 1.0F);
                                 this.drawText(matrices, str, 0.0F, 0.0F, Color.WHITE);
                                 matrices.popPose();
                              }
                           }
                        }
                     }

                     if (this.durability.getValue()) {
                        highestY = itemRowY - 6.0F;
                     }
                  }
               }

               if (this.itemName.getValue() && !player.getMainHandItem().isEmpty()) {
                  String itemText = player.getMainHandItem().getHoverName().getString();
                  float itemTextWidth = Night.FONT_MANAGER.getWidth(itemText) * 0.5F;
                  float nameY = highestY - fontHeight * 0.5F - 2.0F;
                  matrices.pushPose();
                  matrices.translate(-itemTextWidth / 2.0F, nameY, 1.0F);
                  matrices.scale(0.5F, 0.5F, 1.0F);
                  this.drawText(matrices, itemText, 0.0F, 0.0F, Color.WHITE);
                  matrices.popPose();
               }

               matrices.popPose();
               Renderer3D.draw(Renderer3D.QUADS, Renderer3D.DEBUG_LINES, false);
               Renderer3D.QUADS.clear();
               Renderer3D.DEBUG_LINES.clear();
            }
         }
      }
   }

   private void drawText(PoseStack matrices, String text, float x, float y, Color color) {
      if (this.glow.getValue()) {
         Night.FONT_MANAGER.drawText(matrices, text, x, y, color, true);
      } else {
         Night.FONT_MANAGER.drawTextWithShadow(matrices, text, x, y, color, false);
      }
   }

   private List<String> getCachedEnchantments(ItemStack stack) {
      if (stack != null && !stack.isEmpty()) {
         ItemEnchantments component = (ItemEnchantments)stack.get(DataComponents.ENCHANTMENTS);
         return component != null && !component.isEmpty() ? ENCHANT_CACHE.computeIfAbsent(component, c -> {
            List<String> list = new ArrayList<>(c.size());

            for (Entry<Holder<Enchantment>> entry : c.entrySet()) {
               String shortName = NAME_CACHE.computeIfAbsent((Holder<Enchantment>)entry.getKey(), NameTagsModule::parseShortName);
               int level = entry.getIntValue();
               list.add(level > 1 ? shortName + " " + level : shortName);
            }

            return list;
         }) : Collections.emptyList();
      } else {
         return Collections.emptyList();
      }
   }

   private static String parseShortName(Holder<Enchantment> holder) {
      String reg = holder.getRegisteredName();
      int colon = reg.indexOf(58);
      String id = colon != -1 ? reg.substring(colon + 1) : reg;
      String shortName = id.startsWith("protection")
         ? "Pro"
         : (
            id.startsWith("blast_protection")
               ? "Bla"
               : (
                  id.startsWith("fire_protection")
                     ? "Fir"
                     : (
                        id.startsWith("projectile_protection")
                           ? "Proj"
                           : (
                              id.startsWith("unbreaking")
                                 ? "Unb"
                                 : (
                                    id.startsWith("mending")
                                       ? "Men"
                                       : (
                                          id.startsWith("thorns")
                                             ? "Tho"
                                             : (
                                                id.startsWith("respiration")
                                                   ? "Res"
                                                   : (
                                                      id.startsWith("aqua_affinity")
                                                         ? "Aqu"
                                                         : (
                                                            id.startsWith("depth_strider")
                                                               ? "Dep"
                                                               : (
                                                                  id.startsWith("feather_falling")
                                                                     ? "Fea"
                                                                     : (
                                                                        id.startsWith("soul_speed")
                                                                           ? "Soul"
                                                                           : (
                                                                              id.startsWith("swift_sneak")
                                                                                 ? "Sne"
                                                                                 : (
                                                                                    id.startsWith("sharpness")
                                                                                       ? "Sha"
                                                                                       : (
                                                                                          id.startsWith("smite")
                                                                                             ? "Smi"
                                                                                             : (
                                                                                                id.startsWith("bane_of_arthropods")
                                                                                                   ? "Boa"
                                                                                                   : (
                                                                                                      id.startsWith("knockback")
                                                                                                         ? "Kb"
                                                                                                         : (
                                                                                                            id.startsWith("fire_aspect")
                                                                                                               ? "FA"
                                                                                                               : (
                                                                                                                  id.startsWith("looting")
                                                                                                                     ? "Loot"
                                                                                                                     : (
                                                                                                                        id.startsWith("sweeping_edge")
                                                                                                                           ? "Swp"
                                                                                                                           : (
                                                                                                                              id.startsWith("efficiency")
                                                                                                                                 ? "Eff"
                                                                                                                                 : (
                                                                                                                                    id.startsWith("silk_touch")
                                                                                                                                       ? "Silk"
                                                                                                                                       : (
                                                                                                                                          id.startsWith(
                                                                                                                                                "fortune"
                                                                                                                                             )
                                                                                                                                             ? "Fort"
                                                                                                                                             : (
                                                                                                                                                id.startsWith(
                                                                                                                                                      "power"
                                                                                                                                                   )
                                                                                                                                                   ? "Pow"
                                                                                                                                                   : (
                                                                                                                                                      id.startsWith(
                                                                                                                                                            "punch"
                                                                                                                                                         )
                                                                                                                                                         ? "Pun"
                                                                                                                                                         : (
                                                                                                                                                            id.startsWith(
                                                                                                                                                                  "flame"
                                                                                                                                                               )
                                                                                                                                                               ? "Fla"
                                                                                                                                                               : (
                                                                                                                                                                  id.startsWith(
                                                                                                                                                                        "infinity"
                                                                                                                                                                     )
                                                                                                                                                                     ? "Inf"
                                                                                                                                                                     : (
                                                                                                                                                                        id.startsWith(
                                                                                                                                                                              "loyalty"
                                                                                                                                                                           )
                                                                                                                                                                           ? "Loy"
                                                                                                                                                                           : (
                                                                                                                                                                              id.startsWith(
                                                                                                                                                                                    "impaling"
                                                                                                                                                                                 )
                                                                                                                                                                                 ? "Imp"
                                                                                                                                                                                 : (
                                                                                                                                                                                    id.startsWith(
                                                                                                                                                                                          "riptide"
                                                                                                                                                                                       )
                                                                                                                                                                                       ? "Rip"
                                                                                                                                                                                       : (
                                                                                                                                                                                          id.startsWith(
                                                                                                                                                                                                "channeling"
                                                                                                                                                                                             )
                                                                                                                                                                                             ? "Chan"
                                                                                                                                                                                             : (
                                                                                                                                                                                                id.startsWith(
                                                                                                                                                                                                      "multishot"
                                                                                                                                                                                                   )
                                                                                                                                                                                                   ? "Multi"
                                                                                                                                                                                                   : (
                                                                                                                                                                                                      id.startsWith(
                                                                                                                                                                                                            "quick_charge"
                                                                                                                                                                                                         )
                                                                                                                                                                                                         ? "Quick"
                                                                                                                                                                                                         : (
                                                                                                                                                                                                            id.startsWith(
                                                                                                                                                                                                                  "piercing"
                                                                                                                                                                                                               )
                                                                                                                                                                                                               ? "Pier"
                                                                                                                                                                                                               : (
                                                                                                                                                                                                                  id.startsWith(
                                                                                                                                                                                                                        "density"
                                                                                                                                                                                                                     )
                                                                                                                                                                                                                     ? "Den"
                                                                                                                                                                                                                     : (
                                                                                                                                                                                                                        id.startsWith(
                                                                                                                                                                                                                              "breach"
                                                                                                                                                                                                                           )
                                                                                                                                                                                                                           ? "Bre"
                                                                                                                                                                                                                           : (
                                                                                                                                                                                                                              id.startsWith(
                                                                                                                                                                                                                                    "wind_burst"
                                                                                                                                                                                                                                 )
                                                                                                                                                                                                                                 ? "Wind"
                                                                                                                                                                                                                                 : (
                                                                                                                                                                                                                                    id.startsWith(
                                                                                                                                                                                                                                          "vanishing_curse"
                                                                                                                                                                                                                                       )
                                                                                                                                                                                                                                       ? "Van"
                                                                                                                                                                                                                                       : (
                                                                                                                                                                                                                                          id.startsWith(
                                                                                                                                                                                                                                                "binding_curse"
                                                                                                                                                                                                                                             )
                                                                                                                                                                                                                                             ? "Bind"
                                                                                                                                                                                                                                             : (
                                                                                                                                                                                                                                                id.length()
                                                                                                                                                                                                                                                      > 3
                                                                                                                                                                                                                                                   ? id.substring(
                                                                                                                                                                                                                                                      0,
                                                                                                                                                                                                                                                      3
                                                                                                                                                                                                                                                   )
                                                                                                                                                                                                                                                   : id
                                                                                                                                                                                                                                             )
                                                                                                                                                                                                                                       )
                                                                                                                                                                                                                                 )
                                                                                                                                                                                                                           )
                                                                                                                                                                                                                     )
                                                                                                                                                                                                               )
                                                                                                                                                                                                         )
                                                                                                                                                                                                   )
                                                                                                                                                                                             )
                                                                                                                                                                                       )
                                                                                                                                                                                 )
                                                                                                                                                                           )
                                                                                                                                                                     )
                                                                                                                                                               )
                                                                                                                                                         )
                                                                                                                                                   )
                                                                                                                                             )
                                                                                                                                       )
                                                                                                                                 )
                                                                                                                           )
                                                                                                                     )
                                                                                                               )
                                                                                                         )
                                                                                                   )
                                                                                             )
                                                                                       )
                                                                                 )
                                                                           )
                                                                     )
                                                               )
                                                         )
                                                   )
                                             )
                                       )
                                 )
                           )
                     )
               )
         );
      return shortName.substring(0, 1).toUpperCase() + shortName.substring(1);
   }

   private ItemStack getItem(Player player, int index) {
      return switch (index) {
         case 0 -> player.getMainHandItem();
         case 1 -> player.getItemBySlot(EquipmentSlot.HEAD);
         case 2 -> player.getItemBySlot(EquipmentSlot.CHEST);
         case 3 -> player.getItemBySlot(EquipmentSlot.LEGS);
         case 4 -> player.getItemBySlot(EquipmentSlot.FEET);
         case 5 -> player.getOffhandItem();
         default -> ItemStack.EMPTY;
      };
   }
}
