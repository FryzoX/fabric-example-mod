package night.modules.impl.visuals;

import night.Night;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.NumberSetting;

@RegisterModule(
   name = "CrystalAnimations",
   description = "Customizes crystal model animations and parts locally.",
   category = Module.Category.VISUALS
)
public class CrystalAnimationsModule extends Module {
   public NumberSetting rotationSpeed;
   public NumberSetting floatFactor;
   public NumberSetting crystalScale;
   public BooleanSetting inner;
   public BooleanSetting outer;
   public BooleanSetting core;
   public BooleanSetting bottom;
   public NumberSetting heightOffset = new NumberSetting(
      "HeightOffset", "Crystal visual height in blocks; positive raises it, negative lowers it.", 0.0F, -2.0F, 2.0F
   );

   public static CrystalAnimationsModule active() {
      if (Night.MODULE_MANAGER == null) {
         return null;
      } else {
         CrystalAnimationsModule module = Night.MODULE_MANAGER.getModule(CrystalAnimationsModule.class);
         return module != null && module.isToggled() ? module : null;
      }
   }

   public CrystalAnimationsModule() {
      this.rotationSpeed = new NumberSetting("RotationSpeed", "Crystal rotation multiplier.", 1.0F, 0.0F, 5.0F);
      this.floatFactor = new NumberSetting("FloatFactor", "Crystal bobbing amplitude; zero disables bobbing.", 1.0F, 0.0F, 3.0F);
      this.crystalScale = new NumberSetting("CrystalScale", "Crystal model size multiplier.", 1.0F, 0.1F, 3.0F);
      this.inner = new BooleanSetting("Inner", "Show inner glass without hiding the core.", true);
      this.outer = new BooleanSetting("Outer", "Show outer glass without hiding inner parts.", true);
      this.core = new BooleanSetting("Core", "Show the crystal core.", true);
      this.bottom = new BooleanSetting("Bottom", "Show the base when the crystal normally has one.", true);
   }
}
