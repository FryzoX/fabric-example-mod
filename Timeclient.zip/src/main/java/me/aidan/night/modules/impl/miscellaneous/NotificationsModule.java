package night.modules.impl.miscellaneous;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownEnderpearl;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.ClientConnectEvent;
import night.events.impl.PlayerDeathEvent;
import night.events.impl.PlayerPopEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.utils.chat.ChatUtils;
import night.utils.minecraft.EntityUtils;

@RegisterModule(
   name = "Notifications",
   description = "Notifies you in chat whenever something significant happens.",
   category = Module.Category.MISCELLANEOUS
)
public class NotificationsModule extends Module {
   public BooleanSetting totemPops = new BooleanSetting("TotemPops", "Notifies you in chat whenever a player pops a totem.", true);
   public BooleanSetting visualRange = new BooleanSetting("VisualRange", "Notifies you in chat whenever a player enters your render distance.", false);
   public BooleanSetting pearlThrows = new BooleanSetting("PearlThrows", "Notifies you in chat whenever a player throws a pearl.", true);
   private final Map<UUID, String> loadedPlayers = new LinkedHashMap<>();
   private final ArrayList<Integer> thrownPearls = new ArrayList<>();

   @SubscribeEvent
   public void onTick(TickEvent event) {
      if (!this.getNull()) {
         if (this.visualRange.getValue()) {
            HashSet<UUID> currentlyVisible = new HashSet<>();

            for (Entity entity : mc.level.entitiesForRendering()) {
               if (entity instanceof Player player && entity != mc.player && !EntityUtils.isGhost(player)) {
                  FakePlayerModule fakePlayer = Night.MODULE_MANAGER != null ? Night.MODULE_MANAGER.getModule(FakePlayerModule.class) : null;
                  if (fakePlayer == null || !fakePlayer.isToggled() || entity != fakePlayer.getPlayer()) {
                     currentlyVisible.add(player.getUUID());
                     if (!this.loadedPlayers.containsKey(player.getUUID())) {
                        this.loadedPlayers.put(player.getUUID(), player.getName().getString());
                        Night.CHAT_MANAGER
                           .message(
                              ChatUtils.getPrimary() + player.getName().getString() + ChatUtils.getSecondary() + " has entered your visual range.",
                              "visual-range-" + player.getName().getString()
                           );
                     }
                  }
               }
            }

            if (!this.loadedPlayers.isEmpty()) {
               Iterator<Entry<UUID, String>> it = this.loadedPlayers.entrySet().iterator();

               while (it.hasNext()) {
                  Entry<UUID, String> entry = it.next();
                  if (!currentlyVisible.contains(entry.getKey())) {
                     it.remove();
                     Night.CHAT_MANAGER
                        .message(
                           ChatUtils.getPrimary() + entry.getValue() + ChatUtils.getSecondary() + " has left your visual range.",
                           "visual-range-" + entry.getValue()
                        );
                  }
               }
            }
         }

         if (this.pearlThrows.getValue()) {
            for (Entity e : mc.level.entitiesForRendering()) {
               ThrownEnderpearl pearl;
               if (e instanceof ThrownEnderpearl && (pearl = (ThrownEnderpearl)e).getOwner() != null && !this.thrownPearls.contains(pearl.getId())) {
                  String name = pearl.getOwner().getName().getString();
                  Night.CHAT_MANAGER
                     .message(
                        ChatUtils.getPrimary()
                           + name
                           + ChatUtils.getSecondary()
                           + " threw a pearl towards "
                           + EntityUtils.getPearlDirection(pearl).toString()
                           + ".",
                        "pearl-throws-" + name
                     );
                  this.thrownPearls.add(pearl.getId());
               }
            }

            this.thrownPearls.removeIf(id -> !(mc.level.getEntity(id) instanceof ThrownEnderpearl));
         }
      }
   }

   @SubscribeEvent
   public void onClientConnect(ClientConnectEvent event) {
      this.loadedPlayers.clear();
   }

   @SubscribeEvent
   public void onPlayerPop(PlayerPopEvent event) {
      if (this.totemPops.getValue()) {
         Night.CHAT_MANAGER
            .message(
               ChatUtils.getPrimary()
                  + event.getPlayer().getName().getString()
                  + ChatUtils.getSecondary()
                  + " has popped "
                  + ChatUtils.getPrimary()
                  + event.getPops()
                  + ChatUtils.getSecondary()
                  + " totem"
                  + (event.getPops() > 1 ? "s" : "")
                  + ".",
               "totem-pop-" + event.getPlayer().getName().getString()
            );
      }
   }

   @SubscribeEvent
   public void onPlayerDeath(PlayerDeathEvent event) {
      int pops = Night.WORLD_MANAGER.getPoppedTotems().getOrDefault(event.getPlayer().getUUID(), 0);
      if (this.totemPops.getValue() && pops > 0) {
         Night.CHAT_MANAGER
            .message(
               ChatUtils.getPrimary()
                  + event.getPlayer().getName().getString()
                  + ChatUtils.getSecondary()
                  + " has died after popping "
                  + ChatUtils.getPrimary()
                  + pops
                  + ChatUtils.getSecondary()
                  + " totem"
                  + (pops > 1 ? "s" : "")
                  + ".",
               "totem-pop-" + event.getPlayer().getName().getString()
            );
      }
   }
}
