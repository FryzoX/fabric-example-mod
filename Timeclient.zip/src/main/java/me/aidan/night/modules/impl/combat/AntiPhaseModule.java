package night.modules.impl.combat;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.PlayerUpdateEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.EntityUtils;
import night.utils.minecraft.HoleUtils;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.WorldUtils;

@RegisterModule(
   name = "AntiPhase",
   description = "Places a climbable block (Scaffolding, Ladder, Vines) directly at a target enemy's feet.",
   category = Module.Category.COMBAT
)
public class AntiPhaseModule extends Module {
   public ModeSetting block = new ModeSetting(
      "Block", "The item placed at the enemy's feet.", "Scaffolding", new String[]{"Scaffolding", "Ladder", "Vines", "Rail"}
   );
   public ModeSetting autoSwitch = new ModeSetting(
      "Switch", "The mode that will be used for automatically switching to the selected item.", "Silent", InventoryUtils.SWITCH_MODES
   );
   public ModeSetting rotate = new ModeSetting("Rotate", "The rotation mode when placing.", "Grim", new String[]{"None", "Normal", "Grim"});
   public BooleanSetting strictDirection = new BooleanSetting("StrictDirection", "Only places using directions that face you.", false);
   public BooleanSetting render = new BooleanSetting("Render", "Whether or not to render the place position.", true);
   public NumberSetting range = new NumberSetting("Range", "The maximum distance at which enemies will be targeted.", 5.0F, 1.0F, 6.0F);
   public NumberSetting wallRange = new NumberSetting(
      "WallRange", "The maximum distance at which enemies will be targeted through walls (no line of sight required).", 3.0F, 0.0F, 6.0F
   );
   public BooleanSetting onlyHole = new BooleanSetting(
      "OnlyHole", "Only places while the enemy is already standing in a hole (feet surrounded by blocks).", false
   );
   public BooleanSetting pauseOnEat = new BooleanSetting("PauseOnEat", "Pauses placing while eating or using items.", false);
   private Player target;

   @Override
   public String getMetaData() {
      return this.target != null ? this.target.getName().getString() : "None";
   }

   @Override
   public void onDisable() {
      this.target = null;
   }

   private int findItemSlot(Item item) {
      for (int i = 0; i <= 8; i++) {
         if (mc.player.getInventory().getItem(i).is(item)) {
            return i;
         }
      }

      return -1;
   }

   private Player findTarget() {
      return mc.level.players().stream().filter(this::isValidTarget).min(Comparator.comparingDouble(p -> mc.player.distanceToSqr(p))).orElse(null);
   }

   private boolean isValidTarget(Player player) {
      if (player == mc.player || !player.isAlive() || player.isRemoved() || player.isSpectator()) {
         return false;
      } else if (EntityUtils.isGhost(player)) {
         return false;
      } else if (Night.FRIEND_MANAGER.contains(player.getName().getString())) {
         return false;
      } else {
         double distSq = mc.player.distanceToSqr(player);
         if (distSq > Mth.square(this.range.getValue().doubleValue())) {
            return false;
         } else {
            boolean needLos = distSq > Mth.square(this.wallRange.getValue().doubleValue());
            return !needLos || WorldUtils.canSee(player);
         }
      }
   }

   private boolean isPlaceable(BlockPos position, Player targetPlayer) {
      if (mc.level == null) {
         return false;
      } else if (mc.level.isOutsideBuildHeight(position)) {
         return false;
      } else {
         return !mc.level.getBlockState(position).canBeReplaced()
            ? false
            : mc.level
               .getEntities((Entity)null, new AABB(position), e -> true)
               .stream()
               .noneMatch(
                  e -> e != targetPlayer
                     && !(e instanceof ExperienceOrb)
                     && !(e instanceof ItemEntity)
                     && !(e instanceof AbstractArrow)
                     && !EntityUtils.isGhost(e)
               );
      }
   }

   private Set<BlockPos> footCells(Player player) {
      HashSet<BlockPos> cells = new HashSet<>();
      AABB box = player.getBoundingBox();
      int y = player.blockPosition().getY();

      for (int x = (int)Math.floor(box.minX); x < Math.ceil(box.maxX); x++) {
         for (int z = (int)Math.floor(box.minZ); z < Math.ceil(box.maxZ); z++) {
            cells.add(new BlockPos(x, y, z));
         }
      }

      return cells;
   }

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (mc.player != null && mc.level != null) {
         if (!this.pauseOnEat.getValue() || !mc.player.isUsingItem() && mc.player.getUseItemRemainingTicks() <= 0) {
            this.target = this.findTarget();
            if (this.target != null) {
               if (!this.onlyHole.getValue() || HoleUtils.isPlayerInHole(this.target)) {
                  int slot = this.findItemSlot(this.resolveItem());
                  if (slot != -1) {
                     Set<BlockPos> feetCells = this.footCells(this.target);
                     boolean railMode = this.block.getValue().equals("Rail");
                     if (railMode) {
                        feetCells.removeIf(
                           positionx -> !this.isPlaceable(positionx, this.target)
                              || !Blocks.RAIL.defaultBlockState().canSurvive(mc.level, positionx)
                              || !WorldUtils.getDirections(positionx, List.of(), this.strictDirection.getValue()).contains(Direction.DOWN)
                        );
                        if (feetCells.isEmpty()) {
                           return;
                        }
                     }

                     int previousSlot = mc.player.getInventory().getSelectedSlot();
                     Night.ROTATION_MANAGER.beginBatchRotation();

                     try {
                        if (InventoryUtils.switchSlot(this.autoSwitch.getValue(), slot, previousSlot)) {
                           for (BlockPos position : feetCells) {
                              if (this.isPlaceable(position, this.target)) {
                                 if (railMode) {
                                    WorldUtils.placeBlock(
                                       position, Direction.DOWN, InteractionHand.MAIN_HAND, this.rotate.getValue(), true, this.render.getValue()
                                    );
                                 } else {
                                    boolean placed = false;
                                    Iterator var9 = WorldUtils.getDirections(position, List.of(), this.strictDirection.getValue()).iterator();

                                    while (true) {
                                       if (var9.hasNext()) {
                                          Direction direction = (Direction)var9.next();
                                          if (!WorldUtils.placeBlock(
                                             position, direction, InteractionHand.MAIN_HAND, this.rotate.getValue(), true, this.render.getValue()
                                          )) {
                                             continue;
                                          }

                                          placed = true;
                                       }

                                       if (!placed) {
                                          WorldUtils.airPlaceBlock(position, InteractionHand.MAIN_HAND, "None", this.render.getValue());
                                       }
                                       break;
                                    }
                                 }
                              }
                           }

                           InventoryUtils.switchBack(this.autoSwitch.getValue(), slot, previousSlot);
                           return;
                        }
                     } finally {
                        Night.ROTATION_MANAGER.endBatchRotation();
                     }
                  }
               }
            }
         }
      }
   }

   private Item resolveItem() {
      String var1 = this.block.getValue();

      return switch (var1) {
         case "Rail" -> Items.RAIL;
         case "Ladder" -> Items.LADDER;
         case "Vines" -> Items.VINE;
         default -> Items.SCAFFOLDING;
      };
   }
}
